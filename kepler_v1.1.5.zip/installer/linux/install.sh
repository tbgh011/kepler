#!/bin/bash
# =================================================================
#  Kepler - Planetary Image Processing Suite
#  Linux Installer Bootstrap
#  Supports: Linux Mint, Ubuntu, Debian, Fedora, Arch
# =================================================================

KEPLER_VERSION="1.0.0"
BOLD="\033[1m"
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
CYAN="\033[36m"
DIM="\033[2m"
RESET="\033[0m"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${CYAN}${BOLD}  ╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}${BOLD}  ║         KEPLER  -  Planetary Image Processor         ║${RESET}"
echo -e "${CYAN}${BOLD}  ║                   Linux Installer                    ║${RESET}"
echo -e "${CYAN}${BOLD}  ╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "${DIM}  Version: ${KEPLER_VERSION}  |  $(uname -srm)${RESET}"
echo ""

# ── Detect distro ───────────────────────────────────────────────
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO_NAME="${PRETTY_NAME:-Linux}"
    DISTRO_ID="${ID:-unknown}"
    DISTRO_ID_LIKE="${ID_LIKE:-}"
else
    DISTRO_NAME="Linux"
    DISTRO_ID="unknown"
    DISTRO_ID_LIKE=""
fi

echo -e "  System detected: ${GREEN}${DISTRO_NAME}${RESET}"
echo ""

# ── Detect package manager ──────────────────────────────────────
PKG_MGR=""
if command -v apt-get &>/dev/null; then
    PKG_MGR="apt-get"
elif command -v apt &>/dev/null; then
    PKG_MGR="apt"
elif command -v dnf &>/dev/null; then
    PKG_MGR="dnf"
elif command -v yum &>/dev/null; then
    PKG_MGR="yum"
elif command -v pacman &>/dev/null; then
    PKG_MGR="pacman"
fi

if [ -n "$PKG_MGR" ]; then
    echo -e "  Package manager: ${GREEN}${PKG_MGR}${RESET}"
else
    echo -e "  Package manager: ${YELLOW}not found (pip fallback only)${RESET}"
fi

# ── Check sudo / root ───────────────────────────────────────────
IS_ROOT=0
CAN_SUDO=0

if [ "$EUID" -eq 0 ]; then
    IS_ROOT=1
    echo -e "  Running as:      ${GREEN}root${RESET}"
elif sudo -n true 2>/dev/null; then
    CAN_SUDO=1
    echo -e "  Sudo access:     ${GREEN}available (cached)${RESET}"
else
    echo -e "  Sudo access:     ${YELLOW}will prompt for password${RESET}"
    echo ""
    echo -e "  ${YELLOW}NOTE: Some packages require sudo (administrator) access.${RESET}"
    echo -e "  ${YELLOW}You will be asked for your password below.${RESET}"
    echo -e "  ${YELLOW}This is required to install: python3-tk, python3-pip${RESET}"
fi

echo ""

# ── Check Python ────────────────────────────────────────────────
echo -e "${BOLD}  [1/5] Checking Python...${RESET}"

PYTHON_CMD=""
for cmd in python3 python python3.11 python3.10 python3.9 python3.8; do
    if command -v "$cmd" &>/dev/null; then
        PYVER=$("$cmd" --version 2>&1 | awk '{print $2}')
        PYMAJOR=$(echo "$PYVER" | cut -d. -f1)
        PYMINOR=$(echo "$PYVER" | cut -d. -f2)
        if [ "$PYMAJOR" -ge 3 ] && [ "$PYMINOR" -ge 8 ]; then
            PYTHON_CMD="$cmd"
            echo -e "  ${GREEN}✔ Found Python ${PYVER} at $(which $cmd)${RESET}"
            break
        fi
    fi
done

if [ -z "$PYTHON_CMD" ]; then
    echo -e "  ${YELLOW}Python 3.8+ not found. Installing...${RESET}"
    if [ "$PKG_MGR" = "apt-get" ] || [ "$PKG_MGR" = "apt" ]; then
        sudo apt-get update -qq
        sudo apt-get install -y python3 python3-pip
        PYTHON_CMD="python3"
    elif [ "$PKG_MGR" = "dnf" ] || [ "$PKG_MGR" = "yum" ]; then
        sudo $PKG_MGR install -y python3 python3-pip
        PYTHON_CMD="python3"
    elif [ "$PKG_MGR" = "pacman" ]; then
        sudo pacman -S --noconfirm python python-pip
        PYTHON_CMD="python3"
    else
        echo -e "  ${RED}ERROR: Cannot install Python automatically.${RESET}"
        echo -e "  ${RED}Please install Python 3.8+ manually and re-run this installer.${RESET}"
        echo ""
        exit 1
    fi
fi

# ── Check tkinter ────────────────────────────────────────────────
echo ""
echo -e "${BOLD}  [2/5] Checking tkinter (GUI toolkit)...${RESET}"

if $PYTHON_CMD -c "import tkinter" 2>/dev/null; then
    echo -e "  ${GREEN}✔ tkinter is available${RESET}"
else
    echo -e "  ${YELLOW}tkinter not found. Installing python3-tk...${RESET}"
    echo ""
    if [ "$PKG_MGR" = "apt-get" ] || [ "$PKG_MGR" = "apt" ]; then
        echo -e "  ${YELLOW}This requires sudo (administrator) access.${RESET}"
        echo -e "  ${YELLOW}Enter your password if prompted:${RESET}"
        echo ""
        sudo apt-get install -y python3-tk
    elif [ "$PKG_MGR" = "dnf" ] || [ "$PKG_MGR" = "yum" ]; then
        sudo $PKG_MGR install -y python3-tkinter
    elif [ "$PKG_MGR" = "pacman" ]; then
        sudo pacman -S --noconfirm tk
    else
        echo -e "  ${RED}Cannot install tkinter automatically.${RESET}"
        echo -e "  ${RED}On Debian/Ubuntu/Mint:  sudo apt install python3-tk${RESET}"
        echo -e "  ${RED}On Fedora/RHEL:         sudo dnf install python3-tkinter${RESET}"
        echo ""
        read -p "Press Enter to continue anyway (installer may fail)..."
    fi

    # Re-check
    if ! $PYTHON_CMD -c "import tkinter" 2>/dev/null; then
        echo -e "  ${RED}ERROR: tkinter still not available after install attempt.${RESET}"
        echo -e "  ${RED}Please install manually: sudo apt install python3-tk${RESET}"
        exit 1
    fi
    echo -e "  ${GREEN}✔ tkinter installed successfully${RESET}"
fi

# ── Ensure python3-pil.imagetk is installed (ImageTk needed by Kepler) ──
echo ""
echo -e "${BOLD}  [2b/5] Checking Pillow ImageTk support...${RESET}"

if $PYTHON_CMD -c "from PIL import ImageTk" 2>/dev/null; then
    echo -e "  ${GREEN}✔ Pillow ImageTk available${RESET}"
else
    echo -e "  ${YELLOW}ImageTk not found. Installing python3-pil.imagetk...${RESET}"
    if [ "$PKG_MGR" = "apt-get" ] || [ "$PKG_MGR" = "apt" ]; then
        sudo apt-get install -y python3-pil.imagetk
    fi
    if ! $PYTHON_CMD -c "from PIL import ImageTk" 2>/dev/null; then
        echo -e "  ${YELLOW}⚠ ImageTk still unavailable — Kepler GUI may not start${RESET}"
    else
        echo -e "  ${GREEN}✔ Pillow ImageTk installed${RESET}"
    fi
fi

# ── Check pip ────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}  [3/5] Checking pip...${RESET}"

if $PYTHON_CMD -m pip --version &>/dev/null 2>&1; then
    PIP_VER=$($PYTHON_CMD -m pip --version 2>&1 | awk '{print $2}')
    echo -e "  ${GREEN}✔ pip ${PIP_VER} available${RESET}"
else
    echo -e "  ${YELLOW}pip not found. Installing...${RESET}"
    if [ "$PKG_MGR" = "apt-get" ] || [ "$PKG_MGR" = "apt" ]; then
        sudo apt-get install -y python3-pip
    elif [ "$PKG_MGR" = "dnf" ] || [ "$PKG_MGR" = "yum" ]; then
        sudo $PKG_MGR install -y python3-pip
    elif [ "$PKG_MGR" = "pacman" ]; then
        sudo pacman -S --noconfirm python-pip
    else
        $PYTHON_CMD -m ensurepip --upgrade 2>/dev/null || true
    fi
fi

# ── Install Python libraries ─────────────────────────────────────
echo ""
echo -e "${BOLD}  [4/5] Checking Python libraries...${RESET}"

MISSING_PKGS=""
for pkg_info in "numpy:NumPy" "PIL:Pillow" "scipy:SciPy" "tifffile scikit-image:tifffile"; do
    import_name="${pkg_info%%:*}"
    pip_name="${pkg_info##*:}"
    if $PYTHON_CMD -c "import $import_name" 2>/dev/null; then
        echo -e "  ${GREEN}✔ ${pip_name} already installed${RESET}"
    else
        echo -e "  ${YELLOW}○ ${pip_name} not found — will install${RESET}"
        MISSING_PKGS="$MISSING_PKGS $pip_name"
    fi
done

if [ -n "$MISSING_PKGS" ]; then
    echo ""
    echo -e "  Installing:${YELLOW}${MISSING_PKGS}${RESET}"
    echo -e "  ${DIM}(using pip --user, no sudo needed)${RESET}"
    echo ""
    $PYTHON_CMD -m pip install --user --upgrade $MISSING_PKGS 2>/tmp/kepler_pip_err.txt
    PIP_RC=$?
    if [ $PIP_RC -eq 0 ]; then
        echo -e "  ${GREEN}✔ Libraries installed successfully${RESET}"
    elif grep -q "externally-managed" /tmp/kepler_pip_err.txt 2>/dev/null; then
        # PEP 668: system Python on Ubuntu 23+ / Mint 22 requires this flag
        echo -e "  ${YELLOW}Retrying with --break-system-packages (PEP 668)...${RESET}"
        $PYTHON_CMD -m pip install --user --break-system-packages --upgrade $MISSING_PKGS
        if [ $? -eq 0 ]; then
            echo -e "  ${GREEN}✔ Libraries installed successfully${RESET}"
        else
            echo -e "  ${YELLOW}⚠ Some libraries may have failed — check output above${RESET}"
        fi
    else
        echo -e "  ${YELLOW}⚠ Some libraries may have failed — check output above${RESET}"
    fi
    rm -f /tmp/kepler_pip_err.txt
else
    echo -e "  ${GREEN}✔ All libraries already installed${RESET}"
fi

# ── Launch GUI installer ─────────────────────────────────────────
echo ""
echo -e "${BOLD}  [5/5] Launching Kepler GUI Installer...${RESET}"
echo ""

if [ -f "$SCRIPT_DIR/install_linux.py" ]; then
    exec $PYTHON_CMD "$SCRIPT_DIR/install_linux.py"
else
    # Fallback: no GUI installer, do minimal install
    echo -e "  ${YELLOW}GUI installer not found. Running minimal text install...${RESET}"

    INSTALL_DIR="$HOME/.local/share/kepler"
    BIN_DIR="$HOME/.local/bin"

    mkdir -p "$INSTALL_DIR" "$BIN_DIR"

    # Copy app files if they exist next to this script
    for f in main.py app.py processing.py requirements.txt; do
        if [ -f "$SCRIPT_DIR/../$f" ]; then
            cp "$SCRIPT_DIR/../$f" "$INSTALL_DIR/"
            echo -e "  ${GREEN}✔ Copied $f${RESET}"
        fi
    done

    # Create launcher
    cat > "$BIN_DIR/kepler" << EOF
#!/bin/bash
cd "$INSTALL_DIR"
exec $PYTHON_CMD "$INSTALL_DIR/main.py" "\$@"
EOF
    chmod +x "$BIN_DIR/kepler"
    echo -e "  ${GREEN}✔ Created: $BIN_DIR/kepler${RESET}"

    # PATH
    if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
        echo "export PATH=\"\$PATH:$BIN_DIR\"" >> "$HOME/.bashrc"
        echo "export PATH=\"\$PATH:$BIN_DIR\"" >> "$HOME/.profile"
        echo -e "  ${GREEN}✔ Added $BIN_DIR to PATH in ~/.bashrc${RESET}"
    fi

    echo ""
    echo -e "  ${GREEN}${BOLD}Kepler installed! Launch with: kepler${RESET}"
    echo -e "  ${DIM}(open a new terminal for PATH to take effect)${RESET}"
fi

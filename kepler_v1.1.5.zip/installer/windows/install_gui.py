#!/usr/bin/env python3
"""
install_gui.py — Kepler GUI Installer for Windows
Light theme matching main app · auto-sized window · robust Python detection
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import subprocess
import sys
import os
import shutil
import platform
import time
import tempfile
import urllib.request

try:
    import ctypes
    import winreg
    WINDOWS = True
except ImportError:
    WINDOWS = False

# ─────────────────────────────────────────────────────────────
#  Theme — identical to main Kepler app (light)
# ─────────────────────────────────────────────────────────────
BG        = "#f0f4f8"
BG_PANEL  = "#e2e8f0"
BG_CARD   = "#ffffff"
BG_RAISED = "#cbd5e1"
FG_BRIGHT = "#0f172a"
FG_MID    = "#334155"
FG_DIM    = "#64748b"
ACCENT    = "#0369a1"
ACCENT_G  = "#15803d"
ACCENT_O  = "#c2410c"
ACCENT_R  = "#dc2626"
BORDER    = "#94a3b8"
SEL_BG    = "#bfdbfe"

# Box accent backgrounds (light tints)
BOX_ORANGE = "#fff3e8"
BOX_BLUE   = "#e8f4fb"
BOX_GREEN  = "#e8f7ee"
BOX_GREY   = "#f8fafc"

KEPLER_VERSION      = "1.1.5"
INSTALL_DIR_DEFAULT = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Kepler"
)
PYTHON_MIN    = (3, 8)
PYTHON_URL    = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
PYTHON_WINGET = "Python.Python.3.11"
REQUIRED_PACKAGES = [
    ("numpy",    "numpy",    "Scientific array processing"),
    ("PIL",      "Pillow",   "Image file support (PNG/JPEG/TIFF)"),
    ("scipy",    "scipy",    "FFT & signal processing"),
    ("tifffile",     "tifffile",      "16-bit TIFF support"),
    ("scikit-image", "scikit-image",  "CLAHE contrast enhancement"),
]

# ─────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────
def is_admin():
    if not WINDOWS:
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False


def find_python():
    """
    Search for a suitable Python interpreter.
    After a fresh winget/installer install the PATH of THIS process is not
    updated, so we also probe every known Windows installation directory.
    """
    candidates = [sys.executable, "python", "python3", "py"]

    if WINDOWS:
        localappdata   = os.environ.get("LOCALAPPDATA", "")
        appdata        = os.environ.get("APPDATA", "")
        programfiles   = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        programfiles86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
        home           = os.path.expanduser("~")
        windir         = os.environ.get("WINDIR", r"C:\Windows")

        # Windows py launcher (highest priority after sys.executable)
        py_launcher = os.path.join(windir, "py.exe")
        if os.path.isfile(py_launcher):
            candidates.insert(1, py_launcher)

        # Probe known install directories for freshly-installed Python
        for base in [localappdata, appdata, programfiles, programfiles86, home]:
            if not base:
                continue
            for pyver in ["Python313", "Python312", "Python311",
                          "Python310", "Python39", "Python38"]:
                for sub in [
                    pyver,
                    os.path.join("Programs", "Python", pyver),
                    os.path.join("AppData", "Local", "Programs", "Python", pyver),
                ]:
                    exe = os.path.join(base, sub, "python.exe")
                    if os.path.isfile(exe) and exe not in candidates:
                        candidates.append(exe)

        # Also scan PATH manually in case it was updated by winget but not inherited
        path_env = os.environ.get("PATH", "")
        for directory in path_env.split(os.pathsep):
            exe = os.path.join(directory, "python.exe")
            if os.path.isfile(exe) and exe not in candidates:
                candidates.append(exe)

    seen = set()
    for cmd in candidates:
        if cmd in seen:
            continue
        seen.add(cmd)
        try:
            out = subprocess.check_output(
                [cmd, "--version"],
                stderr=subprocess.STDOUT,
                text=True,
                timeout=8,
            ).strip()
            ver_str = out.split()[-1]
            parts   = tuple(int(x) for x in ver_str.split(".")[:2])
            if parts >= PYTHON_MIN:
                return cmd, ver_str
        except Exception:
            continue
    return None, None


def check_package(import_name):
    try:
        __import__(import_name)
        return True
    except ImportError:
        return False


def run_cmd(cmd, log_fn=None):
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, shell=False
    )
    lines = []
    for line in proc.stdout:
        line = line.rstrip()
        lines.append(line)
        if log_fn:
            log_fn(line)
    proc.wait()
    return proc.returncode, "\n".join(lines)


def add_to_path_registry(path):
    if not WINDOWS:
        return False
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Environment", 0, winreg.KEY_ALL_ACCESS
        )
        current, _ = winreg.QueryValueEx(key, "PATH")
        if path.lower() not in current.lower():
            winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ,
                              current + ";" + path)
        winreg.CloseKey(key)
        ctypes.windll.user32.SendMessageTimeoutW(
            0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, None
        )
        return True
    except Exception:
        return False


def create_shortcut(target_py, shortcut_path, working_dir,
                    description="Kepler", icon_path="", pythonw_path="pythonw.exe"):
    """
    Create a Windows .lnk shortcut with icon.
    Tries: ctypes IShellLink COM → win32com → PowerShell → VBS
    All methods set IconLocation when icon_path points to an existing file.
    """
    has_icon = bool(icon_path and os.path.isfile(icon_path))
    args     = f'"{target_py}"'

    # ── Method 1: ctypes IShellLink (pure Python, no extra packages) ──
    try:
        import ctypes, ctypes.wintypes
        from uuid import UUID

        ole32 = ctypes.windll.ole32
        ole32.CoInitialize(None)

        def _make_guid(s):
            g = UUID(s)
            return (ctypes.c_byte * 16)(*g.bytes_le)

        clsid_sl = _make_guid("00021401-0000-0000-C000-000000000046")
        iid_sl   = _make_guid("000214F9-0000-0000-C000-000000000046")
        iid_pf   = _make_guid("0000010B-0000-0000-C000-000000000046")

        psl = ctypes.c_void_p()
        hr  = ole32.CoCreateInstance(
            ctypes.byref(clsid_sl), None, 1,         # CLSCTX_INPROC_SERVER = 1
            ctypes.byref(iid_sl),   ctypes.byref(psl))
        if hr != 0:
            raise OSError(f"CoCreateInstance hr={hr:#010x}")

        # IShellLinkW vtable indices (IUnknown has 3, then IShellLinkW methods):
        vt_ptr = ctypes.cast(ctypes.cast(psl, ctypes.POINTER(ctypes.c_void_p))[0],
                             ctypes.POINTER(ctypes.c_void_p))
        WFT = ctypes.WINFUNCTYPE

        def _sl(idx, *argtypes):
            return WFT(ctypes.c_long, ctypes.c_void_p, *argtypes)(vt_ptr[idx])

        _sl(7,  ctypes.c_wchar_p)(psl.value, description or "")     # SetDescription
        _sl(9,  ctypes.c_wchar_p)(psl.value, working_dir)            # SetWorkingDirectory
        _sl(11, ctypes.c_wchar_p)(psl.value, args)                   # SetArguments
        _sl(20, ctypes.c_wchar_p)(psl.value, pythonw_path)           # SetPath
        if has_icon:
            _sl(17, ctypes.c_wchar_p, ctypes.c_int)(psl.value, icon_path, 0)  # SetIconLocation

        # QI for IPersistFile
        ppf = ctypes.c_void_p()
        qi  = WFT(ctypes.c_long, ctypes.c_void_p,
                  ctypes.POINTER(ctypes.c_byte * 16),
                  ctypes.POINTER(ctypes.c_void_p))(vt_ptr[0])
        hr  = qi(psl.value, ctypes.byref(iid_pf), ctypes.byref(ppf))
        if hr != 0:
            raise OSError(f"QI IPersistFile hr={hr:#010x}")

        pf_vt = ctypes.cast(ctypes.cast(ppf, ctypes.POINTER(ctypes.c_void_p))[0],
                             ctypes.POINTER(ctypes.c_void_p))
        Save  = WFT(ctypes.c_long, ctypes.c_void_p,
                    ctypes.c_wchar_p, ctypes.c_int)(pf_vt[6])
        hr    = Save(ppf.value, shortcut_path, 1)
        if hr != 0:
            raise OSError(f"IPersistFile::Save hr={hr:#010x}")

        # Release both interfaces
        WFT(ctypes.c_ulong, ctypes.c_void_p)(pf_vt[2])(ppf.value)
        WFT(ctypes.c_ulong, ctypes.c_void_p)(vt_ptr[2])(psl.value)
        return
    except Exception:
        pass

    # ── Method 2: win32com ────────────────────────────────────
    try:
        import win32com.client
        shell = win32com.client.Dispatch("WScript.Shell")
        lnk   = shell.CreateShortcut(shortcut_path)
        lnk.TargetPath       = pythonw_path
        lnk.Arguments        = args
        lnk.WorkingDirectory = working_dir
        lnk.Description      = description
        if has_icon:
            lnk.IconLocation = f"{icon_path},0"
        lnk.Save()
        return
    except Exception:
        pass

    # ── Method 3: PowerShell .ps1 ─────────────────────────────
    ps1 = None
    try:
        ps1 = tempfile.mktemp(suffix=".ps1")
        lines = [
            '$ws = New-Object -ComObject WScript.Shell',
            f'$s  = $ws.CreateShortcut("{shortcut_path}")',
            f'$s.TargetPath       = "{pythonw_path}"',
            f'$s.Arguments        = "\\"{target_py}\\""',
            f'$s.WorkingDirectory = "{working_dir}"',
            f'$s.Description      = "{description}"',
        ]
        if has_icon:
            lines.append(f'$s.IconLocation = "{icon_path},0"')
        lines.append('$s.Save()')
        with open(ps1, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        r = subprocess.run(
            ["powershell", "-ExecutionPolicy", "Bypass",
             "-NonInteractive", "-File", ps1],
            capture_output=True, timeout=15)
        if r.returncode == 0:
            return
    except Exception:
        pass
    finally:
        if ps1:
            try: os.unlink(ps1)
            except Exception: pass

    # ── Method 4: cscript VBS (last resort) ──────────────────
    icon_line = f'oLink.IconLocation = "{icon_path},0"\n' if has_icon else ""
    script = (
        f'Set oWS = WScript.CreateObject("WScript.Shell")\n'
        f'Set oLink = oWS.CreateShortcut("{shortcut_path}")\n'
        f'oLink.TargetPath = "{pythonw_path}"\n'
        f'oLink.Arguments = "\\"{target_py}\\""\n'
        f'oLink.WorkingDirectory = "{working_dir}"\n'
        f'oLink.Description = "{description}"\n'
        f'{icon_line}'
        f'oLink.Save\n'
    )
    vbs = tempfile.mktemp(suffix=".vbs")
    try:
        with open(vbs, "w") as fh:
            fh.write(script)
        subprocess.run(["cscript", "//NoLogo", vbs],
                       capture_output=True, timeout=15)
    finally:
        try: os.unlink(vbs)
        except Exception: pass


class ScrollableFrame(tk.Frame):
    """Canvas + Scrollbar wrapper. Child widgets go in .inner."""

    def __init__(self, parent, bg=BG_PANEL, **kwargs):
        super().__init__(parent, bg=bg, **kwargs)

        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self._vsb    = ttk.Scrollbar(self, orient="vertical",
                                     command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=self._vsb.set)

        self._vsb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self.inner  = tk.Frame(self._canvas, bg=bg)
        self._wid   = self._canvas.create_window((0, 0), window=self.inner,
                                                  anchor="nw")

        self.inner.bind("<Configure>",   self._on_inner_change)
        self._canvas.bind("<Configure>", self._on_canvas_resize)
        self._canvas.bind("<Enter>",     self._attach_wheel)
        self._canvas.bind("<Leave>",     self._detach_wheel)

    def _on_canvas_resize(self, event):
        self._canvas.itemconfig(self._wid, width=event.width)
        self._refresh_scroll()

    def _on_inner_change(self, event=None):
        self._refresh_scroll()

    def _refresh_scroll(self):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))
        inner_h  = self.inner.winfo_reqheight()
        canvas_h = self._canvas.winfo_height()
        if inner_h <= canvas_h:
            self._vsb.pack_forget()
        else:
            if not self._vsb.winfo_ismapped():
                self._vsb.pack(side="right", fill="y")

    def scroll_to_top(self):
        self._canvas.yview_moveto(0)

    def _attach_wheel(self, _=None):
        self._canvas.bind_all("<MouseWheel>", self._wheel)
        self._canvas.bind_all("<Button-4>",   self._wheel)
        self._canvas.bind_all("<Button-5>",   self._wheel)

    def _detach_wheel(self, _=None):
        self._canvas.unbind_all("<MouseWheel>")
        self._canvas.unbind_all("<Button-4>")
        self._canvas.unbind_all("<Button-5>")

    def _wheel(self, event):
        if   event.num == 4: self._canvas.yview_scroll(-1, "units")
        elif event.num == 5: self._canvas.yview_scroll( 1, "units")
        else: self._canvas.yview_scroll(int(-1 * event.delta / 120), "units")


# ─────────────────────────────────────────────────────────────
#  KeplerInstaller
# ─────────────────────────────────────────────────────────────
class KeplerInstaller(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Kepler Installer")
        self.configure(bg=BG_PANEL)
        self.resizable(True, True)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        # Set window icon — withdraw first, then set via tk.PhotoImage (PNG)
        # for reliable display; fall back to iconbitmap(.ico) for Windows
        self.withdraw()
        _here = os.path.dirname(os.path.abspath(__file__))
        _icon_set = False
        for _rel in [os.path.join(_here, "..", "..", "icon.png"),
                     os.path.join(_here, "..", "icon.png"),
                     os.path.join(_here, "icon.png")]:
            _rel = os.path.abspath(_rel)
            if os.path.isfile(_rel):
                try:
                    self._tk_icon = tk.PhotoImage(file=_rel)
                    self.wm_iconphoto(True, self._tk_icon)
                    _icon_set = True
                    break
                except Exception:
                    pass
        if not _icon_set:
            for _rel in [os.path.join(_here, "..", "..", "icon.ico"),
                         os.path.join(_here, "..", "icon.ico"),
                         os.path.join(_here, "icon.ico")]:
                _rel = os.path.abspath(_rel)
                if os.path.isfile(_rel):
                    try: self.iconbitmap(default=_rel); break
                    except Exception: pass
        self.deiconify()

        # Width: fixed comfortable reading width
        # Height: fitted per-page by _fit_to_content() after each page renders
        self.update_idletasks()
        self._sw = self.winfo_screenwidth()
        self._sh = self.winfo_screenheight()
        self._win_w = max(780, min(920, int(self._sw * 0.62)))
        self.resizable(True, True)
        self.minsize(680, 300)

        self.current_step            = 0
        self.install_dir             = tk.StringVar(value=INSTALL_DIR_DEFAULT)
        self.create_desktop_shortcut = tk.BooleanVar(value=True)
        self.create_startmenu        = tk.BooleanVar(value=True)
        self.add_to_path             = tk.BooleanVar(value=True)
        self._python_cmd             = None
        self._missing_pkgs           = []

        self.steps = [
            self._page_welcome,
            self._page_warnings,
            self._page_checks,
            self._page_options,
            self._page_install,
            self._page_done,
        ]

        self._apply_styles()
        self._build_chrome()
        # Initial geometry — will be resized to fit after first page renders
        self.geometry(f"{self._win_w}x600")
        self._show_step(0)

    # ── ttk styles ───────────────────────────────────────────
    def _apply_styles(self):
        s = ttk.Style()
        try: s.theme_use("clam")
        except Exception: pass
        s.configure("K.Horizontal.TProgressbar",
                    troughcolor=BG_RAISED, background=ACCENT,
                    lightcolor=ACCENT, darkcolor=ACCENT,
                    bordercolor=BORDER)
        s.configure("Vertical.TScrollbar",
                    background=BG_RAISED, troughcolor=BG_PANEL,
                    arrowcolor=FG_MID)

    # ── Chrome: fixed header + scrollable content + fixed nav ─
    def _build_chrome(self):
        # ── Header ──
        hdr = self._hdr_frame = tk.Frame(self, bg=BG_PANEL)
        hdr.pack(fill="x")

        # Show real icon; fallback to drawn planet if unavailable
        _icon_shown = False
        try:
            from PIL import Image, ImageTk
            _here = os.path.dirname(os.path.abspath(__file__))
            for _rel in [os.path.join(_here, "..", "..", "icon.ico"),
                         os.path.join(_here, "..", "icon.ico"),
                         os.path.join(_here, "icon.ico")]:
                if os.path.isfile(_rel):
                    _pil = Image.open(_rel).resize((48, 48), Image.LANCZOS).convert("RGBA")
                    self._hdr_icon = ImageTk.PhotoImage(_pil)
                    tk.Label(hdr, image=self._hdr_icon, bg=BG_PANEL).pack(
                        side="left", padx=(14, 8), pady=10)
                    _icon_shown = True
                    break
        except Exception:
            pass
        if not _icon_shown:
            planet = tk.Canvas(hdr, width=52, height=52, bg=BG_PANEL, highlightthickness=0)
            planet.pack(side="left", padx=(14, 8), pady=10)
            planet.create_oval(4,  4, 48, 48, fill="#e8760a", outline="#b45309", width=2)
            planet.create_oval(8, 8, 44, 44, fill="#c05a05", outline="")
            planet.create_oval(0, 17, 52, 35, outline="#92400e", width=2, fill="")

        tf = tk.Frame(hdr, bg=BG_PANEL)
        tf.pack(side="left", pady=10)
        tk.Label(tf, text="Kepler", bg=BG_PANEL, fg=ACCENT,
                 font=("Consolas", 18, "bold")).pack(anchor="w")
        tk.Label(tf,
                 text="Planetary Image Processing Suite  ·  Installer v" + KEPLER_VERSION,
                 bg=BG_PANEL, fg=FG_DIM,
                 font=("Consolas", 9)).pack(anchor="w")

        self.step_var = tk.StringVar(value="")
        tk.Label(hdr, textvariable=self.step_var, bg=BG_PANEL, fg=FG_DIM,
                 font=("Consolas", 9), justify="right").pack(side="right", padx=16)

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        # ── Scrollable content ──
        self._sf     = ScrollableFrame(self, bg=BG_PANEL)
        self._sf.pack(fill="both", expand=True)
        self.content = self._sf.inner

        # ── Nav bar ──
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")
        nav = self._nav_frame = tk.Frame(self, bg=BG_PANEL)
        nav.pack(fill="x")

        self.btn_back = tk.Button(
            nav, text="◀  Back", command=self._back,
            bg=BG_RAISED, fg=FG_MID, font=("Consolas", 10),
            relief="flat", cursor="hand2", padx=16, pady=8,
            activebackground=SEL_BG, activeforeground=FG_BRIGHT
        )
        self.btn_back.pack(side="left", padx=(18, 6), pady=10)

        self.btn_next = tk.Button(
            nav, text="Next  ▶", command=self._next,
            bg=ACCENT, fg="white", font=("Consolas", 10, "bold"),
            relief="flat", cursor="hand2", padx=22, pady=8,
            activebackground="#075985", activeforeground="white"
        )
        self.btn_next.pack(side="right", padx=(6, 18), pady=10)

        self.btn_cancel = tk.Button(
            nav, text="Cancel", command=self._on_close,
            bg=BG_RAISED, fg=ACCENT_R, font=("Consolas", 9),
            relief="flat", cursor="hand2", padx=12, pady=8,
            activebackground=SEL_BG, activeforeground=ACCENT_R
        )
        self.btn_cancel.pack(side="right", padx=4, pady=10)

    # ── Navigation ───────────────────────────────────────────
    def _clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()
        self._sf.scroll_to_top()

    def _show_step(self, idx):
        self._clear_content()
        self.current_step = idx
        names = ["Welcome", "Warnings", "System Check",
                 "Options", "Installing", "Complete"]
        self.step_var.set(f"Step {idx+1} of {len(names)}  ·  {names[idx]}")
        self.btn_back.configure(state="normal" if idx > 0 else "disabled")
        self.steps[idx]()
        self.content.update_idletasks()
        self._sf._refresh_scroll()
        self.after(10, self._fit_to_content)

    def _fit_to_content(self):
        """Resize window to exactly fit the current page content.
        Called after each page renders so there is no dead space.
        """
        self.update_idletasks()
        # Height of chrome = header + top-border + bottom-border + nav
        chrome_h = (self._hdr_frame.winfo_reqheight() + 2 +
                    self._nav_frame.winfo_reqheight() + 2)
        content_h = self.content.winfo_reqheight()
        total_h = chrome_h + content_h + 4   # small breathing room
        # Clamp to screen
        max_h = int(self._sh * 0.92)
        h = max(300, min(total_h, max_h))
        w = self._win_w
        x = (self._sw - w) // 2
        y = max(20, (self._sh - h) // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _next(self):
        if self.current_step < len(self.steps) - 1:
            self._show_step(self.current_step + 1)

    def _back(self):
        if self.current_step > 0:
            self._show_step(self.current_step - 1)

    def _on_close(self):
        if self.current_step == 5:
            self.destroy()
        elif messagebox.askyesno("Cancel",
                "Are you sure you want to cancel the Kepler installation?"):
            self.destroy()

    # ── Shared widget helpers ────────────────────────────────
    def _pad_frame(self):
        f = tk.Frame(self.content, bg=BG_PANEL, padx=32, pady=18)
        f.pack(fill="both", expand=True)
        return f

    def _heading(self, parent, text, color=ACCENT):
        tk.Label(parent, text=text, bg=BG_PANEL, fg=color,
                 font=("Consolas", 14, "bold"),
                 anchor="w", wraplength=820, justify="left"
                 ).pack(fill="x", pady=(0, 8))

    def _para(self, parent, text, color=FG_MID, size=10):
        tk.Label(parent, text=text, bg=BG_PANEL, fg=color,
                 font=("Consolas", size), justify="left",
                 wraplength=820, anchor="w"
                 ).pack(fill="x", pady=3)

    def _divider(self, parent):
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", pady=10)

    def _box(self, parent, text, color=ACCENT, bg=BG_CARD):
        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.pack(fill="x", pady=5)
        inner = tk.Frame(outer, bg=bg, padx=16, pady=12)
        inner.pack(fill="both", expand=True)
        tk.Label(inner, text=text, bg=bg, fg=color,
                 font=("Consolas", 10), justify="left",
                 wraplength=800, anchor="w"
                 ).pack(fill="x")
        return inner

    def _bullet(self, parent, text, color=ACCENT_G):
        tk.Label(parent, text="   " + text, bg=BG_PANEL, fg=color,
                 font=("Consolas", 10), anchor="w",
                 wraplength=820
                 ).pack(fill="x", pady=2)

    # ══════════════════════════════════════════════════════════
    #  PAGE 0 — Welcome
    # ══════════════════════════════════════════════════════════
    def _page_welcome(self):
        self.btn_next.configure(text="Begin  ▶", state="normal",
                                bg=ACCENT, fg="white")
        p = self._pad_frame()

        self._heading(p, "Welcome to the Kepler Installer")
        self._para(p,
            "This wizard will install Kepler — a professional planetary image "
            "processing suite — on your Windows system.\n\n"
            "Kepler provides wavelet sharpening, FFT denoising, RGB colour "
            "balance, and deringing tools designed for planetary and deep-sky "
            "astronomy imaging."
        )
        self._divider(p)
        self._para(p, "This installer will:", color=FG_BRIGHT)
        for item in [
            "✔  Check for Python 3.8+  (install automatically if missing)",
            "✔  Check for NumPy, Pillow, SciPy, scikit-image  (install if missing)",
            "✔  Copy Kepler files to your chosen folder",
            "✔  Create a Desktop shortcut",
            "✔  Add Kepler to the Start Menu",
            "✔  Add Kepler to your system PATH",
        ]:
            self._bullet(p, item)
        self._divider(p)

        if not is_admin():
            self._box(p,
                "⚠  NOT RUNNING AS ADMINISTRATOR\n\n"
                "For best results, close this window, right-click install.bat "
                "and choose  \"Run as administrator\".\n\n"
                "Without admin rights some features (system-wide PATH, "
                "all-users shortcuts) may be limited.  "
                "You can still continue for a standard user-level install.",
                color=ACCENT_O, bg=BOX_ORANGE
            )
        else:
            self._box(p,
                "✔  Running as Administrator — full installation available.",
                color=ACCENT_G, bg=BOX_GREEN
            )

    # ══════════════════════════════════════════════════════════
    #  PAGE 1 — Warnings
    # ══════════════════════════════════════════════════════════
    def _page_warnings(self):
        self.btn_next.configure(text="I Understand  ▶", state="normal",
                                bg=ACCENT, fg="white")
        p = self._pad_frame()

        self._heading(p, "⚠  Important — Please Read Before Continuing",
                      color=ACCENT_O)

        self._box(p,
            "WINDOWS SMARTSCREEN  —  \"Windows protected your PC\"\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "You may see this warning when running install.bat or the Python "
            "installer.  It appears because Kepler is new, independently-released "
            "software not yet in Microsoft's database.\n\n"
            "This does NOT mean the software is harmful.\n\n"
            "HOW TO BYPASS:\n"
            "  1.  Click \"More info\"  (small grey link under the warning)\n"
            "  2.  A  \"Run anyway\"  button will appear — click it.",
            color=ACCENT_O, bg=BOX_ORANGE
        )
        self._box(p,
            "WINDOWS UAC PROMPT  —  \"Allow this app to make changes?\"\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "If Python needs to be installed, Windows will ask for permission "
            "via a UAC dialog.  Click  \"Yes\"  to allow it.  "
            "Without this, Python cannot be installed automatically.",
            color=ACCENT, bg=BOX_BLUE
        )
        self._box(p,
            "PYTHON INSTALLER  —  CRITICAL CHECKBOX\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "If the Python installer opens, you MUST tick this checkbox "
            "on the very FIRST screen before clicking anything else:\n\n"
            "        ☑  Add python.exe to PATH\n\n"
            "It appears at the BOTTOM of the first screen.  "
            "Missing it means Kepler won't launch from shortcuts or the terminal.",
            color=ACCENT_G, bg=BOX_GREEN
        )
        self._box(p,
            "ANTIVIRUS / WINDOWS DEFENDER\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "pip.exe (the Python package downloader) may be flagged by some "
            "antivirus tools — this is a known false positive.  "
            "If prompted, choose  \"Allow\"  or  \"Exclude\"  for pip.exe.",
            color=FG_MID, bg=BOX_GREY
        )
        self._box(p,
            "ALL SOURCE CODE IS READABLE\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Every Kepler file is plain Python text — nothing compiled, nothing "
            "hidden.  After installation you can open every file in the "
            "installation folder with any text editor.",
            color=FG_DIM, bg=BOX_GREY
        )

    # ══════════════════════════════════════════════════════════
    #  PAGE 2 — System Checks
    # ══════════════════════════════════════════════════════════
    def _page_checks(self):
        self.btn_next.configure(text="Continue  ▶", state="disabled",
                                bg=ACCENT, fg="white")
        p = self._pad_frame()

        self._heading(p, "System Compatibility Check")
        self._para(p, "Scanning your system for required components…",
                   color=FG_MID)
        self._divider(p)

        cf = tk.Frame(p, bg=BG_PANEL)
        cf.pack(fill="x")

        self._check_labels = {}
        rows = [
            ("os",       "Operating System",       ""),
            ("admin",    "Administrator Rights",    ""),
            ("python",   "Python 3.8+",             ""),
            ("pip",      "pip  (package manager)",  ""),
            ("numpy",    "NumPy",                   "scientific arrays"),
            ("pil",      "Pillow",                  "image file I/O"),
            ("scipy",    "SciPy",                   "FFT processing"),
            ("tifffile", "tifffile",                "16-bit TIFF support"),
            ("skimage",  "scikit-image",            "CLAHE contrast enhancement"),
            ("tkinter",  "tkinter",                 "GUI toolkit (this window)"),
        ]
        for key, label, note in rows:
            outer = tk.Frame(cf, bg=BORDER, padx=1, pady=1)
            outer.pack(fill="x", pady=2)
            row = tk.Frame(outer, bg=BG_CARD, padx=14, pady=9)
            row.pack(fill="both", expand=True)
            tk.Label(row, text=label, bg=BG_CARD, fg=FG_BRIGHT,
                     font=("Consolas", 10), width=26, anchor="w").pack(side="left")
            if note:
                tk.Label(row, text=f"  ({note})", bg=BG_CARD, fg=FG_DIM,
                         font=("Consolas", 9)).pack(side="left")
            lbl = tk.Label(row, text="checking…", bg=BG_CARD, fg=FG_DIM,
                           font=("Consolas", 10, "bold"))
            lbl.pack(side="right", padx=8)
            self._check_labels[key] = lbl

        self._result_lbl = tk.Label(p, text="", bg=BG_PANEL, fg=ACCENT_G,
                                    font=("Consolas", 10), anchor="w")
        self._result_lbl.pack(fill="x", pady=(12, 0))

        threading.Thread(target=self._run_checks, daemon=True).start()

    def _setchk(self, key, text, color):
        if key in self._check_labels:
            self._check_labels[key].configure(text=text, fg=color)

    def _run_checks(self):
        time.sleep(0.2)
        # platform.release() returns "10" for both Win10 and Win11.
        # Use the build number (platform.version()) to distinguish:
        # Windows 11 = build 22000+, Windows 10 = build 10240–19999
        try:
            _build = int(platform.version().split(".")[2])
        except Exception:
            _build = 0
        if _build >= 22000:
            _win_name = "Windows 11"
        elif _build >= 10240:
            _win_name = "Windows 10"
        else:
            _win_name = f"Windows {platform.release()}"
        # Append edition if available (Pro, Home, etc.)
        try:
            import winreg
            _key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
            _edition, _ = winreg.QueryValueEx(_key, "EditionID")
            winreg.CloseKey(_key)
            _win_name += f" {_edition}"
        except Exception:
            pass
        self.after(0, lambda wn=_win_name: self._setchk("os",
            f"{wn}  ✔", ACCENT_G))

        adm = is_admin()
        self.after(80,  lambda: self._setchk("admin",
            "Administrator  ✔" if adm else "Standard user  ⚠",
            ACCENT_G if adm else ACCENT_O))

        py_cmd, py_ver = find_python()
        self._python_cmd = py_cmd
        self.after(160, lambda: self._setchk("python",
            f"{py_ver}  ✔" if py_cmd else "Not found — will install",
            ACCENT_G if py_cmd else ACCENT_O))

        pip_ok = False
        if py_cmd:
            try:
                subprocess.check_output([py_cmd, "-m", "pip", "--version"],
                                        stderr=subprocess.STDOUT, timeout=10)
                pip_ok = True
            except Exception:
                pass
        self.after(250, lambda: self._setchk("pip",
            "Available  ✔" if pip_ok else "Will be installed",
            ACCENT_G if pip_ok else ACCENT_O))

        self._missing_pkgs = []
        pkg_map = {"numpy":    ("numpy",     "numpy"),
                   "pil":      ("PIL",       "Pillow"),
                   "scipy":    ("scipy",     "scipy"),
                   "tifffile": ("tifffile",  "tifffile"),
                   "skimage":  ("skimage",   "scikit-image")}
        for delay, (key, (imp, pip_name)) in zip(
                [340, 430, 520, 610, 700], pkg_map.items()):
            ok = check_package(imp) if py_cmd else False
            if ok:
                self.after(delay, lambda k=key: self._setchk(k, "Installed  ✔", ACCENT_G))
            else:
                self.after(delay, lambda k=key: self._setchk(k,
                    "Missing — will install", ACCENT_O))
                self._missing_pkgs.append(pip_name)

        try:
            import tkinter as _t
            tk_ok = True
        except ImportError:
            tk_ok = False
        self.after(720, lambda: self._setchk("tkinter",
            "Available  ✔" if tk_ok else "Missing! Re-install Python",
            ACCENT_G if tk_ok else ACCENT_R))

        self.after(900, self._checks_done)

    def _checks_done(self):
        self.btn_next.configure(state="normal")
        needs = ([] if self._python_cmd else ["Python"]) + self._missing_pkgs
        if needs:
            self._result_lbl.configure(
                text=f"⚠  Will be installed automatically: {', '.join(needs)}",
                fg=ACCENT_O)
        else:
            self._result_lbl.configure(
                text="✔  All requirements satisfied — installation will be quick.",
                fg=ACCENT_G)
        self.content.update_idletasks()
        self._sf._refresh_scroll()

    # ══════════════════════════════════════════════════════════
    #  PAGE 3 — Options
    # ══════════════════════════════════════════════════════════
    def _page_options(self):
        self.btn_next.configure(text="Install  ▶", state="normal",
                                bg=ACCENT, fg="white")
        p = self._pad_frame()

        self._heading(p, "Installation Options")
        self._para(p, "Installation Folder:", color=FG_BRIGHT)

        dir_f = tk.Frame(p, bg=BG_PANEL)
        dir_f.pack(fill="x", pady=5)
        tk.Entry(dir_f, textvariable=self.install_dir,
                 bg=BG_CARD, fg=FG_BRIGHT, insertbackground=ACCENT,
                 font=("Consolas", 10), relief="flat",
                 highlightthickness=1, highlightbackground=BORDER,
                 highlightcolor=ACCENT
                 ).pack(side="left", fill="x", expand=True, padx=(0, 8))
        tk.Button(dir_f, text="Browse…", command=self._browse_dir,
                  bg=BG_RAISED, fg=ACCENT, font=("Consolas", 9),
                  relief="flat", cursor="hand2", padx=10, pady=5,
                  activebackground=SEL_BG).pack(side="left")

        self._divider(p)
        self._para(p, "Options:", color=FG_BRIGHT)
        for var, lbl in [
            (self.create_desktop_shortcut, "Create Desktop shortcut"),
            (self.create_startmenu,        "Add Kepler to the Start Menu"),
            (self.add_to_path,
             "Add Kepler to system PATH  "
             "(allows typing 'kepler' in any terminal)"),
        ]:
            tk.Checkbutton(p, text=lbl, variable=var,
                           bg=BG_PANEL, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                           activebackground=BG_PANEL, activeforeground=ACCENT,
                           font=("Consolas", 10),
                           highlightthickness=0).pack(anchor="w", pady=4)

        self._divider(p)
        self._box(p,
            "Estimated disk space:\n\n"
            "  Kepler application files . . . . . .   ~1 MB\n"
            "  Python 3.11  (if not installed) . . .  ~70 MB\n"
            "  NumPy        (if not installed) . . .  ~20 MB\n"
            "  Pillow       (if not installed) . . .   ~8 MB\n"
            "  SciPy        (if not installed) . . .  ~35 MB\n"
            "  tifffile     (if not installed) . . .   ~1 MB\n"
            "  scikit-image (if not installed) . . .  ~10 MB\n"
            "  ─────────────────────────────────────────────\n"
            "  Total (worst case) . . . . . . . . .  ~145 MB",
            color=FG_MID, bg=BG_CARD
        )

    def _browse_dir(self):
        d = filedialog.askdirectory(
            title="Choose Installation Folder",
            initialdir=os.path.dirname(self.install_dir.get())
        )
        if d:
            self.install_dir.set(os.path.join(d, "Kepler"))

    # ══════════════════════════════════════════════════════════
    #  PAGE 4 — Installing
    # ══════════════════════════════════════════════════════════
    def _page_install(self):
        self.btn_next.configure(state="disabled")
        self.btn_back.configure(state="disabled")
        self.btn_cancel.configure(state="disabled")

        outer = tk.Frame(self.content, bg=BG_PANEL, padx=32, pady=18)
        outer.pack(fill="both", expand=True)

        self._heading(outer, "Installing Kepler…")

        self.prog_label = tk.Label(outer, text="Starting…",
                                   bg=BG_PANEL, fg=ACCENT,
                                   font=("Consolas", 10))
        self.prog_label.pack(anchor="w", pady=(4, 2))

        self.prog_bar = ttk.Progressbar(
            outer, style="K.Horizontal.TProgressbar", maximum=100)
        self.prog_bar.pack(fill="x", pady=(0, 10))

        log_outer = tk.Frame(outer, bg=BORDER, padx=1, pady=1)
        log_outer.pack(fill="both", expand=True)
        log_inner = tk.Frame(log_outer, bg="#1e1e2e")
        log_inner.pack(fill="both", expand=True)

        self.log_text = tk.Text(
            log_inner, bg="#1e1e2e", fg="#a6e3a1",
            font=("Consolas", 9), relief="flat",
            state="disabled", wrap="word",
            insertbackground=ACCENT
        )
        log_sb = ttk.Scrollbar(log_inner, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_sb.set)
        log_sb.pack(side="right", fill="y")
        self.log_text.pack(fill="both", expand=True, padx=6, pady=6)

        threading.Thread(target=self._do_install, daemon=True).start()

    def _log(self, msg):
        def _up():
            self.log_text.configure(state="normal")
            self.log_text.insert("end", msg + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.after(0, _up)

    def _set_prog(self, pct, label=""):
        def _up():
            self.prog_bar["value"] = pct
            if label:
                self.prog_label.configure(text=label)
        self.after(0, _up)

    def _do_install(self):
        install_dir = self.install_dir.get()
        script_dir  = os.path.dirname(os.path.abspath(__file__))
        kepler_root = script_dir
        for _ in range(5):
            if os.path.exists(os.path.join(kepler_root, "main.py")):
                break
            kepler_root = os.path.dirname(kepler_root)

        try:
            # 1. Find / install Python
            self._set_prog(5, "Checking Python…")
            py_cmd, py_ver = find_python()

            if not py_cmd:
                self._log("Python not found.  Trying winget…")
                self._set_prog(10, "Installing Python via winget…")
                rc, _ = run_cmd(
                    ["winget", "install", PYTHON_WINGET,
                     "--accept-package-agreements",
                     "--accept-source-agreements", "--silent"],
                    self._log
                )
                if rc != 0:
                    self._log("winget failed.  Downloading Python installer…")
                    self._log(">>> IMPORTANT: tick 'Add python.exe to PATH' <<<")
                    tmp = tempfile.mktemp(suffix=".exe")
                    try:
                        urllib.request.urlretrieve(PYTHON_URL, tmp)
                        subprocess.run([tmp, "/passive",
                                        "InstallAllUsers=0",
                                        "PrependPath=1",
                                        "Include_test=0"])
                        os.unlink(tmp)
                    except Exception as e:
                        self._log(f"Download failed: {e}")
                        self.after(0, lambda: messagebox.showerror(
                            "Python Required",
                            "Could not install Python automatically.\n\n"
                            "Please install Python 3.11 from:\n"
                            "  https://www.python.org/downloads/\n\n"
                            "IMPORTANT: tick  'Add python.exe to PATH'\n"
                            "then re-run this installer."
                        ))
                        self.after(0, lambda: self.btn_cancel.configure(
                            state="normal"))
                        return

                # Re-search including newly installed locations
                py_cmd, py_ver = find_python()
                if not py_cmd:
                    self._log("Python still not found in PATH. "
                              "Please restart the installer.")
                    self.after(0, lambda: messagebox.showwarning(
                        "Restart Required",
                        "Python was installed but this installer cannot "
                        "see it yet because Windows PATH hasn't updated.\n\n"
                        "Please close and re-run this installer."
                    ))
                    self.after(0, lambda: self.btn_cancel.configure(
                        state="normal"))
                    return

            self._log(f"Python {py_ver or 'ready'} — OK")
            self._python_cmd = py_cmd
            self._set_prog(25, "Python ready.")

            # 2. Upgrade pip
            self._set_prog(28, "Upgrading pip…")
            run_cmd([py_cmd, "-m", "pip", "install",
                     "--upgrade", "pip", "--quiet"], self._log)

            # 3. Install missing packages
            missing = self._missing_pkgs or []
            total   = max(len(missing), 1)
            for i, pkg in enumerate(missing):
                pct = 30 + int(i / total * 35)
                self._set_prog(pct, f"Installing {pkg}…")
                self._log(f"pip install {pkg}")
                rc, _ = run_cmd(
                    [py_cmd, "-m", "pip", "install", pkg, "--upgrade"],
                    self._log
                )
                self._log(f"  {'OK' if rc == 0 else 'WARNING: install failed'}")
            self._set_prog(65, "Libraries ready.")

            # 4. Copy Kepler files
            self._set_prog(68, f"Copying files to {install_dir}…")
            os.makedirs(install_dir, exist_ok=True)
            for fname in ["main.py", "app.py", "processing.py",
                          "requirements.txt"]:
                src = os.path.join(kepler_root, fname)
                dst = os.path.join(install_dir, fname)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    self._log(f"  Copied {fname}")
                else:
                    self._log(f"  WARNING: {fname} not found at {src}")

            # Copy icon if present
            for icon_name in ["icon.png", "icon.ico", "kepler.png", "kepler.ico"]:
                src = os.path.join(kepler_root, icon_name)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(install_dir, icon_name))
                    self._log(f"  Copied {icon_name}")

            self._set_prog(75, "Files installed.")

            # 5. Launcher batch — resolve pythonw from the found python path
            py_dir = os.path.dirname(os.path.abspath(py_cmd))
            pythonw = os.path.join(py_dir, "pythonw.exe")
            if not os.path.isfile(pythonw):
                pythonw = py_cmd  # fall back to python.exe (shows console)
            launcher = os.path.join(install_dir, "Kepler.bat")
            with open(launcher, "w") as f:
                f.write("@echo off\n")
                f.write(f'cd /d "{install_dir}"\n')
                f.write(f'start "" "{pythonw}" "{install_dir}\\main.py" %*\n')
            self._log(f"  Launcher: {launcher}  (using {pythonw})")
            self._set_prog(80, "Launcher created.")

            # 6. Shortcuts — run on main thread (COM STA requirement)
            icon_path = os.path.abspath(os.path.join(install_dir, "icon.ico"))
            icon_arg  = icon_path if os.path.isfile(icon_path) else ""
            self._log(f"  Icon: {icon_path}  found={os.path.isfile(icon_path)}")

            do_desktop  = self.create_desktop_shortcut.get()
            do_startmenu = self.create_startmenu.get()
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            sm = os.path.join(
                os.environ.get("APPDATA", ""),
                r"Microsoft\Windows\Start Menu\Programs\Kepler"
            )
            main_py = os.path.join(install_dir, "main.py")

            import threading
            _sc_done = threading.Event()

            def _make_shortcuts():
                try:
                    if do_desktop:
                        create_shortcut(main_py,
                            os.path.join(desktop, "Kepler.lnk"),
                            install_dir, "Kepler — Planetary Image Processing",
                            icon_arg, pythonw_path=pythonw)
                        self._log(f"  Desktop shortcut created{'  (with icon)' if icon_arg else '  (no icon)'}.")
                    if do_startmenu:
                        os.makedirs(sm, exist_ok=True)
                        create_shortcut(main_py,
                            os.path.join(sm, "Kepler.lnk"),
                            install_dir, "Kepler — Planetary Image Processing",
                            icon_arg, pythonw_path=pythonw)
                        self._log(f"  Start Menu entry created{'  (with icon)' if icon_arg else ''}.")
                finally:
                    _sc_done.set()

            # Schedule on main thread then wait (COM STA objects must run on main thread)
            self.after(0, _make_shortcuts)
            _sc_done.wait(timeout=15)
            self._set_prog(88, "Shortcuts created.")

            # 7. PATH
            if self.add_to_path.get():
                ok = add_to_path_registry(install_dir)
                self._log("  PATH updated." if ok
                          else "  PATH update skipped (try running as Administrator).")

            # 8. Uninstaller
            with open(os.path.join(install_dir, "uninstall.bat"), "w") as f:
                f.write("@echo off\n")
                f.write(f'echo Removing Kepler from {install_dir}...\n')
                f.write(f'rd /s /q "{install_dir}"\n')
                f.write("echo Done.\npause\n")
            self._log("  Uninstaller written.")

            self._pythonw_path = pythonw   # stored for "Launch on Finish"
            self._set_prog(100, "Installation complete!")
            self._log(f"\n✔  Kepler installed to: {install_dir}")
            self._log("   Launch from Desktop or Start Menu.")
            self.after(900, self._next)

        except Exception as e:
            import traceback
            self._log(f"\nFATAL ERROR: {e}\n{traceback.format_exc()}")
            self.after(0, lambda: messagebox.showerror(
                "Installation Failed", f"An error occurred:\n\n{e}"))
            self.after(0, lambda: self.btn_cancel.configure(state="normal"))

    # ══════════════════════════════════════════════════════════
    #  PAGE 5 — Done
    # ══════════════════════════════════════════════════════════
    def _page_done(self):
        self.btn_back.configure(state="disabled")
        self.btn_cancel.configure(state="disabled")
        self.btn_next.configure(text="Finish", state="normal",
                                bg=ACCENT_G, fg="white",
                                activebackground="#0d6b32",
                                activeforeground="white")
        p = self._pad_frame()

        self._heading(p, "✔  Kepler Successfully Installed!", color=ACCENT_G)
        self._para(p, "Installed to:", color=FG_MID)
        self._para(p, f"   {self.install_dir.get()}", color=ACCENT)
        self._divider(p)

        self._box(p,
            "How to launch Kepler:\n\n"
            "  •  Double-click the  Kepler  icon on your Desktop\n"
            "  •  Start  ›  All Programs  ›  Kepler  ›  Kepler\n"
            "  •  Open a terminal and type:  Kepler\n\n"
            "Supported image formats:  PNG  ·  JPEG  ·  TIFF  ·  BMP",
            color=ACCENT_G, bg=BOX_GREEN
        )
        self._divider(p)
        self._box(p,
            "To uninstall Kepler in future:\n\n"
            f"  Run:  {self.install_dir.get()}\\uninstall.bat\n\n"
            "This removes all Kepler files.  Python and its libraries "
            "are left in place (they may be used by other software).",
            color=FG_DIM, bg=BOX_GREY
        )
        self._divider(p)

        launch_var = tk.BooleanVar(value=True)
        tk.Checkbutton(p, text="Launch Kepler when I click Finish",
                       variable=launch_var,
                       bg=BG_PANEL, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                       activebackground=BG_PANEL, font=("Consolas", 10),
                       highlightthickness=0).pack(anchor="w", pady=(4, 0))

        def finish():
            if launch_var.get():
                py = getattr(self, "_pythonw_path", None) \
                     or getattr(self, "_python_cmd", None) \
                     or "pythonw.exe"
                main_py = os.path.join(self.install_dir.get(), "main.py")
                if os.path.exists(main_py):
                    subprocess.Popen([py, main_py],
                                     cwd=self.install_dir.get(),
                                     creationflags=0x00000008)  # DETACHED_PROCESS
            self.destroy()

        self.btn_next.configure(command=finish)


# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if WINDOWS:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = KeplerInstaller()
    app.mainloop()

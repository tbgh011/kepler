"""
processing.py - Core image processing algorithms for PlanetarySharp Pro
"""

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, median_filter, uniform_filter, sobel
from scipy.signal import fftconvolve
import threading


# ─────────────────────────────────────────────────────────────
#  Utility
# ─────────────────────────────────────────────────────────────

def pil_to_array(img: Image.Image) -> np.ndarray:
    """Convert PIL Image to float32 array [0,1], preserving 16-bit depth."""
    raw = np.array(img)
    if raw.dtype == np.uint16:
        return (raw.astype(np.float32) / 65535.0)
    elif raw.dtype == np.uint8:
        return (raw.astype(np.float32) / 255.0)
    else:
        # float or other — normalise to 0-1
        r = raw.astype(np.float32)
        mn, mx = r.min(), r.max()
        return (r - mn) / (mx - mn + 1e-9) if mx > mn else r


def array_to_pil(arr: np.ndarray) -> Image.Image:
    """Convert float32 array [0,1] back to PIL Image."""
    clipped = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    return Image.fromarray(clipped, mode="RGB")


def luminance(arr: np.ndarray) -> np.ndarray:
    """Return luminance channel from RGB float array."""
    return 0.299 * arr[..., 0] + 0.587 * arr[..., 1] + 0.114 * arr[..., 2]


# ─────────────────────────────────────────────────────────────
#  Oklab color space  (same color model WaveSharp 3 uses)
#  Perceptually uniform — sharpening on L only avoids colour
#  fringing and gives more natural contrast enhancement.
# ─────────────────────────────────────────────────────────────

def _linear(c: np.ndarray) -> np.ndarray:
    """sRGB → linear RGB (vectorised)."""
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _srgb(c: np.ndarray) -> np.ndarray:
    """Linear RGB → sRGB (vectorised)."""
    return np.where(c <= 0.0031308, c * 12.92,
                    1.055 * np.power(np.clip(c, 0, None), 1.0 / 2.4) - 0.055)


def rgb_to_oklab(rgb: np.ndarray) -> np.ndarray:
    """
    Convert float32/64 RGB [0,1] → Oklab [L∈0-1, a,b∈≈-0.5..0.5].
    Returns array of same shape with channels (L, a, b).
    """
    r, g, b = _linear(rgb[..., 0]), _linear(rgb[..., 1]), _linear(rgb[..., 2])
    # RGB → LMS (Oklab M1 matrix)
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    # cube root
    l_, m_, s_ = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    # LMS → Lab (Oklab M2 matrix)
    L =  0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_
    a =  1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    bch= 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    return np.stack([L, a, bch], axis=-1)


def oklab_to_rgb(lab: np.ndarray) -> np.ndarray:
    """Convert Oklab → float RGB [0,1]."""
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    r =  4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bch= -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return np.clip(np.stack([_srgb(r), _srgb(g), _srgb(bch)], axis=-1), 0.0, 1.0)


# ─────────────────────────────────────────────────────────────
#  À trous Wavelet Sharpening
#  Shift-invariant, no ringing.  Filter kernel selectable per
#  run: Gaussian (B3-spline), Z-Gaussian (sharper), Bilateral
#  (edge-preserving).
# ─────────────────────────────────────────────────────────────

# B3-spline 1D kernel
_B3 = np.array([1/16, 1/4, 3/8, 1/4, 1/16], dtype=np.float64)


def _atrous_smooth_b3(plane: np.ndarray, scale: int) -> np.ndarray:
    """B3-spline à trous smooth at dyadic scale."""
    step = 2 ** scale
    tmp = np.zeros_like(plane)
    out = np.zeros_like(plane)
    for i, k in enumerate(_B3):
        offset = (i - 2) * step
        tmp += k * np.roll(plane, -offset, axis=1)
    for i, k in enumerate(_B3):
        offset = (i - 2) * step
        out += k * np.roll(tmp, -offset, axis=0)
    return out


def _atrous_smooth_gaussian(plane: np.ndarray, scale: int) -> np.ndarray:
    """Gaussian smooth — sigma grows with scale."""
    sigma = 0.85 * (2 ** scale)
    return gaussian_filter(plane, sigma=sigma)


def _atrous_smooth_zgaussian(plane: np.ndarray, scale: int) -> np.ndarray:
    """Z-Gaussian — uses a wider smooth per scale, so each detail plane captures
    a broader frequency band. Results in stronger, crispier sharpening than
    standard Gaussian. WaveSharp's most aggressive mode."""
    sigma = 1.4 * (2 ** scale)   # wider than gaussian's 0.85, more energy in detail
    return gaussian_filter(plane, sigma=sigma)


def _atrous_smooth_bilateral(plane: np.ndarray, scale: int) -> np.ndarray:
    """Edge-preserving bilateral-style smooth using iterative Gaussian."""
    sigma_s = 0.85 * (2 ** scale)
    sigma_r = 0.08   # range sigma (edge threshold)
    smooth = gaussian_filter(plane, sigma=sigma_s)
    edge_weight = np.exp(-((plane - smooth) ** 2) / (2 * sigma_r ** 2))
    # Blend: near edges keep original, smooth areas get blurred
    return plane * (1 - edge_weight) + smooth * edge_weight


_SMOOTH_FN = {
    "gaussian":  _atrous_smooth_gaussian,
    "zgaussian": _atrous_smooth_zgaussian,
    "bilateral": _atrous_smooth_bilateral,
    "b3":        _atrous_smooth_b3,
}


def _atrous_decompose(channel: np.ndarray, n_levels: int,
                      filter_method: str = "b3"):
    """Decompose channel into n_levels detail planes + residual."""
    smooth_fn = _SMOOTH_FN.get(filter_method, _atrous_smooth_b3)
    planes = []
    current = channel.astype(np.float64)
    for scale in range(n_levels):
        smoothed = smooth_fn(current, scale)
        planes.append(current - smoothed)
        current = smoothed
    return planes, current


# Dyadic à trous decomposition base sigmas — matching WaveSharp 3.
# Each level doubles the scale: L1=1.5px, L2=3.0px, L3=6.0px.
# The UI Decomp σ sliders let the user override these per layer.
_WV_SIGMAS = [1.5, 3.0, 6.0]


def estimate_filter_sigma(sharpen: float, level: int,
                          img_arr: np.ndarray = None) -> float:
    """Returns the Decomp sigma for each layer used by Autosize Filter.

    Matches WaveSharp's actual sub-pixel operating point: base = 0.5px.
    Each layer doubles the sigma (dyadic):
      L1: 0.5px, L2: 1.0px, L3: 2.0px

    sharpen and img_arr are accepted for API compatibility but not used.
    """
    base = 0.5
    return round(base * float(2 ** level), 2)   # 0.5 / 1.0 / 2.0 px


def estimate_sharpen_filter(sharpen: float, sigma: float, level: int = 0) -> float:
    """
    Return the per-layer SharpenFilter value that WaveSharp Autosize sets.

    WaveSharp uses fixed per-layer base values (observed from WaveSharp 3):
      L1 (level=0): 0.146
      L2 (level=1): 0.100
      L3 (level=2): 0.100
    These scale linearly with sharpen (0 at sharpen=0, full at sharpen=200).

    sigma is accepted for API compatibility but not used for the calculation.
    """
    if sharpen <= 0:
        return 0.0
    # WaveSharp-calibrated base SharpenFilter per layer
    _BASE_SF = [0.146, 0.100, 0.100]
    base = _BASE_SF[min(int(level), 2)]
    sharpen_norm = min(float(sharpen) / 200.0, 1.0)   # 0..1
    return round(sharpen_norm * base, 3)


def _smooth_at_scale(plane: np.ndarray, scale: int, fm: str,
                     sigma: float = None,
                     bilateral_radius: float = 2.0,
                     zgauss_factor: float = 1.0) -> np.ndarray:
    """Apply one smoothing step.

    "gaussian"  : true Gaussian at the provided sigma value (WaveSharp Gauss mode).
    "zgaussian" : Gaussian at sigma = 1.4 * 2^scale * zgauss_factor.
                  zgauss_factor=0 collapses to Gaussian mode; =1 is full Z-Gaussian.
    "bilateral" : edge-preserving bilateral approximation.
                  bilateral_radius controls the spatial sigma (0=thin, 10=wide).
    "b3"        : dilated B3-spline à trous kernel.
    """
    if fm == "gaussian" and sigma is not None:
        return gaussian_filter(plane.astype(np.float64), sigma=sigma)
    elif fm == "zgaussian":
        # Factor blends between full Z-Gaussian (factor=0) and Gaussian (factor=1).
        # factor=0 → sigma = 1.4 * 2^scale  (full Z-Gaussian, wider/stronger)
        # factor=1 → sigma = Decomp σ value  (identical to Gaussian mode)
        base_s = sigma if sigma is not None else 0.85 * (2 ** scale)
        zg_s   = 1.4 * (2 ** scale)
        s = zg_s + zgauss_factor * (base_s - zg_s)   # interpolate ZG→Gauss
        s = max(s, 0.1)
        return gaussian_filter(plane.astype(np.float64), sigma=s)
    elif fm == "bilateral":
        # Bilateral: Gaussian smoothing in flat areas, edge/limb preservation at edges.
        # Uses Sobel edge magnitude for the range weighting — this correctly detects
        # the planetary limb and belt edges regardless of the decomp sigma scale.
        #
        # bilateral_radius (1-10) → logarithmic threshold scale:
        #   radius=10 → threshold very large → ew≈1 everywhere → identical to Gaussian
        #   radius=1  → threshold small     → ew≈0 at strong edges → edges fully preserved
        #                                     ew≈1 in flat areas → full Gaussian in interior
        sigma_s = sigma if sigma is not None else 0.85 * (2 ** scale)
        plane64 = plane.astype(np.float64)
        smooth  = gaussian_filter(plane64, sigma=sigma_s)
        # Compute Sobel edge magnitude for edge detection
        sx = sobel(plane64, axis=1)
        sy = sobel(plane64, axis=0)
        edge_mag = np.hypot(sx, sy)
        # Robust edge scale: 99th percentile of edge magnitude
        edge_scale = np.percentile(edge_mag, 99.0)
        if edge_scale < 1e-9:
            return smooth  # flat image — just return Gaussian
        # Logarithmic threshold: radius=1→0.3×scale, radius=10→100×scale
        log_threshold = edge_scale * (0.3 * (100.0 / 0.3) ** ((bilateral_radius - 1.0) / 9.0))
        ew = np.exp(-(edge_mag ** 2) / (2.0 * log_threshold ** 2))
        return plane64 * (1.0 - ew) + smooth * ew
    else:
        return _atrous_smooth_b3(plane, scale)


def _background_mask(plane: np.ndarray) -> np.ndarray:
    """Compute a soft foreground mask to suppress sky/background sharpening.

    Planetary images have a bright disk on a near-black sky background.
    Without this mask, high-gain sharpening amplifies sky noise into visible
    specks around the planet.

    Strategy: ramp from 0 (sky) to 1 (planet) using thresholds relative to
    the image peak luma. This is robust regardless of what fraction of the
    image is sky — unlike percentile-based thresholds which fail when sky
    dominates (as in typical drizzled planetary images).

      lo = peak * 1.5%  — ramp start (true sky noise)
      hi = peak * 3.0%  — ramp end   (safely inside even the darkest belts)

    The mask is then smoothed so the limb transition is gradual.

    Returns float64 mask in [0, 1], same shape as plane.
    """
    p = plane.astype(np.float64)
    lmax = p.max()
    if lmax < 0.01:
        return np.ones_like(p)   # near-blank image — no masking

    lo = lmax * 0.015
    hi = lmax * 0.030
    mask = np.clip((p - lo) / (hi - lo + 1e-8), 0.0, 1.0)

    # Smooth so limb transition is gradual
    sigma = max(plane.shape[0] // 120, 3)
    mask = gaussian_filter(mask, sigma=sigma)

    mask_max = mask.max()
    if mask_max > 1e-6:
        mask = np.clip(mask / mask_max, 0.0, 1.0)

    return mask


def _sharpen_plane(plane: np.ndarray, levels: list, fm: str,
                   pre_fft: list = None,
                   sharp_filter = 0.0,
                   bg_mask: np.ndarray = None,
                   pre_smooth: float = 0.0,
                   power_fn: float = 1.0,
                   bilateral_radius: float = 2.0,
                   zgauss_factor: float = 1.0,
                   bilateral_layers: list = None) -> np.ndarray:
    # bilateral_layers: list of bool per layer; if None all layers use fm
    # when fm=="bilateral", layers where bilateral_layers[i]==False use gaussian
    """
    Multi-scale wavelet / USM sharpening.

    fm=="gaussian": Multi-scale USM — each layer: detail = base - gaussian(base, σ).
                    Gain = sharpen/100 (slider 0-200, unity at 100).
                    Sigma comes from Decomp σ sliders (default dyadic: 1/2/4 px).
                    Matches WaveSharp "Gauss" mode exactly.
    fm=="b3" etc:   Iterative B3 à trous cascade. Gain = sharpen/75.
    """
    has_pre = pre_fft and any(p is not None for p in pre_fft)
    working = gaussian_filter(plane.astype(np.float64), sigma=pre_smooth) \
              if pre_smooth > 0 else plane.astype(np.float64)
    sigmas = [s for _, _, s in levels]
    # Gaussian mode: gain_div calibrated to match WaveSharp's actual operating point.
    # WaveSharp uses sigma≈0.5px (sub-pixel kernel) with gain≈350x at slider=200.
    # gain_div_L1 = 200/350 = 0.5714 so slider 200 -> gain 350x on sigma=0.5 USM.
    # Coarser layers scale by 4x per layer — gives clearly visible effect at L2 and L3:
    #   L1 (i=0): gain_div=0.5714   (sigma=0.5px, gain=350x at slider 200)
    #   L2 (i=1): gain_div=2.2857   (sigma=1.0px, gain=87.5x at slider 200)
    #   L3 (i=2): gain_div=9.1429   (sigma=2.0px, gain=21.9x at slider 200)
    # Non-gaussian modes keep a flat gain_div=75 (unchanged from prior behaviour).
    # Gaussian mode: gain calibrated to WaveSharp (slider 200 = 350x gain on L1).
    # Z-Gaussian: factor=0 is ~3.3x stronger than Gaussian (sliders need ~30% of
    #             Gaussian values). factor=1 is identical to Gaussian.
    #             gain_div scales as gaussian_gain_div * (0.30 + 0.70*factor).
    # Other modes: flat gain_div=75.
    if fm == "gaussian":
        _base_gain_div = 200.0 / 350.0           # 0.5714
    elif fm == "zgaussian":
        # factor=0 → full Z-Gaussian: sliders need ~33% of Gaussian values
        # factor=1 → identical to Gaussian: gain_div = gaussian value
        _zg_mult = 2.173 * (1.0 - zgauss_factor) + 1.0 * zgauss_factor
        _base_gain_div = (200.0 / 350.0) * _zg_mult
    elif fm == "bilateral":
        # Bilateral uses the same gain_div as Gaussian so that at radius=10
        # (pure Gaussian behaviour) the slider values produce identical output.
        _base_gain_div = 200.0 / 350.0           # 0.5714
    else:
        _base_gain_div = 75.0
    # Scale factor per layer: controls how much L2/L3 contribute relative to L1.
    # scale=4 gives meaningful visible effect at all three layers.
    _gaussian_scale = 4.0
    # Resolve sharp_filter: list = per-layer; scalar = broadcast to all layers
    _sf_list = sharp_filter if isinstance(sharp_filter, (list, tuple))                else [float(sharp_filter)] * len(levels)

    if not has_pre:
        # Build cascade
        if fm == "gaussian":
            # Gaussian bandpass decomposition matching WaveSharp "Gauss" mode:
            #   L1 (i=0): detail = base - gauss(base, s0)            <- USM
            #   L2 (i=1): detail = gauss(base, s0) - gauss(base, s1) <- bandpass
            #   L3 (i=2): detail = gauss(base, s1) - gauss(base, s2) <- bandpass
            # Cumulative USM for L2+ re-sharpened fine content already boosted
            # by L1, causing ~4x over-contribution. Bandpass prevents this.
            base = working
            smoothed_layers = [gaussian_filter(base, s) for s in sigmas]
        else:
            # Iterative a trous: B3/zgaussian/bilateral at dyadic scale indices
            c = [working]
            for i in range(len(levels)):
                _lfm = fm if (bilateral_layers is None or bilateral_layers[i]) else "gaussian"
                c.append(_smooth_at_scale(c[-1], i, _lfm, sigmas[i],
                                          bilateral_radius=bilateral_radius,
                                          zgauss_factor=zgauss_factor))

        out = plane.astype(np.float64).copy()
        for i, (sharpen, denoise, sigma) in enumerate(levels):
            if sharpen == 0:
                continue
            _sf = _sf_list[i]
            if fm == "gaussian":
                if i == 0:
                    detail = base - smoothed_layers[0]          # L1: USM
                else:
                    detail = smoothed_layers[i-1] - smoothed_layers[i]  # L2+: bandpass
                # SharpenFilter: DoG boost on the extraction kernel.
                if _sf > 0.0:
                    dog_base = base if i == 0 else smoothed_layers[i-1]
                    dog = smoothed_layers[i] - gaussian_filter(dog_base, sigma * 1.6)
                    detail = detail + _sf * dog
            else:
                detail = c[i] - c[i + 1]             # wavelet bandpass
                _lfm = fm if (bilateral_layers is None or bilateral_layers[i]) else "gaussian"
                if _sf > 0.0:
                    prev_sigma = sigmas[max(i - 1, 0)]
                    sf_smooth = _smooth_at_scale(detail, max(i - 1, 0), _lfm, prev_sigma,
                                                 bilateral_radius=bilateral_radius,
                                                 zgauss_factor=zgauss_factor)
                    detail = detail + _sf * (detail - sf_smooth)

            thresh = (denoise / 100.0) * 0.004
            if thresh > 0:
                abs_d = np.abs(detail)
                detail = np.where(abs_d > thresh, np.sign(detail) * (abs_d - thresh), 0.0)

            # Power function: sign(d) * |d|^exp — applied after threshold, before gain
            if power_fn != 1.0:
                abs_d = np.abs(detail)
                detail = np.sign(detail) * np.power(abs_d, power_fn)

            gain_div = _base_gain_div * (_gaussian_scale ** i) if fm in ("gaussian", "zgaussian", "bilateral") else _base_gain_div
            amp = (sharpen / gain_div) * detail
            if bg_mask is not None:
                amp *= bg_mask
            out += amp

        return out

    # ── PRE-layer FFT path (always iterative) ────────────────────────────────
    out = plane.astype(np.float64).copy()
    c_i = working.copy()

    for i, (sharpen, denoise, sigma) in enumerate(levels):
        if pre_fft and i < len(pre_fft) and pre_fft[i] is not None:
            fs, fw, fc = pre_fft[i]
            if fs < 100.0:
                tmp = np.stack([c_i] * 3, axis=-1).astype(np.float32)
                tmp = fft_denoise(tmp, fft_start=fs, fft_width=fw, fft_curve=fc)
                c_i = tmp[..., 0].astype(np.float64)

        _lfm = fm if (bilateral_layers is None or (
            bilateral_layers is not None and i < len(bilateral_layers) and bilateral_layers[i])) else "gaussian"
        c_next = gaussian_filter(c_i, sigma) if _lfm == "gaussian" \
                 else _smooth_at_scale(c_i, i, _lfm, sigma,
                                       bilateral_radius=bilateral_radius,
                                       zgauss_factor=zgauss_factor)
        detail = c_i - c_next

        if sharpen > 0:
            _sf = _sf_list[i]
            if _sf > 0.0:
                if fm == "gaussian":
                    dog = c_next - gaussian_filter(c_i, sigma * 1.6)
                    detail = detail + _sf * dog
                else:
                    prev_sigma = sigmas[max(i - 1, 0)]
                    sf_smooth = _smooth_at_scale(detail, max(i - 1, 0), fm, prev_sigma)
                    detail = detail + _sf * (detail - sf_smooth)

            thresh = (denoise / 100.0) * 0.004
            if thresh > 0:
                abs_d = np.abs(detail)
                detail = np.where(abs_d > thresh, np.sign(detail) * (abs_d - thresh), 0.0)

            # Power function: sign(d) * |d|^exp — applied after threshold, before gain
            if power_fn != 1.0:
                abs_d = np.abs(detail)
                detail = np.sign(detail) * np.power(abs_d, power_fn)

            gain_div = _base_gain_div * (_gaussian_scale ** i) if fm in ("gaussian", "zgaussian", "bilateral") else _base_gain_div
            amp = (sharpen / gain_div) * detail
            if bg_mask is not None:
                amp *= bg_mask
            out += amp

        c_i = c_next

    return out


def _extract_luma(img: np.ndarray, color_model: str):
    """Extract the luma/lightness channel for sharpening, return (L, aux).
    aux holds whatever is needed to reconstruct the full image afterwards."""
    if color_model == "hsl":
        import colorsys
        r, g, b = img[..., 0], img[..., 1], img[..., 2]
        cmax = np.max(img, axis=-1); cmin = np.min(img, axis=-1)
        L = (cmax + cmin) / 2.0
        return L, ("hsl", img)
    elif color_model == "hsv":
        V = np.max(img, axis=-1)
        return V, ("hsv", img)
    else:  # oklab (default)
        lab = rgb_to_oklab(img)
        return lab[..., 0].copy(), ("oklab", lab)


def _reconstruct(L_sharp: np.ndarray, aux, color_model: str) -> np.ndarray:
    """Reconstruct RGB from sharpened luma + original aux data."""
    tag, data = aux
    if tag == "oklab":
        out = data.copy(); out[..., 0] = np.clip(L_sharp, 0.0, 1.0)
        return oklab_to_rgb(out).astype(np.float32)
    elif tag == "hsl":
        # Shift L by the delta, keep H and S
        orig_img = data
        r, g, b  = orig_img[..., 0], orig_img[..., 1], orig_img[..., 2]
        cmax = np.max(orig_img, axis=-1); cmin = np.min(orig_img, axis=-1)
        L_orig = (cmax + cmin) / 2.0
        delta  = np.clip(L_sharp, 0.0, 1.0) - L_orig
        # Apply delta as brightness shift to RGB (preserves H/S)
        return np.clip(orig_img + delta[..., np.newaxis], 0.0, 1.0).astype(np.float32)
    else:  # hsv
        orig_img = data
        V_orig   = np.max(orig_img, axis=-1)
        scale    = np.clip(L_sharp, 0.0, 1.0) / np.maximum(V_orig, 1e-6)
        return np.clip(orig_img * scale[..., np.newaxis], 0.0, 1.0).astype(np.float32)


def wavelet_sharpen(
    img_array: np.ndarray,
    levels: list,
    filter_method: str = "gaussian",
    filter_enabled: bool = True,
    color_model: str = "oklab",
    convolve: str = "L",
    pre_fft: list = None,
    sharp_filter: float = 0.0,
    pre_smooth: float = 0.0,
    power_fn: float = 1.0,
    bilateral_radius: float = 2.0,
    zgauss_factor: float = 1.0,
    bilateral_layers: list = None,
) -> np.ndarray:
    """
    À trous wavelet sharpening — colour-safe, matches WaveSharp 3.

    pre_smooth : Gaussian sigma applied to the luma channel BEFORE decomposition.
                 Matches WaveSharp's 'Chroma Denoise / Autosize Filter' behaviour.
                 Eliminates sub-pixel moire by removing noise below the finest
                 decomposition scale before the wavelet cascade begins.
                 Default 0 (off). Recommended: set to Layer-1 sigma (e.g. 1.5).
    """
    fm  = filter_method if filter_enabled else "gaussian"
    img = img_array.astype(np.float64)

    # Compute sky-suppression mask from luma. Prevents amplification of sky noise
    # at high gain. Uses peak-relative thresholds so dark belt pixels are not masked.
    lum = 0.299 * img[..., 0] + 0.587 * img[..., 1] + 0.114 * img[..., 2]
    bg_mask = _background_mask(lum)

    if convolve == "RGB":
        result = np.empty_like(img)
        for c in range(3):
            result[..., c] = np.clip(
                _sharpen_plane(img[..., c], levels, fm, pre_fft, sharp_filter, bg_mask, pre_smooth, power_fn,
                                bilateral_radius, zgauss_factor, bilateral_layers), 0.0, 1.0)
        return result.astype(np.float32)

    if convolve == "LRGB":
        # WaveSharp LRGB sharpens each RGB channel independently at full gain,
        # matching the pixel-level output of WaveSharp's LRGB mode.
        # The previous two-pass (L delta → pass1 → RGB sharpen on pass1) diluted
        # the gain because pass2 was sharpening an already-boosted signal.
        result = np.empty_like(img)
        for c in range(3):
            result[..., c] = np.clip(
                _sharpen_plane(img[..., c], levels, fm, pre_fft, sharp_filter, bg_mask, pre_smooth, power_fn,
                                bilateral_radius, zgauss_factor, bilateral_layers), 0.0, 1.0)
        return result.astype(np.float32)

    # convolve == "L"
    L, aux  = _extract_luma(img, color_model)
    L_sharp = _sharpen_plane(L, levels, fm, pre_fft, sharp_filter, bg_mask, pre_smooth, power_fn,
                            bilateral_radius, zgauss_factor, bilateral_layers)
    return _reconstruct(L_sharp, aux, color_model)


def auto_wavelet_settings(img_array: np.ndarray, auto_strength: float, snr_target: float):
    """
    Analyze image and return wavelet settings scaled to user's controls.
    auto_strength 0-200: maps directly to slider values (100=normal, 200=max)
    snr_target 10-50:    maps to sharpen amount — higher = more aggressive

    Returns: [(slider1,sharpen1,denoise1), (slider2,...), (slider3,...)]
    """
    lum = luminance(img_array)

    # Noise estimate from finest wavelet plane
    planes, _ = _atrous_decompose(lum, 3, "b3")
    noise_est = np.std(planes[0]) * 1.4826
    noise_est = max(noise_est, 1e-6)

    # Denoise proportional to noise floor
    dn1 = int(np.clip(noise_est * 4000,  2, 40))
    dn2 = int(np.clip(noise_est * 5000,  2, 50))
    dn3 = int(np.clip(noise_est * 6000,  3, 60))

    # Slider: directly driven by auto_strength (0-200 range)
    sl  = int(np.clip(auto_strength, 0, 200))
    sl1 = sl
    sl2 = max(10, int(sl * 0.9))
    sl3 = max(10, int(sl * 0.7))

    # Sharpen: driven by snr_target (10-50) — maps to 0-500 sharpen range
    # snr_target=10 → very gentle,  snr_target=50 → extreme
    sh_scale = (snr_target - 10) / 40.0   # 0.0 to 1.0
    sh1 = int(sh_scale * 500)
    sh2 = int(sh_scale * 400)
    sh3 = int(sh_scale * 300)

    return [(sl1, sh1, dn1), (sl2, sh2, dn2), (sl3, sh3, dn3)]



# ─────────────────────────────────────────────────────────────
#  FFT Denoise
# ─────────────────────────────────────────────────────────────

def _window_func(h: int, w: int, kind: str) -> np.ndarray:
    """Build a 2D window function."""
    if kind == "hann":
        wy = np.hanning(h)
        wx = np.hanning(w)
    elif kind == "hamming":
        wy = np.hamming(h)
        wx = np.hamming(w)
    elif kind == "blackman":
        wy = np.blackman(h)
        wx = np.blackman(w)
    else:  # none
        return np.ones((h, w), dtype=np.float32)
    return np.outer(wy, wx).astype(np.float32)


def _soft_threshold(spectrum: np.ndarray, threshold: float) -> np.ndarray:
    """Soft thresholding in frequency domain."""
    mag = np.abs(spectrum)
    phase = np.angle(spectrum)
    mag_thresh = np.maximum(mag - threshold, 0)
    return mag_thresh * np.exp(1j * phase)


def _fft_curve_exponent(curve_amount: float) -> float:
    """Map curve slider 0-100 to power exponent k.
    k < 1 = concave-down / gentle (left);  k=1 = linear (centre);  k > 1 = concave-up / aggressive (right).
    Formula: k = 0.3 * (10/3)^(curve_amount/50)
    slider=0 → k≈0.30, slider=50 → k=1.0, slider=100 → k≈3.33
    """
    return 0.3 * ((10.0 / 3.0) ** (float(curve_amount) / 50.0))


def fft_denoise(
    img_array: np.ndarray,
    fft_start: float,
    fft_width: float,
    fft_curve,   # float 0-100 (continuous slider) or legacy str for back-compat
) -> np.ndarray:
    """
    FFT low-pass filter.

    fft_start  : 0-100, percentage of Nyquist where attenuation begins.
    fft_width  : 0-100, width of the rolloff as percentage of Nyquist.
    fft_curve  : float 0-100 — curve shape slider.
                 0 = concave-down / gentle (less removal)
                 50 = linear
                 100 = concave-up / aggressive (more removal)
                 Also accepts legacy strings for back-compatibility.
    """
    # Legacy string back-compat
    if isinstance(fft_curve, str):
        _legacy = {"cosine": 25, "linear": 50, "gaussian": 75, "hard": 100}
        fft_curve = float(_legacy.get(fft_curve, 50))

    start_frac = np.clip(fft_start / 100.0, 0.0, 1.0)
    width_frac  = np.clip(fft_width  / 100.0, 0.0, 1.0)
    if start_frac >= 1.0:
        return img_array.copy()

    h, w = img_array.shape[:2]
    cy, cx   = h // 2, w // 2
    Y2, X2   = np.ogrid[:h, :w]
    dist     = np.sqrt((X2 - cx)**2 + (Y2 - cy)**2)
    max_dist = float(min(cx, cy)) + 1e-10   # Nyquist = half min dimension, not corner
    nd       = dist / max_dist

    cutoff_frac = start_frac + width_frac
    t = np.clip((nd - start_frac) / max(width_frac, 1e-6), 0.0, 1.0)
    in_ramp = (nd >= start_frac) & (nd < cutoff_frac)
    above   = nd >= cutoff_frac

    k = _fft_curve_exponent(fft_curve)
    filter_2d = np.ones((h, w), dtype=np.float64)
    filter_2d[in_ramp] = (1.0 - t[in_ramp]) ** k
    filter_2d[above]   = 0.0

    result = np.empty_like(img_array)
    for c in range(3):
        channel  = img_array[..., c].astype(np.float64)
        Fshift   = np.fft.fftshift(np.fft.fft2(channel))
        Fshift  *= filter_2d
        denoised = np.real(np.fft.ifft2(np.fft.ifftshift(Fshift)))
        result[..., c] = np.clip(denoised, 0.0, 1.0)

    return result


def build_fft_filter_curve(fft_start: float, fft_width: float, fft_curve,
                            n_bins: int = 64) -> np.ndarray:
    """Return a 1-D array (length n_bins) of filter values 0..1 for display."""
    if isinstance(fft_curve, str):
        _legacy = {"cosine": 25, "linear": 50, "gaussian": 75, "hard": 100}
        fft_curve = float(_legacy.get(fft_curve, 50))
    nd = np.linspace(0.0, 1.0, n_bins)
    start_frac  = np.clip(fft_start / 100.0, 0.0, 1.0)
    width_frac  = np.clip(fft_width  / 100.0, 0.0, 1.0)
    cutoff_frac = start_frac + width_frac
    t = np.clip((nd - start_frac) / max(width_frac, 1e-6), 0.0, 1.0)
    in_ramp = (nd >= start_frac) & (nd < cutoff_frac)
    above   = nd >= cutoff_frac
    k = _fft_curve_exponent(fft_curve)
    filt = np.ones(n_bins, dtype=np.float64)
    filt[in_ramp] = (1.0 - t[in_ramp]) ** k
    filt[above]   = 0.0
    return filt


def compute_fft_power(img_array: np.ndarray) -> np.ndarray:
    """Return 1D radially averaged power spectrum (64 bins) for display."""
    lum = luminance(img_array)
    h, w = lum.shape
    window = _window_func(h, w, "hann")
    F = np.fft.fftshift(np.fft.fft2(lum * window))
    power = np.log1p(np.abs(F) ** 2)
    cy, cx = h // 2, w // 2
    Y, X = np.ogrid[:h, :w]
    dist = np.sqrt((X - cx)**2 + (Y - cy)**2).astype(int)
    max_dist = min(cx, cy)
    bins = 64
    spectrum = np.zeros(bins)
    counts = np.zeros(bins)
    for i in range(bins):
        r0 = int(i * max_dist / bins)
        r1 = int((i + 1) * max_dist / bins)
        mask = (dist >= r0) & (dist < r1)
        if mask.any():
            spectrum[i] = np.mean(power[mask])
            counts[i] = mask.sum()
    # Normalize
    if spectrum.max() > 0:
        spectrum /= spectrum.max()
    return spectrum


# ─────────────────────────────────────────────────────────────
#  RGB Balance & Saturation
# ─────────────────────────────────────────────────────────────

def _rgb_to_hsl(r, g, b):
    """Vectorized RGB to HSL."""
    cmax = np.maximum(np.maximum(r, g), b)
    cmin = np.minimum(np.minimum(r, g), b)
    delta = cmax - cmin

    L = (cmax + cmin) / 2.0
    S = np.where(delta == 0, 0, delta / (1 - np.abs(2 * L - 1) + 1e-10))

    H = np.zeros_like(r)
    mask_r = (cmax == r) & (delta > 0)
    mask_g = (cmax == g) & (delta > 0)
    mask_b = (cmax == b) & (delta > 0)
    H[mask_r] = ((g[mask_r] - b[mask_r]) / delta[mask_r]) % 6
    H[mask_g] = (b[mask_g] - r[mask_g]) / delta[mask_g] + 2
    H[mask_b] = (r[mask_b] - g[mask_b]) / delta[mask_b] + 4
    H = H / 6.0
    return H, S, L


def _hsl_to_rgb(H, S, L):
    """Vectorized HSL to RGB."""
    C = (1 - np.abs(2 * L - 1)) * S
    X = C * (1 - np.abs((H * 6) % 2 - 1))
    m = L - C / 2

    H6 = (H * 6).astype(int) % 6
    R = np.select([H6==0, H6==1, H6==2, H6==3, H6==4, H6==5], [C,X,0*C,0*C,X,C])
    G = np.select([H6==0, H6==1, H6==2, H6==3, H6==4, H6==5], [X,C,C,X,0*C,0*C])
    B = np.select([H6==0, H6==1, H6==2, H6==3, H6==4, H6==5], [0*C,0*C,X,C,C,X])
    return R + m, G + m, B + m


def apply_color_adjustments(
    img_array: np.ndarray,
    r_gain: float, g_gain: float, b_gain: float,
    r_gamma: float, g_gamma: float, b_gamma: float,
    saturation: float,
    vibrance: float,
    hue_rotation: float,
    brightness: float,
    contrast: float,
    r_black: float = 0.0,
    g_black: float = 0.0,
    b_black: float = 0.0,
) -> np.ndarray:
    """Apply per-channel black point, gain, gamma, saturation, vibrance, hue, brightness, contrast.

    Black point is applied first: out = (in - black) / (1 - black), lifting
    the shadow floor per channel. This is the standard levels stretch and is
    what brings diverging histogram shadow edges together.
    """
    result = img_array.copy().astype(np.float64)

    # Per-channel black point (levels stretch: lift shadow floor)
    for c, bp in enumerate([r_black, g_black, b_black]):
        if bp > 0.0:
            span = max(1.0 - bp, 1e-6)
            result[..., c] = np.clip((result[..., c] - bp) / span, 0.0, 1.0)

    # Per-channel gamma
    eps = 1e-8
    result[..., 0] = np.power(np.clip(result[..., 0], eps, 1), 1.0 / max(r_gamma, eps))
    result[..., 1] = np.power(np.clip(result[..., 1], eps, 1), 1.0 / max(g_gamma, eps))
    result[..., 2] = np.power(np.clip(result[..., 2], eps, 1), 1.0 / max(b_gamma, eps))

    # Per-channel gain
    result[..., 0] *= r_gain
    result[..., 1] *= g_gain
    result[..., 2] *= b_gain

    # Brightness
    result += brightness

    # Contrast (pivot at 0.5)
    result = (result - 0.5) * (1.0 + contrast) + 0.5

    result = np.clip(result, 0, 1)

    # Saturation
    lum = luminance(result)
    lum3 = lum[..., np.newaxis]
    result = lum3 + (result - lum3) * saturation

    # Vibrance (selective saturation — boost less-saturated colors more)
    H, S, L = _rgb_to_hsl(result[..., 0], result[..., 1], result[..., 2])
    vib_boost = (vibrance - 1.0) * (1.0 - S)
    S_new = np.clip(S + vib_boost * S, 0, 1)
    rr, gg, bb = _hsl_to_rgb(H, S_new, L)
    result[..., 0] = rr; result[..., 1] = gg; result[..., 2] = bb

    # Hue rotation
    if abs(hue_rotation) > 0.001:
        H, S, L = _rgb_to_hsl(result[..., 0], result[..., 1], result[..., 2])
        H = (H + hue_rotation / 360.0) % 1.0
        rr, gg, bb = _hsl_to_rgb(H, S, L)
        result[..., 0] = rr; result[..., 1] = gg; result[..., 2] = bb

    return np.clip(result, 0, 1).astype(np.float32)


def auto_balance(img_array: np.ndarray):
    """Full per-channel levels balance — aligns both shadow and highlight
    edges of R, G, B in the histogram simultaneously.

    Uses green as the reference channel. Computes black point (0.5th percentile)
    and white point (99.5th percentile) per channel, then returns the gain and
    black point needed so each channel maps [black..white] → [0..1] with the
    same effective range as green.

    Returns:
        r_gain, g_gain, b_gain   — multipliers  (e.g. 1.23 → slider 123)
        r_black, g_black, b_black — black points 0-1 (e.g. 0.05 → slider 5)
    """
    blacks = np.array([np.percentile(img_array[..., c], 0.5) for c in range(3)])
    whites = np.array([np.percentile(img_array[..., c], 99.5) for c in range(3)])
    spans  = np.maximum(whites - blacks, 1e-6)   # per-channel dynamic range

    # Green is the reference: map [g_black..g_white] → [0..1]
    g_span = spans[1]

    # For R and B: after black-point subtraction their span will be spans[c],
    # so the gain needed to match green's output range is g_span / spans[c].
    # Green's own gain stays 1.0.
    r_gain  = float(np.clip(g_span / spans[0], 0.1, 8.0))
    g_gain  = 1.0
    b_gain  = float(np.clip(g_span / spans[2], 0.1, 8.0))

    r_black = float(np.clip(blacks[0], 0.0, 0.5))
    g_black = float(np.clip(blacks[1], 0.0, 0.5))
    b_black = float(np.clip(blacks[2], 0.0, 0.5))

    return r_gain, g_gain, b_gain, r_black, g_black, b_black


def auto_white_balance(img_array: np.ndarray):
    """Percentile white-point stretch per channel.
    Stretches each channel so its 99th percentile maps to 1.0.
    Returns (r_gain, g_gain, b_gain, r_gamma, g_gamma, b_gamma)
    as slider units (gains 0-200, gammas 50-200)."""
    result_gains  = []
    result_gammas = []
    for c in range(3):
        ch = img_array[..., c]
        white = np.percentile(ch, 99)
        black = np.percentile(ch, 1)
        span  = max(white - black, 1e-6)

        # Gain: stretch so white point → 1.0
        gain = np.clip(1.0 / (white + 1e-8), 0.2, 3.0)

        # Gamma: correct midtone brightness via mid-grey target
        # After gain, the midpoint should sit at ~0.5
        mid_in  = np.clip((ch.mean() - black) / span, 0.01, 0.99)
        # gamma = log(0.5) / log(mid_in) maps mid_in → 0.5
        gamma = np.clip(np.log(0.5) / (np.log(mid_in) + 1e-10), 0.5, 2.0)

        result_gains.append(gain)
        result_gammas.append(gamma)

    return tuple(result_gains), tuple(result_gammas)


# ─────────────────────────────────────────────────────────────
#  Deringing / Onion-Rind Removal
# ─────────────────────────────────────────────────────────────

def _derind_mask(
    lum: np.ndarray,
    edge: float,
    feather: float,
    smooth: float,
    gap_width: float,
    gap_angle: float,
    saturn_mode: bool,
    inset: float = 0.0,
) -> np.ndarray:
    """
    Build the De-rind active mask — a soft band around the planetary limb.

    edge      : outer extent in pixels (how far outside the disk the mask reaches)
    feather   : inward falloff in pixels (mask tapers to zero this far inside limb)
    smooth    : Gaussian sigma to broaden mask both ways (removes discontinuities)
    gap_width : angular gap width in degrees (0 = no gap)
    gap_angle : rotation of the gap centre in degrees (0 = top)
    saturn_mode : auto-apply gap on both sides (for Saturn's rings)
    inset     : pull mask band inward from limb by this many px (0 = starts at limb)
    """
    from scipy.ndimage import binary_dilation, binary_erosion, distance_transform_edt, gaussian_filter
    import numpy as np

    h, w = lum.shape

    # ── Detect planet disk via luminance threshold ──────────────────
    # Use a fraction of the image peak — robust to any sky fraction and planet size.
    # p85 fails when the planet occupies <15% of the image (e.g. small Mars disk).
    lum_max = float(np.percentile(lum, 99.5))   # robust peak (ignores hot pixels)
    disk_thresh = max(lum_max * 0.15, 0.01)      # 15% of peak — sits at the visual limb
    disk_mask   = (lum > disk_thresh).astype(bool)

    # ── Signed distance from limb: positive outside, negative inside ─
    # dist_out: distance from disk boundary going outward (sky pixels)
    # dist_in:  distance from disk boundary going inward (planet pixels)
    dist_out = distance_transform_edt(disk_mask)          # inside: dist to boundary
    dist_out_inv = distance_transform_edt(~disk_mask)     # outside: dist to boundary

    # Ramp outward: 1 at limb → 0 at `edge` px outside
    edge_px    = max(float(edge), 1.0)
    feather_px = max(float(feather), 0.0)
    smooth_px  = max(float(smooth), 0.0)

    # Inset: shift the mask band inward from the limb by `inset` px.
    # dist_out_inv for sky pixels and dist_out for planet pixels are both
    # measured from the detected limb boundary. Adding inset_px shifts the
    # effective limb reference inward so the mask band starts inset_px inside.
    # Inset shifts the mask band inward by inset_px.
    # The band spans from (edge - inset) px outward (sky) to (feather + inset) px inward.
    #
    # outer_ramp: sky pixels. Effective sky extent = max(edge - inset, 0).
    #   ramp = 1 at limb, 0 at (edge - inset) px outside.
    #   When inset >= edge: eff_outer = 0, outer_ramp = 0 everywhere.
    #
    # inner_ramp: planet pixels. Band starts at inset_px inside limb, tapers over feather_px.
    #   ramp = 0 for planet pixels shallower than inset_px (not yet inside band)
    #   ramp = 1 at inset_px depth, 0 at (inset + feather) px depth.
    inset_px = max(float(inset), 0.0)
    eff_outer = max(edge_px - inset_px, 0.0)
    outer_ramp = np.clip(1.0 - dist_out_inv / max(eff_outer, 1e-3), 0.0, 1.0)                  if eff_outer > 0 else np.zeros_like(dist_out_inv)
    if feather_px > 0:
        inner_ramp = np.clip(1.0 - (dist_out - inset_px) / feather_px, 0.0, 1.0)
        inner_ramp[dist_out < inset_px] = 0.0   # not yet inside the band
    else:
        inner_ramp = np.zeros_like(lum)
    # outer_ramp covers sky side; inner_ramp covers planet interior side
    mask = outer_ramp * (1.0 - disk_mask.astype(float))   # sky band outside limb
    mask += inner_ramp * disk_mask.astype(float)           # band inside planet
    mask = np.clip(mask, 0.0, 1.0)

    # ── Smooth: broaden mask in both directions ──────────────────────
    if smooth_px > 0:
        mask = gaussian_filter(mask.astype(np.float64), sigma=smooth_px)
        mask = np.clip(mask, 0.0, 1.0)

    # ── Angular gap ──────────────────────────────────────────────────
    if gap_width > 0 or saturn_mode:
        # Find disk centroid
        ys, xs = np.where(disk_mask)
        if len(ys) > 0:
            cy, cx = ys.mean(), xs.mean()
        else:
            cy, cx = h / 2, w / 2

        # Angle map (degrees, 0=top, clockwise)
        Y, X = np.mgrid[:h, :w]
        angles = np.degrees(np.arctan2(X - cx, -(Y - cy))) % 360.0

        gap_w = gap_width if not saturn_mode else max(gap_width, 30.0)
        half  = gap_w / 2.0
        gaps  = [(gap_angle % 360.0, half)]
        if saturn_mode:
            gaps.append(((gap_angle + 180.0) % 360.0, half))

        gap_mask = np.zeros((h, w), dtype=bool)
        for centre, hw in gaps:
            lo = (centre - hw) % 360.0
            hi = (centre + hw) % 360.0
            if lo < hi:
                gap_mask |= (angles >= lo) & (angles <= hi)
            else:   # wraps around 0°
                gap_mask |= (angles >= lo) | (angles <= hi)

        # Feather the gap edges softly (5px transition)
        from scipy.ndimage import gaussian_filter as gf
        gap_soft = gf(gap_mask.astype(np.float32), sigma=3.0)
        mask *= (1.0 - np.clip(gap_soft, 0, 1))

    return mask.astype(np.float32)


def apply_derind(
    img_array: np.ndarray,
    edge: float        = 8.0,
    feather: float     = 4.0,
    smooth: float      = 2.0,
    inset: float       = 0.0,
    gap_width: float   = 0.0,
    gap_angle: float   = 0.0,
    saturn_mode: bool  = False,
    dark_edge: bool    = True,
    pre_blur: float    = 0.0,
    show_ring_map: bool = False,
) -> np.ndarray:
    """
    De-rind: suppress the halo/rind artifact around bright planetary limbs.

    Parameters map directly to WaveSharp De-rind controls:
      edge        : outer extent of correction (px beyond limb)
      feather     : inward feather depth (px inside limb, tapering to zero)
      smooth      : broaden mask both ways — removes discontinuities (Gaussian sigma)
      inset       : pull mask band inward from limb by this many px (0 = starts at limb)
      gap_width   : angular gap in the mask in degrees (0=none); use for Saturn rings
      gap_angle   : rotation of the gap centre in degrees (0=top, clockwise)
      saturn_mode : auto-apply symmetric 180° gaps on both sides of disk
      dark_edge   : suppress bright diffraction rings outside the main halo band
      pre_blur    : optional pre-blur sigma applied before correction
      show_ring_map : overlay the active mask as a red tint for inspection
    """
    from scipy.ndimage import gaussian_filter
    result = img_array.astype(np.float64)

    # Optional pre-blur
    if pre_blur > 0:
        result = np.stack([
            gaussian_filter(result[..., c], sigma=pre_blur) for c in range(3)
        ], axis=-1)

    lum = luminance(result.astype(np.float32))

    # Build the active mask
    mask = _derind_mask(lum, edge=edge, feather=feather, smooth=smooth,
                        gap_width=gap_width, gap_angle=gap_angle,
                        saturn_mode=saturn_mode, inset=inset)

    # Dark-edge extension: if enabled, extend correction outward to catch
    # diffraction rings beyond the main halo band (common on Mars).
    # The extended mask is merged with the main mask using max() so the result
    # is a single smooth gradient, not two separate rings.
    if dark_edge:
        outer_ext = _derind_mask(lum, edge=edge * 2.5, feather=0,
                                  smooth=smooth * 1.5, gap_width=gap_width,
                                  gap_angle=gap_angle, saturn_mode=saturn_mode,
                                  inset=inset)
        # Merge: take the maximum of main mask and half-weight outer extension
        # so there are no gaps and the result is a single continuous band
        mask = np.maximum(mask, outer_ext * 0.5)

    # Build correction target (median-like local average)
    kernel = max(3, int(edge) * 2 + 1)
    from scipy.ndimage import uniform_filter
    target = np.stack([
        uniform_filter(result[..., c].astype(np.float64), size=kernel)
        for c in range(3)
    ], axis=-1)

    # Blend toward target weighted by mask
    mask3 = mask[..., np.newaxis]
    result = result * (1.0 - mask3) + target * mask3
    result = np.clip(result, 0.0, 1.0)

    if show_ring_map:
        # Overlay: blend red tint only where mask > 0. Interior (mask=0) is untouched.
        # Use additive tint so planet detail remains visible inside the mask band.
        tint_strength = np.clip(mask * 0.90, 0, 1)[..., np.newaxis]
        red_tint = np.zeros_like(result)
        red_tint[..., 0] = 1.0   # full red channel
        red_tint[..., 1] = 0.0
        red_tint[..., 2] = 0.0
        # Blend: masked pixels dimmed + vivid red; unmasked pixels unchanged
        result = result * (1.0 - tint_strength * 0.7) + red_tint * tint_strength * 0.7
        result = np.clip(result, 0, 1)

    return result.astype(np.float32)


# ══════════════════════════════════════════════════════════════════════════════
#  Tools — Levels & Curves  +  CLAHE
# ══════════════════════════════════════════════════════════════════════════════

def _build_curve_lut(control_points):
    """
    Build a 256-entry float32 LUT from a list of (x, y) control points in [0,1].
    Uses PCHIP monotone cubic interpolation so the curve never overshoots.
    Always passes through (0,0) and (1,1) if no points are near those edges.
    Returns a float32 array of shape (256,) with values in [0,1].
    """
    from scipy.interpolate import PchipInterpolator
    pts = sorted(control_points, key=lambda p: p[0])
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    # Ensure boundary anchors
    if xs[0] > 0.001:
        xs.insert(0, 0.0); ys.insert(0, 0.0)
    if xs[-1] < 0.999:
        xs.append(1.0); ys.append(1.0)
    interp = PchipInterpolator(xs, ys)
    t = np.linspace(0.0, 1.0, 256)
    lut = np.clip(interp(t).astype(np.float32), 0.0, 1.0)
    return lut


def apply_levels_curves(
    img_array: np.ndarray,
    black_r: float = 0.0, white_r: float = 1.0, gamma_r: float = 1.0,
    black_g: float = 0.0, white_g: float = 1.0, gamma_g: float = 1.0,
    black_b: float = 0.0, white_b: float = 1.0, gamma_b: float = 1.0,
    curve_lut_r = None,
    curve_lut_g = None,
    curve_lut_b = None,
) -> np.ndarray:
    """
    Per-channel levels (black point, white point, gamma) followed by a
    tone curve LUT.  All inputs are float32 [0,1].

    black / white : clamp and stretch the input range
        stretched = (x - black) / (white - black)
    gamma : applied after stretch
        out = stretched ^ (1/gamma)
    curve_lut : 256-entry float32 array mapping [0,255] → [0,1]
        Applied as a final LUT after levels+gamma.
        None = identity (no curve).
    """
    img = img_array.astype(np.float64)
    result = np.empty_like(img)

    def _process_channel(ch, black, white, gamma, lut):
        w_range = max(white - black, 1e-6)
        out = np.clip((ch - black) / w_range, 0.0, 1.0)
        if abs(gamma - 1.0) > 0.001:
            out = np.power(out, 1.0 / gamma)
        if lut is not None:
            # Map float [0,1] through the 256-entry LUT
            idx = np.clip((out * 255.0).astype(np.int32), 0, 255)
            out = lut[idx].astype(np.float64)
        return out

    result[..., 0] = _process_channel(img[..., 0], black_r, white_r, gamma_r, curve_lut_r)
    result[..., 1] = _process_channel(img[..., 1], black_g, white_g, gamma_g, curve_lut_g)
    result[..., 2] = _process_channel(img[..., 2], black_b, white_b, gamma_b, curve_lut_b)

    return np.clip(result, 0.0, 1.0).astype(np.float32)


def _clahe_channel(plane: np.ndarray, clip_limit: float, tile_grid: int) -> np.ndarray:
    """
    Apply CLAHE to a single float32 [0,1] plane.
    Uses skimage if available, otherwise falls back to a scipy tile-based implementation.
    clip_limit is in the 0.5-10.0 user range (divided by 10 for skimage).
    """
    try:
        from skimage.exposure import equalize_adapthist
        return equalize_adapthist(
            plane, kernel_size=tile_grid,
            clip_limit=clip_limit / 10.0).astype(np.float32)
    except ImportError:
        pass

    # scipy fallback: proper CLAHE with bilinear tile interpolation
    # Matches skimage's approach: compute per-tile CDFs, then interpolate
    from scipy.ndimage import zoom as _zoom
    h, w = plane.shape
    nr = tile_grid   # number of tile rows
    nc = tile_grid   # number of tile cols

    def _tile_cdf(patch, cl):
        """Compute clipped CDF for a tile, returns 256-entry LUT."""
        flat = (np.clip(patch, 0.0, 1.0) * 255.0).astype(np.int32).flatten()
        hist = np.bincount(flat, minlength=256).astype(np.float32)
        # Clip and redistribute excess
        clip_val = max(1.0, cl * flat.size / 256.0)
        excess = np.sum(np.maximum(hist - clip_val, 0.0))
        hist = np.minimum(hist, clip_val)
        hist += excess / 256.0
        cdf = np.cumsum(hist)
        lo, hi = cdf[0], cdf[-1]
        if hi > lo:
            cdf = (cdf - lo) / (hi - lo)
        else:
            cdf = np.linspace(0.0, 1.0, 256)
        return cdf.astype(np.float32)

    # Build one CDF per tile centre
    cdfs = np.zeros((nr, nc, 256), dtype=np.float32)
    # Tile boundaries (edges get half-tile padding like skimage)
    row_borders = np.linspace(0, h, nr + 1).astype(int)
    col_borders = np.linspace(0, w, nc + 1).astype(int)
    for r in range(nr):
        for c in range(nc):
            patch = plane[row_borders[r]:row_borders[r+1],
                          col_borders[c]:col_borders[c+1]]
            cdfs[r, c] = _tile_cdf(patch, clip_limit)

    # Tile centre coordinates (for interpolation weights)
    row_centers = ((row_borders[:-1] + row_borders[1:]) / 2.0)
    col_centers = ((col_borders[:-1] + col_borders[1:]) / 2.0)

    # Apply bilinear interpolation between 4 nearest tile CDFs
    out = np.empty_like(plane)
    px_idx = np.clip((plane * 255.0).astype(np.int32), 0, 255)

    for r in range(nr):
        for c in range(nc):
            r0 = row_borders[r]; r1 = row_borders[r+1]
            c0 = col_borders[c]; c1 = col_borders[c+1]
            patch_idx = px_idx[r0:r1, c0:c1]

            # Determine 4 neighbouring tile CDFs for bilinear blend
            ry = np.arange(r0, r1)
            cx = np.arange(c0, c1)

            # Find left/right tile neighbours
            rl = r - 1 if r > 0 else r
            rr = r + 1 if r < nr - 1 else r
            cl_n = c - 1 if c > 0 else c
            cr_n = c + 1 if c < nc - 1 else c

            # Vertical weight: distance from row_centers[rl] to row_centers[rr]
            yc_lo = row_centers[rl]; yc_hi = row_centers[rr]
            if yc_hi > yc_lo:
                wy = np.clip((ry - yc_lo) / (yc_hi - yc_lo), 0.0, 1.0)
            else:
                wy = np.zeros(len(ry))

            # Horizontal weight
            xc_lo = col_centers[cl_n]; xc_hi = col_centers[cr_n]
            if xc_hi > xc_lo:
                wx = np.clip((cx - xc_lo) / (xc_hi - xc_lo), 0.0, 1.0)
            else:
                wx = np.zeros(len(cx))

            wy = wy[:, np.newaxis]   # (rows, 1)
            wx = wx[np.newaxis, :]   # (1, cols)

            # Bilinear blend of 4 CDFs
            cdf_tl = cdfs[rl, cl_n][patch_idx]
            cdf_tr = cdfs[rl, cr_n][patch_idx]
            cdf_bl = cdfs[rr, cl_n][patch_idx]
            cdf_br = cdfs[rr, cr_n][patch_idx]

            out[r0:r1, c0:c1] = (
                (1-wy)*(1-wx)*cdf_tl +
                (1-wy)*wx    *cdf_tr +
                wy    *(1-wx)*cdf_bl +
                wy    *wx    *cdf_br
            )

    return np.clip(out, 0.0, 1.0).astype(np.float32)


def apply_clahe(
    img_array: np.ndarray,
    clip_limit: float = 2.0,
    tile_grid: int = 8,
    channel_mode: str = "luminance",
    strength: float = 1.0,
) -> np.ndarray:
    """
    CLAHE (Contrast Limited Adaptive Histogram Equalisation).

    channel_mode : "luminance" — apply to L only (safe, no colour shift)
                   "rgb"       — apply to each channel independently
    clip_limit   : 0.5-10.0.  Higher = more contrast enhancement.
    tile_grid    : NxN grid of tiles (4-64).  Smaller = more local.
    strength     : 0.0-1.0 blend with original (1.0 = full CLAHE).
    """
    img = np.clip(img_array, 0.0, 1.0).astype(np.float32)

    if channel_mode == "luminance":
        lum = (0.299 * img[..., 0] +
               0.587 * img[..., 1] +
               0.114 * img[..., 2]).astype(np.float32)
        lum_eq = _clahe_channel(lum, clip_limit, tile_grid)
        ratio = np.where(lum > 1e-6, lum_eq / (lum + 1e-6), 1.0)
        ratio = np.clip(ratio, 0.0, 4.0)
        enhanced = img * ratio[..., np.newaxis]
    else:  # "rgb"
        enhanced = np.stack([
            _clahe_channel(img[..., c], clip_limit, tile_grid)
            for c in range(3)
        ], axis=-1)

    result = img + strength * (enhanced - img)
    return np.clip(result, 0.0, 1.0).astype(np.float32)


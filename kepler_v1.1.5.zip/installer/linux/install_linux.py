#!/usr/bin/env python3
"""
install_linux.py - Kepler GUI Installer for Linux Mint / Ubuntu / Debian
Checks and installs all dependencies, creates launchers and .desktop files.
Requires: python3-tk (usually pre-installed on Linux Mint)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import subprocess
import sys
import os
import shutil
import platform
import time
import stat
import tempfile

KEPLER_VERSION = "1.1.5"
INSTALL_DIR_DEFAULT = os.path.expanduser("~/.local/share/kepler")
BIN_LINK = os.path.expanduser("~/.local/bin/kepler")
DESKTOP_FILE_DIR = os.path.expanduser("~/.local/share/applications")

BG         = "#0a0f1e"
BG_PANEL   = "#0d1528"
BG_CARD    = "#111e33"
BG_RAISED  = "#162040"
FG_BRIGHT  = "#e8f4fd"
FG_MID     = "#8aa4c0"
FG_DIM     = "#3d5470"
ACCENT     = "#00d4ff"
ACCENT_G   = "#39ff14"
ACCENT_O   = "#ff6b35"
ACCENT_R   = "#ff4444"
BORDER     = "#1a3050"

REQUIRED_PACKAGES = [
    ("numpy",    "python3-numpy",   "numpy",    "scientific arrays"),
    ("PIL",      "python3-pil",     "Pillow",   "image I/O"),
    ("PIL.ImageTk", "python3-pil.imagetk", None, "ImageTk (Tk/PIL bridge)"),
    ("scipy",    "python3-scipy",   "scipy",    "FFT processing"),
    ("tifffile",     None,              "tifffile",      "16-bit TIFF support"),
    ("skimage",      None,              "scikit-image",  "CLAHE contrast enhancement"),
    ("tkinter",  "python3-tk",      None,       "GUI toolkit"),
]

# ─────────────────────────────────────────────────────────────
#  System helpers
# ─────────────────────────────────────────────────────────────

def detect_distro():
    """Return ('debian'|'fedora'|'arch'|'unknown', pretty_name)."""
    try:
        with open("/etc/os-release") as f:
            data = dict(line.strip().split("=", 1) for line in f
                        if "=" in line)
        name = data.get("PRETTY_NAME", "Linux").strip('"')
        id_like = data.get("ID_LIKE", "") + " " + data.get("ID", "")
        if any(x in id_like for x in ("debian", "ubuntu", "mint")):
            return "debian", name
        elif any(x in id_like for x in ("fedora", "rhel", "centos")):
            return "fedora", name
        elif "arch" in id_like:
            return "arch", name
        else:
            return "unknown", name
    except Exception:
        return "unknown", platform.system()


def get_pkg_manager():
    for pm in ["apt-get", "apt", "dnf", "yum", "pacman", "zypper"]:
        if shutil.which(pm):
            return pm
    return None


def is_root():
    return os.geteuid() == 0


def can_sudo():
    """Check if current user can run sudo (without password prompt)."""
    try:
        r = subprocess.run(["sudo", "-n", "true"],
                           capture_output=True, timeout=3)
        return r.returncode == 0
    except Exception:
        return False


def check_pkg_importable(import_name):
    try:
        __import__(import_name)
        return True
    except ImportError:
        return False


def pip_install(pkg_name, log_fn=None):
    """Install a pip package, with --break-system-packages fallback for PEP 668."""
    for extra in [["--user"], ["--user", "--break-system-packages"], ["--break-system-packages"]]:
        cmd = [sys.executable, "-m", "pip", "install", pkg_name,
               "--upgrade", "--quiet"] + extra
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True)
        out = []
        for line in proc.stdout:
            out.append(line.rstrip())
            if log_fn:
                log_fn(line.rstrip())
        proc.wait()
        if proc.returncode == 0:
            return 0
        # If error mentions externally-managed, retry without --user
        combined = "\n".join(out).lower()
        if "externally-managed" not in combined and "break-system-packages" not in combined:
            break  # real failure, not a PEP 668 issue
    return proc.returncode


def apt_install(pkg_name, log_fn=None, use_sudo=True):
    """Install an apt package."""
    prefix = ["sudo", "-S"] if use_sudo and not is_root() else []
    cmd = prefix + ["apt-get", "install", "-y", pkg_name]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True,
                             env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"})
    for line in proc.stdout:
        if log_fn:
            log_fn(line.rstrip())
    proc.wait()
    return proc.returncode


def add_to_path_profile(directory):
    """Add directory to ~/.bashrc and ~/.profile."""
    line = f'\nexport PATH="$PATH:{directory}"  # Added by Kepler installer\n'
    modified = []
    for rc_file in [os.path.expanduser("~/.bashrc"),
                    os.path.expanduser("~/.profile")]:
        try:
            existing = ""
            if os.path.exists(rc_file):
                with open(rc_file) as f:
                    existing = f.read()
            if directory not in existing:
                with open(rc_file, "a") as f:
                    f.write(line)
                modified.append(rc_file)
        except Exception:
            pass
    return modified


def create_desktop_entry(install_dir, icon_path=None, create_desktop_icon=True):
    """Create .desktop file for app menu and optionally the Desktop."""
    icon = icon_path or "kepler-installer"
    entry = (
        "[Desktop Entry]\n"
        "Name=Kepler\n"
        "GenericName=Planetary Image Processor\n"
        "Comment=Advanced planetary astronomy image processing suite\n"
        f"Exec=python3 {install_dir}/main.py\n"
        f"Icon={icon}\n"
        "Terminal=false\n"
        "Type=Application\n"
        "Categories=Graphics;Science;Education;Astronomy;\n"
        "Keywords=astronomy;planet;image;sharpen;wavelet;\n"
        "StartupWMClass=kepler\n"
        "StartupNotify=true\n"
    )
    # Application menu entry
    os.makedirs(DESKTOP_FILE_DIR, exist_ok=True)
    menu_path = os.path.join(DESKTOP_FILE_DIR, "kepler.desktop")
    with open(menu_path, "w") as f:
        f.write(entry)
    os.chmod(menu_path, 0o755)
    # Desktop shortcut (~~/Desktop/Kepler.desktop)
    if create_desktop_icon:
        desktop_dir = os.path.expanduser("~/Desktop")
        if os.path.isdir(desktop_dir):
            desktop_file = os.path.join(desktop_dir, "Kepler.desktop")
            with open(desktop_file, "w") as f:
                f.write(entry)
            os.chmod(desktop_file, 0o755)
            try:
                # Mark trusted so Cinnamon shows it as a launchable icon
                subprocess.run(["gio", "set", desktop_file,
                                "metadata::trusted", "true"],
                               capture_output=True)
            except Exception:
                pass
    # Refresh desktop database
    try:
        subprocess.run(["update-desktop-database",
                        DESKTOP_FILE_DIR], capture_output=True)
    except Exception:
        pass
    return menu_path


# ─────────────────────────────────────────────────────────────
#  GUI Installer
# ─────────────────────────────────────────────────────────────

class KeplerInstallerLinux(tk.Tk):
    def __init__(self):
        # Immediate startup log — written before anything else
        try:
            import traceback
            with open("/tmp/kepler_icon.log", "w") as _dbg:
                _dbg.write("=== Kepler installer started ===\n")
                _dbg.write(f"__file__: {__file__}\n")
                _dbg.write(f"Python: {sys.executable}\n")
                import os as _os
                _here = _os.path.dirname(_os.path.abspath(__file__))
                _dbg.write(f"_here: {_here}\n")
                for _name in ["icon.png", "icon.ico"]:
                    for _up in ["", "..", "../.."]:
                        _p = _os.path.abspath(_os.path.join(_here, _up, _name)) if _up else _os.path.abspath(_os.path.join(_here, _name))
                        _dbg.write(f"  {_p}  exists={_os.path.isfile(_p)}\n")
        except Exception as _e:
            pass  # can't log, continue anyway

        super().__init__()
        self.title("Kepler Installer")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        # Set window icon — identical approach to main.py which works on Linux Mint.
        # By the time install.sh launches this GUI, python3-pil.imagetk is installed.
        _here = os.path.dirname(os.path.abspath(__file__))
        _ico  = os.path.abspath(os.path.join(_here, "..", "..", "icon.ico"))
        if not os.path.isfile(_ico):
            _ico = None
        def _apply_icon():
            if not _ico:
                return
            try:
                from PIL import Image, ImageTk
                img   = Image.open(_ico)
                sizes = img.info.get("sizes", {img.size})
                best  = max(sizes, key=lambda s: s[0])
                img   = img.resize(best, Image.LANCZOS).convert("RGBA")
                photo = ImageTk.PhotoImage(img)
                self.iconphoto(True, photo)
                self._icon_img = photo  # prevent GC
            except Exception:
                pass
        self.after(0, _apply_icon)

        self.update_idletasks()
        self._sw = self.winfo_screenwidth()
        self._sh = self.winfo_screenheight()
        self._win_w = max(700, min(860, int(self._sw * 0.58)))
        self.geometry(f"{self._win_w}x500")  # placeholder; fitted after render

        self.current_step = 0
        self.steps = [
            self._page_welcome,
            self._page_permissions,
            self._page_checks,
            self._page_options,
            self._page_install,
            self._page_done,
        ]
        self.install_dir  = tk.StringVar(value=INSTALL_DIR_DEFAULT)
        self.create_menu         = tk.BooleanVar(value=True)
        self.create_desktop_icon = tk.BooleanVar(value=True)
        self.add_to_path         = tk.BooleanVar(value=True)
        self.create_bin          = tk.BooleanVar(value=True)
        self._distro, self._distro_name = detect_distro()
        self._pkg_manager = get_pkg_manager()
        self._python_exe  = sys.executable
        self._missing_apt = []
        self._missing_pip = []
        self._sudo_pass   = None

        self._build_chrome()
        self._show_step(0)

    def _build_chrome(self):
        hdr = self._hdr_frame = tk.Frame(self, bg=BG_PANEL, height=80)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        c = tk.Canvas(hdr, width=60, height=60, bg=BG_PANEL,
                      highlightthickness=0)
        c.pack(side="left", padx=16, pady=10)
        c.create_oval(10, 10, 50, 50, fill="#c06010", outline="#ffd060", width=2)
        c.create_oval(14, 14, 46, 46, fill="#904008", outline="")
        c.create_oval(4, 24, 56, 36, outline="#d0a040", width=2, fill="")
        for sx, sy in [(3,5),(55,8),(2,55),(58,50),(30,3),(28,57)]:
            c.create_oval(sx, sy, sx+2, sy+2, fill="white", outline="")

        tf = tk.Frame(hdr, bg=BG_PANEL)
        tf.pack(side="left", pady=10)
        tk.Label(tf, text="KEPLER", bg=BG_PANEL, fg=ACCENT,
                 font=("Monospace", 22, "bold")).pack(anchor="w")
        tk.Label(tf, text=f"Planetary Image Processing Suite  ·  v{KEPLER_VERSION}  ·  {self._distro_name}",
                 bg=BG_PANEL, fg=FG_MID,
                 font=("Monospace", 9)).pack(anchor="w")

        self.breadcrumb_var = tk.StringVar(value="")
        tk.Label(hdr, textvariable=self.breadcrumb_var,
                 bg=BG_PANEL, fg=FG_DIM,
                 font=("Monospace", 8)).pack(side="right", padx=16)

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")
        self.content = tk.Frame(self, bg=BG, padx=28, pady=18)
        self.content.pack(fill="both", expand=True)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        nav = self._nav_frame = tk.Frame(self, bg=BG_PANEL, height=54)
        nav.pack(fill="x")
        nav.pack_propagate(False)

        self.btn_back = tk.Button(nav, text="◀  Back",
                                   command=self._back,
                                   bg=BG_RAISED, fg=FG_MID,
                                   font=("Monospace", 10), relief="flat",
                                   cursor="hand2", padx=16, pady=6,
                                   activebackground=BORDER)
        self.btn_back.pack(side="left", padx=(20, 8), pady=10)

        self.btn_next = tk.Button(nav, text="Next  ▶",
                                   command=self._next,
                                   bg=ACCENT, fg=BG,
                                   font=("Monospace", 10, "bold"), relief="flat",
                                   cursor="hand2", padx=20, pady=6,
                                   activebackground="#00aacc")
        self.btn_next.pack(side="right", padx=(8, 20), pady=10)

        self.btn_cancel = tk.Button(nav, text="Cancel",
                                     command=self._on_close,
                                     bg=BG_RAISED, fg=ACCENT_R,
                                     font=("Monospace", 9), relief="flat",
                                     cursor="hand2", padx=12, pady=6,
                                     activebackground=BORDER)
        self.btn_cancel.pack(side="right", padx=4, pady=10)

    def _clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()

    def _show_step(self, idx):
        self._clear_content()
        self.current_step = idx
        crumbs = ["Welcome", "Permissions", "System Check",
                  "Options", "Installing", "Complete"]
        self.breadcrumb_var.set("  ›  ".join(
            f"[{c}]" if i == idx else c for i, c in enumerate(crumbs)
        ))
        self.btn_back.configure(state="normal" if idx > 0 else "disabled")
        self.steps[idx]()
        self.after(10, self._fit_to_content)

    def _fit_to_content(self):
        """Resize the window to exactly fit the current page."""
        self.update_idletasks()
        chrome_h = (self._hdr_frame.winfo_reqheight() + 2 +
                    self._nav_frame.winfo_reqheight() + 2)
        content_h = self.content.winfo_reqheight()
        total_h = chrome_h + content_h + 4
        max_h = int(self._sh * 0.92)
        h = max(300, min(total_h, max_h))
        w = self._win_w
        x = (self._sw - w) // 2
        y = max(20, (self._sh - h) // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _next(self):
        if self.current_step < len(self.steps) - 1:
            self._show_step(self.current_step + 1)

    def _back(self):
        if self.current_step > 0:
            self._show_step(self.current_step - 1)

    def _on_close(self):
        if self.current_step == 5:
            self.destroy()
        elif messagebox.askyesno("Cancel", "Cancel the Kepler installation?"):
            self.destroy()

    def _heading(self, text, color=ACCENT):
        tk.Label(self.content, text=text, bg=BG, fg=color,
                 font=("Monospace", 14, "bold"), anchor="w").pack(fill="x", pady=(0, 6))

    def _para(self, text, color=FG_MID, size=9):
        tk.Label(self.content, text=text, bg=BG, fg=color,
                 font=("Monospace", size), justify="left",
                 wraplength=630, anchor="w").pack(fill="x", pady=2)

    def _divider(self):
        tk.Frame(self.content, bg=BORDER, height=1).pack(fill="x", pady=8)

    def _box(self, text, color=ACCENT, bg=BG_CARD):
        f = tk.Frame(self.content, bg=bg, padx=14, pady=10)
        f.pack(fill="x", pady=4)
        tk.Label(f, text=text, bg=bg, fg=color, font=("Monospace", 9),
                 justify="left", wraplength=580, anchor="w").pack(fill="x")

    # ── Page 0: Welcome ────────────────────────────────────
    def _page_welcome(self):
        self.btn_back.configure(state="disabled")
        self.btn_next.configure(text="Begin  ▶", state="normal")
        self._heading("Welcome to the Kepler Installer")
        self._para(
            f"This wizard will install Kepler on {self._distro_name}.\n\n"
            "Kepler is a professional planetary image processing suite with\n"
            "wavelet sharpening, FFT denoising, RGB balance, and deringing."
        )
        self._divider()
        self._para("This installer will:", color=FG_BRIGHT)
        for item in [
            f"✔  Detected system: {self._distro_name}",
            "✔  Check Python 3.8+ (install if missing)",
            "✔  Check required libraries (NumPy, Pillow, SciPy, tifffile, scikit-image, tkinter)",
            "✔  Install missing libraries via apt/pip",
            "✔  Install Kepler to your chosen location",
            "✔  Create application menu entry (.desktop file)",
            "✔  Create 'kepler' command in PATH",
        ]:
            tk.Label(self.content, text="   " + item, bg=BG, fg=ACCENT_G,
                     font=("Monospace", 9), anchor="w").pack(fill="x")

    # ── Page 1: Permissions ────────────────────────────────
    def _page_permissions(self):
        self.btn_next.configure(text="I Understand  ▶", state="normal")
        self._heading("⚠  Permissions & sudo", color=ACCENT_O)

        if is_root():
            self._box("✔  Running as root — full system-wide installation available.",
                      color=ACCENT_G, bg="#001a00")
        elif can_sudo():
            self._box("✔  sudo is available and cached — admin tasks will proceed automatically.",
                      color=ACCENT_G, bg="#001a00")
        else:
            self._box(
                "⚠  sudo PASSWORD MAY BE REQUIRED\n\n"
                "Some steps require administrator (sudo) access:\n"
                "  • Installing system packages via apt-get\n"
                "  • Installing tkinter (python3-tk)\n\n"
                "You will be prompted for your password in the terminal\n"
                "where you ran this installer.\n\n"
                "If you are NOT a sudoer, the installer will fall back\n"
                "to pip --user installs where possible.",
                color=ACCENT_O, bg="#1a0e00"
            )

        self._divider()
        self._box(
            "WHAT WILL BE INSTALLED (system-level, requires sudo):\n\n"
            "  • python3-tk     — GUI toolkit (if missing)\n"
            "  • python3-pip    — pip package manager (if missing)\n\n"
            "WHAT WILL BE INSTALLED (user-level, NO sudo needed):\n\n"
            "  • numpy, Pillow, scipy  — via pip --user\n"
            "  • Kepler files          — in ~/.local/share/kepler\n"
            "  • 'kepler' command      — in ~/.local/bin/\n"
            "  • App menu entry        — in ~/.local/share/applications/",
            color=FG_MID, bg=BG_CARD
        )

        self._divider()
        self._box(
            "SUDO SAFETY NOTE\n\n"
            "This installer only calls sudo for package manager commands\n"
            "(apt-get install). You can inspect this script's source code\n"
            "at any time — it is plain Python in the installer folder.",
            color=FG_DIM, bg=BG_CARD
        )

    # ── Page 2: Checks ─────────────────────────────────────
    def _page_checks(self):
        self.btn_next.configure(text="Continue  ▶", state="disabled")
        self._heading("System Compatibility Check")
        self._para("Scanning your system...", color=FG_MID)
        self._divider()

        self.check_frame = tk.Frame(self.content, bg=BG)
        self.check_frame.pack(fill="x")

        self._check_labels = {}
        rows = [
            ("distro",   f"Distribution",           self._distro_name),
            ("python",   "Python 3.8+",              ""),
            ("pip",      "pip",                      ""),
            ("tkinter",  "tkinter (GUI)",             ""),
            ("numpy",    "NumPy",                     "scientific arrays"),
            ("pil",      "Pillow",                    "image I/O"),
            ("imagetk",  "Pillow ImageTk",            "Tk/PIL bridge"),
            ("scipy",    "SciPy",                     "FFT processing"),
            ("tifffile", "tifffile",                  "16-bit TIFF support"),
            ("skimage",  "scikit-image",              "CLAHE contrast enhancement"),
            ("pkgmgr",   "Package Manager",           self._pkg_manager or "none"),
        ]
        for key, label, note in rows:
            row = tk.Frame(self.check_frame, bg=BG_CARD, padx=12, pady=5)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=label, bg=BG_CARD, fg=FG_BRIGHT,
                     font=("Monospace", 9), width=24, anchor="w").pack(side="left")
            if note:
                tk.Label(row, text=f"  {note}", bg=BG_CARD, fg=FG_DIM,
                         font=("Monospace", 8)).pack(side="left")
            lbl = tk.Label(row, text="...", bg=BG_CARD,
                            fg=FG_DIM, font=("Monospace", 9, "bold"))
            lbl.pack(side="right", padx=8)
            self._check_labels[key] = lbl

        threading.Thread(target=self._run_checks, daemon=True).start()

    def _set_chk(self, key, text, color):
        self._check_labels[key].configure(text=text, fg=color)

    def _run_checks(self):
        time.sleep(0.3)

        self.after(0, lambda: self._set_chk("distro", f"{self._distro_name} ✔", ACCENT_G))

        # Python
        ver = platform.python_version()
        parts = tuple(int(x) for x in ver.split(".")[:2])
        if parts >= (3, 8):
            self.after(150, lambda: self._set_chk("python", f"{ver} ✔", ACCENT_G))
        else:
            self.after(150, lambda: self._set_chk("python", f"{ver} — Too old!", ACCENT_R))

        # pip
        try:
            subprocess.check_output([sys.executable, "-m", "pip", "--version"],
                                     stderr=subprocess.STDOUT)
            self.after(250, lambda: self._set_chk("pip", "Available ✔", ACCENT_G))
        except Exception:
            self.after(250, lambda: self._set_chk("pip", "Missing — will install", ACCENT_O))
            self._missing_apt.append("python3-pip")

        # Package manager
        if self._pkg_manager:
            self.after(300, lambda: self._set_chk("pkgmgr",
                f"{self._pkg_manager} ✔", ACCENT_G))
        else:
            self.after(300, lambda: self._set_chk("pkgmgr",
                "Not found ⚠ (pip fallback)", ACCENT_O))

        # Individual packages
        delays = {"tkinter": 400, "numpy": 500, "pil": 600, "imagetk": 650, "scipy": 700, "tifffile": 800, "skimage": 850}
        pkg_info = {
            "tkinter":  ("tkinter",    "python3-tk",          None,       True),
            "numpy":    ("numpy",      "python3-numpy",       "numpy",    False),
            "pil":      ("PIL",        "python3-pil",         "Pillow",   False),
            "imagetk":  ("PIL.ImageTk","python3-pil.imagetk", None,       False),
            "scipy":    ("scipy",      "python3-scipy",       "scipy",    False),
            "tifffile": ("tifffile",   None,                  "tifffile",      False),
            "skimage":  ("skimage",    None,                  "scikit-image",  False),
        }
        self._missing_apt = []
        self._missing_pip = []

        for key, (imp, apt_pkg, pip_pkg, apt_only) in pkg_info.items():
            ok = check_pkg_importable(imp)
            d = delays[key]
            if ok:
                self.after(d, lambda k=key: self._set_chk(k, "Installed ✔", ACCENT_G))
            else:
                self.after(d, lambda k=key: self._set_chk(k, "Missing — will install", ACCENT_O))
                if self._pkg_manager and "apt" in self._pkg_manager and apt_pkg is not None:
                    self._missing_apt.append(apt_pkg)
                if pip_pkg:
                    self._missing_pip.append(pip_pkg)

        self.after(900, self._checks_done)

    def _checks_done(self):
        self.btn_next.configure(state="normal")
        total = len(set(self._missing_apt + self._missing_pip))
        if total:
            tk.Label(self.content,
                     text=f"⚠  {total} package(s) will be installed automatically.",
                     bg=BG, fg=ACCENT_O, font=("Monospace", 9)
                     ).pack(pady=(8, 0))
        else:
            tk.Label(self.content,
                     text="✔  All requirements met — installation will be fast.",
                     bg=BG, fg=ACCENT_G, font=("Monospace", 9)
                     ).pack(pady=(8, 0))

    # ── Page 3: Options ────────────────────────────────────
    def _page_options(self):
        self.btn_next.configure(text="Install  ▶", state="normal")
        self._heading("Installation Options")

        self._para("Installation Directory:", color=FG_BRIGHT)
        df = tk.Frame(self.content, bg=BG)
        df.pack(fill="x", pady=4)
        tk.Entry(df, textvariable=self.install_dir,
                 bg=BG_RAISED, fg=FG_BRIGHT, insertbackground=ACCENT,
                 font=("Monospace", 9), relief="flat",
                 highlightthickness=1, highlightbackground=BORDER,
                 highlightcolor=ACCENT).pack(side="left", fill="x",
                                              expand=True, padx=(0, 6))
        tk.Button(df, text="Browse...", command=self._browse,
                  bg=BG_RAISED, fg=ACCENT, font=("Monospace", 9),
                  relief="flat", cursor="hand2", padx=8, pady=4,
                  activebackground=BORDER).pack(side="left")

        self._divider()
        self._para("Options:", color=FG_BRIGHT)
        for var, lbl in [
            (self.create_menu,         "Create application menu entry  (.desktop file)"),
            (self.create_desktop_icon, "Create a Desktop shortcut"),
            (self.create_bin,          f"Create 'kepler' command  ({os.path.dirname(BIN_LINK)})"),
            (self.add_to_path,         "Add ~/.local/bin to PATH  (in ~/.bashrc and ~/.profile)"),
        ]:
            tk.Checkbutton(self.content, text=lbl, variable=var,
                           bg=BG, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                           activebackground=BG, activeforeground=ACCENT,
                           font=("Monospace", 9),
                           highlightthickness=0).pack(anchor="w", pady=2)

        self._divider()
        self._box(
            "Estimated disk space:\n"
            f"  Kepler app files:        ~1 MB\n"
            f"  NumPy (if needed):      ~20 MB\n"
            f"  Pillow (if needed):      ~8 MB\n"
            f"  SciPy (if needed):      ~35 MB\n"
            f"  tifffile (if needed):    ~1 MB\n"
            f"  scikit-image (if needed):~10 MB\n"
            f"  ──────────────────────────────\n"
            f"  Total (worst case):    ~75 MB",
            color=FG_MID, bg=BG_CARD
        )

        if self._missing_apt:
            needs_sudo = not is_root() and not can_sudo()
            if needs_sudo:
                self._box(
                    "⚠  Some packages require apt-get (sudo):\n"
                    f"   {', '.join(self._missing_apt)}\n\n"
                    "You may be prompted for your password in the\n"
                    "terminal window where you launched this installer.",
                    color=ACCENT_O, bg="#1a0e00"
                )

    def _browse(self):
        d = filedialog.askdirectory(title="Choose Installation Folder")
        if d:
            self.install_dir.set(os.path.join(d, "kepler"))

    # ── Page 4: Installing ─────────────────────────────────
    def _page_install(self):
        self.btn_next.configure(state="disabled")
        self.btn_back.configure(state="disabled")
        self.btn_cancel.configure(state="disabled")
        self._heading("Installing Kepler...")

        self.prog_label = tk.Label(self.content, text="Starting...",
                                    bg=BG, fg=ACCENT, font=("Monospace", 9))
        self.prog_label.pack(anchor="w")

        style = ttk.Style()
        style.configure("KL.Horizontal.TProgressbar",
                        troughcolor=BG_RAISED, background=ACCENT,
                        lightcolor=ACCENT, darkcolor=ACCENT)
        self.prog_bar = ttk.Progressbar(self.content,
                                         style="KL.Horizontal.TProgressbar",
                                         length=640, maximum=100)
        self.prog_bar.pack(pady=6)

        lf = tk.Frame(self.content, bg="#000000",
                      highlightthickness=1, highlightbackground=BORDER)
        lf.pack(fill="both", expand=True, pady=4)
        self.log_text = tk.Text(lf, bg="#000000", fg="#00ff88",
                                 font=("Monospace", 8), relief="flat",
                                 state="disabled", wrap="word")
        sb = ttk.Scrollbar(lf, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_text.pack(fill="both", expand=True, padx=4, pady=4)

        threading.Thread(target=self._do_install, daemon=True).start()

    def _log(self, msg):
        def _up():
            self.log_text.configure(state="normal")
            self.log_text.insert("end", msg + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.after(0, _up)

    def _set_prog(self, pct, label=""):
        def _up():
            self.prog_bar["value"] = pct
            if label:
                self.prog_label.configure(text=label)
        self.after(0, _up)

    def _do_install(self):
        install_dir = self.install_dir.get()
        # install_linux.py lives in installer/linux/ — walk up to project root
        _here = os.path.dirname(os.path.abspath(__file__))
        source_dir = _here
        for _ in range(4):
            if os.path.exists(os.path.join(source_dir, "main.py")):
                break
            source_dir = os.path.dirname(source_dir)

        try:
            # ── 1: apt packages ─────────────────────────────
            if self._missing_apt and self._pkg_manager and "apt" in self._pkg_manager:
                self._set_prog(5, "Installing system packages via apt-get...")
                self._log("Running: sudo apt-get update")
                subprocess.run(
                    ["sudo", "apt-get", "update", "-qq"],
                    capture_output=True,
                    env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"}
                )
                for i, pkg in enumerate(set(self._missing_apt)):
                    pct = 8 + int(i / len(self._missing_apt) * 20)
                    self._set_prog(pct, f"Installing {pkg} via apt-get...")
                    self._log(f"apt-get install -y {pkg}")
                    rc = apt_install(pkg, self._log, use_sudo=not is_root())
                    if rc == 0:
                        self._log(f"  ✔ {pkg} installed")
                    else:
                        self._log(f"  ⚠ apt failed for {pkg} — will try pip")
                        # Add pip fallback
                        apt_to_pip = {
                            "python3-numpy":       "numpy",
                            "python3-pil":         "Pillow",
                            "python3-pil.imagetk": None,
                            "python3-scipy":       "scipy",
                        }
                        if pkg in apt_to_pip and apt_to_pip[pkg] not in self._missing_pip:
                            self._missing_pip.append(apt_to_pip[pkg])

            # ── 2: pip packages ─────────────────────────────
            self._set_prog(30, "Installing Python packages via pip...")
            self._log("Upgrading pip...")
            subprocess.run([sys.executable, "-m", "pip", "install",
                            "--upgrade", "pip", "--user", "--quiet"],
                           capture_output=True)

            for i, pkg in enumerate(self._missing_pip):
                pct = 33 + int(i / max(len(self._missing_pip), 1) * 30)
                self._set_prog(pct, f"Installing {pkg} via pip...")
                self._log(f"pip install --user {pkg}")
                rc = pip_install(pkg, self._log)
                if rc == 0:
                    self._log(f"  ✔ {pkg} installed")
                else:
                    self._log(f"  ⚠ pip failed for {pkg}")

            # Final safety net: install everything from requirements.txt
            # This catches any package that slipped through the checks
            req_file = os.path.join(source_dir, "requirements.txt")
            if os.path.exists(req_file):
                self._log("Installing from requirements.txt (safety net)...")
                # Try --user first, fall back to --break-system-packages (PEP 668)
                for extra in [["--user"], ["--user", "--break-system-packages"]]:
                    r = subprocess.run(
                        [sys.executable, "-m", "pip", "install", "-r", req_file,
                         "--quiet"] + extra,
                        capture_output=True, text=True)
                    if r.returncode == 0:
                        break
                self._log("  ✔ requirements.txt processed")

            self._set_prog(63, "Dependencies ready.")

            # ── 3: Copy Kepler files ─────────────────────────
            self._set_prog(65, f"Installing Kepler to {install_dir}...")
            self._log(f"Creating directory: {install_dir}")
            os.makedirs(install_dir, exist_ok=True)

            files = ["main.py", "app.py", "processing.py", "requirements.txt"]
            for fname in files:
                src = os.path.join(source_dir, fname)
                dst = os.path.join(install_dir, fname)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    self._log(f"  Copied {fname}")
                else:
                    self._log(f"  ⚠ {fname} not found at {src}")

            # Copy icon
            for icon_name in ["icon.ico", "icon.png", "kepler.ico", "kepler.png"]:
                src = os.path.join(source_dir, icon_name)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(install_dir, icon_name))
                    self._log(f"  Copied {icon_name}")
                    break

            self._set_prog(75, "Files installed.")

            # ── 4: Create launcher script ────────────────────
            # Use the exact Python interpreter that is running this installer
            python_exe = sys.executable
            launcher_sh = os.path.join(install_dir, "kepler.sh")
            with open(launcher_sh, "w") as f:
                f.write("#!/bin/bash\n")
                f.write(f'cd "{install_dir}"\n')
                f.write(f'exec "{python_exe}" "{install_dir}/main.py" "$@"\n')
            os.chmod(launcher_sh, 0o755)
            self._log(f"  Launcher: {launcher_sh}")

            # ── 5: ~/.local/bin/kepler symlink ──────────────
            if self.create_bin.get():
                bin_dir = os.path.dirname(BIN_LINK)
                os.makedirs(bin_dir, exist_ok=True)
                if os.path.exists(BIN_LINK) or os.path.islink(BIN_LINK):
                    os.unlink(BIN_LINK)
                os.symlink(launcher_sh, BIN_LINK)
                self._log(f"  Command: {BIN_LINK} → {launcher_sh}")

            self._set_prog(82, "Launcher created.")

            # ── 6: PATH update ──────────────────────────────
            if self.add_to_path.get():
                bin_dir = os.path.dirname(BIN_LINK)
                modified = add_to_path_profile(bin_dir)
                if modified:
                    self._log(f"  PATH updated in: {', '.join(modified)}")
                    self._log("  Run 'source ~/.bashrc' or open a new terminal.")
                else:
                    self._log("  PATH already contains ~/.local/bin")

            # ── 7: .desktop file ────────────────────────────
            if self.create_menu.get():
                self._set_prog(88, "Creating application menu entry...")
                # Find the copied icon in install_dir
                _icon_path = None
                for _iname in ["icon.ico", "icon.png", "kepler.ico", "kepler.png"]:
                    _candidate = os.path.join(install_dir, _iname)
                    if os.path.exists(_candidate):
                        _icon_path = _candidate
                        break
                dp = create_desktop_entry(install_dir, icon_path=_icon_path,
                                               create_desktop_icon=self.create_desktop_icon.get())
                self._log(f"  Desktop entry: {dp}")

            # ── 8: Uninstall script ──────────────────────────
            uninstall = os.path.join(install_dir, "uninstall.sh")
            with open(uninstall, "w") as f:
                f.write("#!/bin/bash\n")
                f.write("echo 'Uninstalling Kepler...'\n")
                f.write(f'rm -rf "{install_dir}"\n')
                f.write(f'rm -f "{BIN_LINK}"\n')
                f.write(f'rm -f "{DESKTOP_FILE_DIR}/kepler.desktop"\n')
                f.write("echo 'Kepler uninstalled.'\n")
            os.chmod(uninstall, 0o755)
            self._log(f"  Uninstaller: {uninstall}")

            # ── 9: Write install log ─────────────────────────
            log_path = os.path.join(install_dir, "install.log")
            with open(log_path, "w") as f:
                f.write(f"Kepler v{KEPLER_VERSION} installation log\n")
                f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"System: {self._distro_name}\n")
                f.write(f"Python: {platform.python_version()}\n")
                f.write(f"Install dir: {install_dir}\n")

            self._set_prog(100, "Installation complete!")
            self._log("\n✔  Kepler installation complete!")
            self._log(f"   Location: {install_dir}")
            self._log("   Launch: kepler  (in a new terminal)")
            self._log("   Or from Applications menu → Kepler")

            self.after(800, self._next)

        except Exception as e:
            self._log(f"\nFATAL ERROR: {e}")
            import traceback
            self._log(traceback.format_exc())
            self.after(0, lambda: messagebox.showerror(
                "Error", f"Installation failed:\n{e}"))
            self.after(0, lambda: self.btn_cancel.configure(state="normal"))

    # ── Page 5: Done ───────────────────────────────────────
    def _page_done(self):
        self.btn_next.configure(text="Finish", state="normal",
                                 bg=ACCENT_G, fg=BG)
        self.btn_back.configure(state="disabled")
        self.btn_cancel.configure(state="disabled")

        self._heading("✔  Kepler Successfully Installed!", color=ACCENT_G)
        self._para(f"Installation directory:", color=FG_MID)
        self._para(f"   {self.install_dir.get()}", color=ACCENT)
        self._divider()

        self._box(
            "You can now launch Kepler from:\n\n"
            "  •  Applications menu  →  Kepler   (after re-login if needed)\n"
            "  •  Terminal:  kepler\n"
            "  •  Direct:    python3 " + self.install_dir.get() + "/main.py\n\n"
            "To uninstall:  bash " + self.install_dir.get() + "/uninstall.sh",
            color=ACCENT_G, bg="#001a00"
        )
        self._divider()
        self._box(
            "NOTE: If 'kepler' command is not found in terminal,\n"
            "run:  source ~/.bashrc\nor open a new terminal window.",
            color=ACCENT_O, bg="#1a0e00"
        )

        launch_var = tk.BooleanVar(value=True)
        tk.Checkbutton(self.content,
                       text="Launch Kepler now",
                       variable=launch_var,
                       bg=BG, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                       activebackground=BG, font=("Monospace", 9),
                       highlightthickness=0).pack(anchor="w", pady=(10, 0))

        def finish():
            if launch_var.get():
                main_py = os.path.join(self.install_dir.get(), "main.py")
                if os.path.exists(main_py):
                    subprocess.Popen([sys.executable, main_py],
                                     cwd=self.install_dir.get())
            self.destroy()

        self.btn_next.configure(command=finish)


# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Verify we have tkinter
    try:
        import tkinter
    except ImportError:
        print("ERROR: tkinter is not installed.")
        print("Install with: sudo apt install python3-tk")
        sys.exit(1)

    app = KeplerInstallerLinux()
    app.mainloop()

"""
app.py – Kepler  v1.1
· Live processing as sliders move (debounced 400 ms)
· Right-click OR double-click any slider → reset to default
· Per-tab Reset (resets that tab's sliders only)
· Global Reset button (resets image + all sliders)
· Wavelet tab: clear workflow sections (Manual / Filter / Auto)
· Histogram: annotated with shadow / mid-tone / highlight regions
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
import json
from PIL import Image, ImageTk, ImageDraw
import numpy as np

import processing as proc

# ─────────────────────────────────────────────────────────────
#  Colours
# ─────────────────────────────────────────────────────────────
BG_DEEP    = "#f0f4f8"
BG_PANEL   = "#e2e8f0"
BG_CARD    = "#ffffff"
BG_RAISED  = "#cbd5e1"
SLIDER_TRG = "#b0bec5"
SLIDER_THM = "#334155"
FG_BRIGHT  = "#090d19"
FG_MID     = "#1c232e"
FG_DIM     = "#373f4c"
ACCENT_C   = "#013958"
ACCENT_O   = "#6a2306"
ACCENT_G   = "#0b4621"
ACCENT_P   = "#441f82"
ACCENT_R   = "#dc2626"
BORDER     = "#94a3b8"
SEL_BG     = "#bfdbfe"

# ─────────────────────────────────────────────────────────────
#  Fonts
# ─────────────────────────────────────────────────────────────
F_TINY = ("Consolas", 11)
F_SM   = ("Consolas", 12)
F_MD   = ("Consolas", 13)
F_BOLD = ("Consolas", 15, "bold")
F_HDR  = ("Consolas", 19, "bold")

PREV_W, PREV_H = 400, 300
PREFS_FILE = os.path.join(os.path.expanduser("~"), ".kepler_prefs.json")

# ─────────────────────────────────────────────────────────────
#  Prefs
# ─────────────────────────────────────────────────────────────
def load_prefs():
    try:
        with open(PREFS_FILE) as f: return json.load(f)
    except Exception: return {}

def save_prefs(data):
    try:
        d = load_prefs(); d.update(data)
        with open(PREFS_FILE, "w") as f: json.dump(d, f)
    except Exception: pass

# ─────────────────────────────────────────────────────────────
#  LabeledSlider  — right-click or double-click resets to default
# ─────────────────────────────────────────────────────────────
class LabeledSlider(tk.Frame):
    def __init__(self, parent, label, from_, to_, initial,
                 color=ACCENT_C, fmt="{:.0f}", callback=None, resolution=None, **kw):
        super().__init__(parent, bg=BG_CARD, **kw)
        self._default  = initial
        self.fmt       = fmt
        self.callback  = callback
        self.var       = tk.DoubleVar(value=initial)
        self._dragging = False   # True while mouse button held on slider

        # Auto-derive resolution from format string if not supplied
        if resolution is None:
            if callable(fmt):
                resolution = 1
            else:
                import re
                m = re.search(r'\.(\d+)f', fmt)
                decimals = int(m.group(1)) if m else 0
                resolution = 10 ** (-decimals) if decimals > 0 else 1

        self._lbl = tk.Label(self, text=label, bg=BG_CARD, fg=FG_MID,
                             font=F_SM, anchor="w")
        self._lbl.pack(side="left", padx=(0, 4))

        self.scale = tk.Scale(
            self, from_=from_, to=to_, orient="horizontal",
            variable=self.var, showvalue=False, length=160,
            resolution=resolution,
            troughcolor=SLIDER_TRG, bg=BG_CARD, fg=SLIDER_THM,
            activebackground=color, highlightthickness=0, bd=0,
            sliderrelief="raised", sliderlength=14,
            command=self._on_change)
        self.scale.pack(side="left", fill="x", expand=True, padx=2)

        self.val_lbl = tk.Label(self, text=fmt(initial) if callable(fmt) else fmt.format(initial),
                                bg=BG_CARD, fg=color, font=F_MD,
                                width=7, anchor="e")
        self.val_lbl.pack(side="left")

        # Suppress live pipeline during drag; fire once on release
        self.scale.bind("<ButtonPress-1>",   self._drag_start)
        self.scale.bind("<ButtonRelease-1>", self._drag_end)

        # Right-click or double-click → reset to default
        for w in (self.scale, self._lbl, self.val_lbl):
            w.bind("<Button-3>",       lambda e: self.reset())
            w.bind("<Double-Button-1>",lambda e: self.reset())

    def _drag_start(self, event):
        self._dragging = True

    def _drag_end(self, event):
        self._dragging = False
        # Fire callback once with final value after drag ends
        if self.callback:
            self.callback(self.var.get())

    def _on_change(self, v):
        val = float(v)
        self.val_lbl.configure(text=self.fmt(val) if callable(self.fmt) else self.fmt.format(val))
        # Only fire pipeline callback if not mid-drag
        if not self._dragging and self.callback:
            self.callback(val)

    def get(self):   return self.var.get()
    def set(self, v, fire_callback=True):
        self.var.set(v)
        self.val_lbl.configure(text=self.fmt(v) if callable(self.fmt) else self.fmt.format(v))
        if fire_callback and self.callback:
            self.callback(v)

    def reset(self):
        self.set(self._default, fire_callback=True)

# ─────────────────────────────────────────────────────────────
#  ToggleVar
# ─────────────────────────────────────────────────────────────
class ToggleVar(tk.Frame):
    def __init__(self, parent, label, sublabel="", initial=True, command=None, **kw):
        super().__init__(parent, bg=BG_CARD, **kw)
        self._default = initial
        self.var      = tk.BooleanVar(value=initial)
        tk.Checkbutton(self, text=label, variable=self.var,
                       bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                       activebackground=BG_CARD, activeforeground=ACCENT_C,
                       font=F_SM, anchor="w", indicatoron=True,
                       command=command).pack(side="left")
        if sublabel:
            tk.Label(self, text=sublabel, bg=BG_CARD,
                     fg=FG_DIM, font=F_TINY).pack(side="left", padx=4)
    def get(self):   return self.var.get()
    def reset(self): self.var.set(self._default)

# ─────────────────────────────────────────────────────────────
#  UI helpers
# ─────────────────────────────────────────────────────────────
def section_header(parent, text, color=ACCENT_C):
    f = tk.Frame(parent, bg=BG_PANEL)
    f.pack(fill="x", pady=(8,3))
    tk.Label(f, text=f"  {text}  ", bg=color, fg="white",
             font=F_SM).pack(side="left")
    tk.Frame(f, bg=BORDER, height=1).pack(side="left", fill="x",
                                          expand=True, padx=4)
    return f

def card_frame(parent, title=None, color=ACCENT_C, subtitle=None):
    outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    outer.pack(fill="x", padx=6, pady=3)
    inner = tk.Frame(outer, bg=BG_CARD, padx=10, pady=8)
    inner.pack(fill="both", expand=True)
    if title:
        hf = tk.Frame(inner, bg=BG_CARD)
        hf.pack(fill="x", pady=(0,4))
        tk.Label(hf, text=title, bg=BG_CARD, fg=color,
                 font=F_MD).pack(side="left")
        if subtitle:
            tk.Label(hf, text=f"  {subtitle}", bg=BG_CARD,
                     fg=FG_DIM, font=F_TINY).pack(side="left")
    return inner

# ─────────────────────────────────────────────────────────────
#  ZoomWindow
# ─────────────────────────────────────────────────────────────
class ZoomWindow:
    def __init__(self, root, title, get_pil_fn):
        self.get_pil_fn = get_pil_fn
        self._zoom = 1.0; self._pan_x = 0; self._pan_y = 0
        self._drag_x = 0; self._drag_y = 0
        win = tk.Toplevel(root); win.title(title)
        win.geometry("900x720"); win.configure(bg=BG_PANEL)
        self.win = win
        tb = tk.Frame(win, bg=BG_PANEL); tb.pack(fill="x", padx=6, pady=4)
        def zb(txt, cmd, w=3):
            return tk.Button(tb, text=txt, command=cmd, bg=BG_RAISED,
                             fg=FG_MID, font=F_BOLD, relief="flat",
                             cursor="hand2", width=w, padx=4, pady=2,
                             activebackground=SEL_BG)
        zb("−", self._zoom_out).pack(side="left", padx=(0,1))
        self.zoom_lbl = tk.Label(tb, text="100%", bg=BG_RAISED,
                                 fg=ACCENT_C, font=F_BOLD, width=6,
                                 relief="flat", padx=4)
        self.zoom_lbl.pack(side="left")
        zb("+", self._zoom_in).pack(side="left", padx=(1,6))
        for pct, lbl in [(25,"25%"),(50,"50%"),(100,"100%"),(200,"200%"),(400,"400%")]:
            zb(lbl, lambda v=pct: self._set_zoom(v/100), w=4).pack(side="left",padx=1)
        zb("Fit", self._fit).pack(side="left", padx=(6,0))
        tk.Label(tb, text="  scroll/+− zoom  ·  drag pan",
                 bg=BG_PANEL, fg=FG_DIM, font=F_TINY).pack(side="left", padx=6)
        self.canvas = tk.Canvas(win, bg="#606060", highlightthickness=0, cursor="fleur")
        self.canvas.pack(fill="both", expand=True, padx=4, pady=(0,4))
        for ev in ("<MouseWheel>","<Button-4>","<Button-5>"):
            self.canvas.bind(ev, self._on_wheel)
        self.canvas.bind("<ButtonPress-1>", lambda e: setattr(self,'_drag_x',e.x) or setattr(self,'_drag_y',e.y))
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<Configure>", lambda e: self._redraw())
        win.bind("<plus>",  lambda e: self._zoom_in())
        win.bind("<equal>", lambda e: self._zoom_in())
        win.bind("<minus>", lambda e: self._zoom_out())
        self._redraw()

    def _zoom_in(self):  self._set_zoom(self._zoom * 1.25)
    def _zoom_out(self): self._set_zoom(self._zoom / 1.25)
    def _set_zoom(self, z):
        self._zoom = max(0.05, min(32.0, z))
        self.zoom_lbl.configure(text=f"{self._zoom*100:.0f}%")
        self._redraw()
    def _fit(self):
        pil = self.get_pil_fn()
        if pil is None: return
        cw = self.canvas.winfo_width() or 900
        ch = self.canvas.winfo_height() or 680
        self._zoom = min(cw/pil.width, ch/pil.height)*0.95
        self._pan_x = self._pan_y = 0
        self.zoom_lbl.configure(text=f"{self._zoom*100:.0f}%")
        self._redraw()
    def _on_wheel(self, e):
        f = 1.15 if not (e.num==5 or getattr(e,"delta",0)<0) else 1/1.15
        self._set_zoom(self._zoom * f)
    def _on_drag(self, e):
        self._pan_x += e.x - self._drag_x; self._pan_y += e.y - self._drag_y
        self._drag_x = e.x; self._drag_y = e.y; self._redraw()
    def _redraw(self):
        pil = self.get_pil_fn()
        if pil is None: return
        cw = self.canvas.winfo_width() or 900
        ch = self.canvas.winfo_height() or 680
        nw = max(1, int(pil.width*self._zoom)); nh = max(1, int(pil.height*self._zoom))
        resample = Image.NEAREST if self._zoom >= 1.0 else Image.LANCZOS
        res = pil.resize((nw,nh), resample)
        x=(cw-nw)//2+self._pan_x; y=(ch-nh)//2+self._pan_y
        t = ImageTk.PhotoImage(res)
        self.canvas.delete("all"); self.canvas.create_image(x,y,anchor="nw",image=t)
        self.canvas._img = t

# ─────────────────────────────────────────────────────────────
#  Click-to-lock Magnifier
# ─────────────────────────────────────────────────────────────
class StaticMagnifier:
    MAG_SIZE    = 440
    # patch_src = source pixels cropped; canvas fills to MAG_SIZE
    # x1 = patch equals canvas = 1:1 (same view as preview)
    # x2 = half patch, x4 = quarter patch
    ZOOM_LEVELS = [(440,"x1"),(220,"x2"),(110,"x4")]
    DEFAULT_IDX = 1     # start at x2

    def __init__(self, parent):
        self._zoom_idx  = self.DEFAULT_IDX
        self._last_pil  = None
        self._last_px   = 0
        self._last_py   = 0
        self._last_name = ""

        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.pack(fill="x", padx=6, pady=(0,6))
        inner = tk.Frame(outer, bg=BG_CARD, padx=6, pady=6)
        inner.pack(fill="both", expand=True)

        hdr = tk.Frame(inner, bg=BG_CARD)
        hdr.pack(fill="x", pady=(0,4))

        tk.Label(hdr, text="MAGNIFIER", bg=BG_CARD,
                 fg=ACCENT_C, font=F_SM).pack(side="left")

        zf = tk.Frame(hdr, bg=BG_CARD)
        zf.pack(side="left", padx=(8,0))
        tk.Button(zf, text="v", command=self._zoom_out,
                  bg=BG_RAISED, fg=FG_MID, font=F_TINY,
                  relief="flat", cursor="hand2", padx=4, pady=0,
                  activebackground=SEL_BG).pack(side="left")
        self._zoom_lbl = tk.Label(zf, text=self.ZOOM_LEVELS[self._zoom_idx][1],
                                  bg=BG_RAISED, fg=ACCENT_C, font=F_SM,
                                  width=4, anchor="center")
        self._zoom_lbl.pack(side="left", padx=2)
        tk.Button(zf, text="^", command=self._zoom_in,
                  bg=BG_RAISED, fg=FG_MID, font=F_TINY,
                  relief="flat", cursor="hand2", padx=4, pady=0,
                  activebackground=SEL_BG).pack(side="left")

        self.info_lbl = tk.Label(hdr, text="click a preview to magnify",
                                 bg=BG_CARD, fg=FG_DIM, font=F_TINY)
        self.info_lbl.pack(side="right")

        self.canvas = tk.Canvas(inner, width=self.MAG_SIZE, height=self.MAG_SIZE,
                                bg="#cccccc", highlightthickness=1,
                                highlightbackground=BORDER)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_resize)
        self._draw_idle()

    def _zoom_in(self):
        if self._zoom_idx < len(self.ZOOM_LEVELS)-1:
            self._zoom_idx += 1
            self._zoom_lbl.configure(text=self.ZOOM_LEVELS[self._zoom_idx][1])
            self._redraw()

    def _zoom_out(self):
        if self._zoom_idx > 0:
            self._zoom_idx -= 1
            self._zoom_lbl.configure(text=self.ZOOM_LEVELS[self._zoom_idx][1])
            self._redraw()

    def _redraw(self):
        if self._last_pil is not None:
            self.click_magnify(self._last_pil, self._last_px,
                               self._last_py, self._last_name)

    def _on_resize(self, event):
        w = event.width; h = event.height
        if w > 10 and h > 10:
            self.MAG_SIZE = min(w, h)
            self._redraw() if self._last_pil is not None else self._draw_idle()

    def _draw_idle(self):
        self.canvas.delete("all")
        sz = self.canvas.winfo_width() or self.MAG_SIZE
        self.canvas.create_text(sz//2, (self.canvas.winfo_height() or self.MAG_SIZE)//2,
                                text="click on\noriginal or processed\nto magnify",
                                fill=FG_DIM, font=F_SM, justify="center")

    def click_magnify(self, pil, px, py, source_name):
        self._last_pil  = pil
        self._last_px   = px
        self._last_py   = py
        self._last_name = source_name
        patch_src = self.ZOOM_LEVELS[self._zoom_idx][0]
        iw, ih = pil.size
        half   = patch_src // 2
        patch  = pil.crop((max(0,px-half), max(0,py-half),
                           min(iw,px+half), min(ih,py+half)))
        cw = max(self.canvas.winfo_width(),  self.MAG_SIZE)
        ch = max(self.canvas.winfo_height(), self.MAG_SIZE)
        # Scale patch uniformly to COVER the canvas (no grey bars, no distortion).
        # Use the larger scale factor so the image fills the pane on both axes,
        # then centre-crop the overflow.
        pw, ph2 = patch.size
        if pw < 1: pw = 1
        if ph2 < 1: ph2 = 1
        scale = max(cw / pw, ch / ph2)
        sw = max(1, int(pw * scale)); sh = max(1, int(ph2 * scale))
        zoomed = patch.resize((sw, sh), Image.NEAREST)
        # Centre-crop to canvas size
        ox = (sw - cw) // 2; oy = (sh - ch) // 2
        zoomed = zoomed.crop((ox, oy, ox + cw, oy + ch))
        d   = ImageDraw.Draw(zoomed)
        cx  = cw // 2; cy = ch // 2
        arm = max(30, min(cw, ch) // 10)
        d.line([(cx-arm,cy),(cx+arm,cy)], fill="#ff0000", width=2)
        d.line([(cx,cy-arm),(cx,cy+arm)], fill="#ff0000", width=2)
        t = ImageTk.PhotoImage(zoomed)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=t)
        self.canvas._img = t
        self.info_lbl.configure(text=f"{source_name}  ({px}, {py})")


# ─────────────────────────────────────────────────────────────
#  Annotated line histogram
# ─────────────────────────────────────────────────────────────
def draw_line_histogram(canvas, arr: np.ndarray, height: int):
    """
    RGB line histogram, log-scale, 0–65535 x-axis.
    Annotated regions: shadows (left), midtones (centre), highlights (right).
    """
    canvas.delete("all")
    w  = max(canvas.winfo_width(), 300)
    h  = height
    L  = 42; BOT = 48; TOP = 8; R = 6
    pw = w - L - R
    ph = h - TOP - BOT

    BINS = 256
    rh, _ = np.histogram(arr[...,0], bins=BINS, range=(0,1))
    gh, _ = np.histogram(arr[...,1], bins=BINS, range=(0,1))
    bh, _ = np.histogram(arr[...,2], bins=BINS, range=(0,1))

    # ── Region shading ──
    # shadow 0–10%
    xs = L + int(0.10 * pw)
    canvas.create_rectangle(L, TOP, xs, TOP+ph, fill="#e8f0f8", outline="")
    # midtone 10–90%
    xm = L + int(0.90 * pw)
    canvas.create_rectangle(xs, TOP, xm, TOP+ph, fill="#f8f9fa", outline="")
    # highlight 90–100%
    canvas.create_rectangle(xm, TOP, L+pw, TOP+ph, fill="#fff3e0", outline="")

    # ── Region labels (tiny, inside bands) ──
    for txt, xc, col in [
        ("SHADOWS",    L + int(0.05*pw), "#6090c0"),
        ("MIDTONES",   L + int(0.50*pw), "#60a060"),
        ("HIGHLIGHTS", L + int(0.95*pw), "#c08040"),
    ]:
        canvas.create_text(xc, TOP+4, text=txt, fill=col,
                           font=F_TINY, anchor="n")

    # ── Clipping warning lines ──
    canvas.create_line(L+1,     TOP, L+1,     TOP+ph, fill="#6090c0", dash=(3,3), width=1)
    canvas.create_line(L+pw-1,  TOP, L+pw-1,  TOP+ph, fill="#c08040", dash=(3,3), width=1)

    # ── Grid — every 5000 units ──
    for tv in range(0, 65536, 5000):
        x = L + int(tv/65535*pw)
        canvas.create_line(x, TOP, x, TOP+ph, fill="#d8dde4", dash=(2,2))

    # ── Plot background border ──
    canvas.create_rectangle(L, TOP, L+pw, TOP+ph, fill="", outline=BORDER)

    # ── Channel lines ──
    all_max = max(np.log1p(rh).max(), np.log1p(gh).max(), np.log1p(bh).max())
    if all_max < 1: all_max = 1

    for hist, color, width in [
        (bh, "#2563eb", 1),   # blue first (back)
        (gh, "#15803d", 1),
        (rh, "#dc2626", 1),
    ]:
        lh = np.log1p(hist.astype(float))
        pts = []
        for i, v in enumerate(lh):
            x = L + int(i/(BINS-1)*pw)
            y = TOP + ph - int(v/all_max*ph)
            pts.append((x, y))
        for i in range(len(pts)-1):
            canvas.create_line(pts[i][0], pts[i][1],
                               pts[i+1][0], pts[i+1][1],
                               fill=color, width=width)

    # ── X axis — ticks every 5000 units ──
    canvas.create_line(L, TOP+ph, L+pw, TOP+ph, fill=FG_DIM)
    for tv in range(0, 65536, 5000):
        x = L + int(tv/65535*pw)
        lbl = str(tv)
        canvas.create_line(x, TOP+ph, x, TOP+ph+3, fill=FG_DIM)
        canvas.create_text(x, TOP+ph+10, text=lbl, fill=FG_DIM,
                           font=F_TINY, anchor="center")
    # ── Y axis label ──
    canvas.create_line(L, TOP, L, TOP+ph, fill=FG_DIM)
    canvas.create_text(L-3, TOP,    text="▲", fill=FG_DIM, font=F_TINY, anchor="e")
    canvas.create_text(L-3, TOP+ph, text="0", fill=FG_DIM, font=F_TINY, anchor="e")

    # ── Clip annotation ──
    canvas.create_text(L+2,   TOP+ph+30, text="◀ clipped blacks",
                       fill="#6090c0", font=F_TINY, anchor="w")
    canvas.create_text(L+pw-2, TOP+ph+30, text="clipped whites ▶",
                       fill="#c08040", font=F_TINY, anchor="e")

# ─────────────────────────────────────────────────────────────
#  Main Application
# ─────────────────────────────────────────────────────────────
class PlanetarySharpApp:
    # Debounce delay for live processing (ms)
    LIVE_DELAY = 400

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Kepler — Planetary Image Processing Suite")
        self.root.configure(bg=BG_DEEP)
        self.root.minsize(1100, 700)

        prefs = load_prefs()
        if (geom := prefs.get("window_geometry")):
            try: self.root.geometry(geom)
            except Exception: pass
        try: self.root.state(prefs.get("window_state","zoomed"))
        except Exception:
            try: self.root.attributes("-zoomed",True)
            except Exception: self.root.geometry("1400x900")

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.original_pil: Image.Image = None
        self.working_pil:  Image.Image = None
        self.original_arr: np.ndarray  = None
        self.working_arr:  np.ndarray  = None
        self._source_path: str         = None
        self.processing   = False
        self._fft_spectrum = None
        self._live_after  = None
        self._live_pending = False   # pending after() id
        self._pending_tab  = 0       # which tab triggered last live update

        # Per-tab slider registries for per-tab reset
        self._tab_sliders: dict[int, list] = {0:[], 1:[], 2:[], 3:[], 4:[], 5:[]}
        self._current_tab_index = 0

        self._apply_ttk_theme()
        self._build_ui()

    def _on_close(self):
        try:
            prefs = {
                "window_state":    self.root.state(),
                "window_geometry": self.root.geometry(),
            }
            # Save horizontal main sash (left panel width)
            try:
                prefs["main_sash"] = self._main_pane.sash_coord(0)[0]
            except Exception: pass
            # Save vertical sash positions (preview/magnifier/histogram heights)
            try:
                prefs["vert_sash0"] = self._vert_pane.sash_coord(0)[1]
                prefs["vert_sash1"] = self._vert_pane.sash_coord(1)[1]
            except Exception: pass
            save_prefs(prefs)
        except Exception: pass
        self.root.destroy()

    def _restore_sash_positions(self):
        """Restore saved sash positions from prefs."""
        prefs = load_prefs()
        try:
            if "main_sash" in prefs:
                self._main_pane.sash_place(0, prefs["main_sash"], 0)
        except Exception: pass
        try:
            if "vert_sash0" in prefs:
                self._vert_pane.sash_place(0, 0, prefs["vert_sash0"])
            if "vert_sash1" in prefs:
                self._vert_pane.sash_place(1, 0, prefs["vert_sash1"])
        except Exception: pass

    def _reset_sash_positions(self):
        """Reset all interior pane sizes to defaults."""
        try:
            # Main horizontal: left gets 42% of window width (right needs ≥500px)
            total_w = self.root.winfo_width()
            left_w  = max(460, min(int(total_w * 0.42), total_w - 520))
            self._main_pane.sash_place(0, left_w, 0)
        except Exception: pass
        try:
            # Vertical: preview 50%, magnifier 35%, histogram 15%
            total_h = self._vert_pane.winfo_height()
            self._vert_pane.sash_place(0, 0, int(total_h * 0.50))
            self._vert_pane.sash_place(1, 0, int(total_h * 0.85))
        except Exception: pass

    def _apply_ttk_theme(self):
        s = ttk.Style()
        try: s.theme_use("clam")
        except Exception: pass
        s.configure("TNotebook", background=BG_PANEL, borderwidth=0)
        s.configure("TNotebook.Tab", background=BG_RAISED, foreground=FG_MID,
                    padding=[12,5], font=F_SM)
        s.map("TNotebook.Tab",
              background=[("selected", BG_CARD)],
              foreground=[("selected", ACCENT_C)])
        s.configure("TProgressbar",
                    troughcolor=SLIDER_TRG, background=ACCENT_C,
                    lightcolor=ACCENT_C, darkcolor=ACCENT_C, bordercolor=BORDER)
        s.configure("Vertical.TScrollbar",
                    background=BG_RAISED, troughcolor=BG_PANEL, arrowcolor=FG_MID)
        s.configure("TCombobox",
                    fieldbackground="#ffffff", background=BG_RAISED,
                    foreground=FG_BRIGHT, selectbackground=SEL_BG, font=F_SM)

    # ── Build UI ────────────────────────────────────────────
    def _build_ui(self):
        self._build_header()
        self._main_pane = tk.PanedWindow(self.root, orient="horizontal",
                              bg=BG_DEEP, sashwidth=5, sashrelief="flat")
        self._main_pane.pack(fill="both", expand=True, padx=6, pady=(0,6))
        left = tk.Frame(self._main_pane, bg=BG_PANEL, width=460)
        self._main_pane.add(left, minsize=400)
        self._build_image_panel(left)
        right = tk.Frame(self._main_pane, bg=BG_PANEL)
        self._main_pane.add(right, minsize=500)
        self._build_controls(right)
        # Restore saved sash positions after layout is complete
        self.root.after(100, self._restore_sash_positions)

    def _build_header(self):
        hdr = tk.Frame(self.root, bg=BG_PANEL, height=46)
        hdr.pack(fill="x", padx=6, pady=(6,4))
        hdr.pack_propagate(False)
        # Load icon from file; fall back to drawn planet if unavailable
        _icon_shown = False
        try:
            import os
            from PIL import Image, ImageTk
            _ico_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.ico")
            if os.path.isfile(_ico_path):
                _pil = Image.open(_ico_path)
                _sizes = _pil.info.get("sizes", {_pil.size})
                _best  = max(_sizes, key=lambda s: s[0])
                _pil   = _pil.resize((32, 32), Image.LANCZOS).convert("RGBA")
                self._header_icon = ImageTk.PhotoImage(_pil)
                tk.Label(hdr, image=self._header_icon, bg=BG_PANEL).pack(side="left", padx=(10,6), pady=5)
                _icon_shown = True
        except Exception:
            pass
        if not _icon_shown:
            ic = tk.Canvas(hdr, width=36, height=36, bg=BG_PANEL, highlightthickness=0)
            ic.pack(side="left", padx=(10,6), pady=5)
            ic.create_oval(3,3,33,33, fill="#e8760a", outline="#b45309", width=2)
            ic.create_oval(6,6,30,30, fill="#c05a05", outline="")
            ic.create_oval(0,14,36,22, outline="#92400e", width=2, fill="")
        tk.Label(hdr, text="Kepler", bg=BG_PANEL, fg=ACCENT_C, font=F_HDR).pack(side="left")
        tk.Label(hdr, text="  —  Planetary Image Processing Suite  ·  v1.1.5",
                 bg=BG_PANEL, fg=FG_DIM, font=F_MD).pack(side="left")
        self.status_var = tk.StringVar(value="READY")
        tk.Label(hdr, textvariable=self.status_var, bg=BG_PANEL,
                 fg=ACCENT_G, font=F_BOLD).pack(side="right", padx=12)
        tk.Label(hdr, text="STATUS:", bg=BG_PANEL,
                 fg=FG_DIM, font=F_SM).pack(side="right")
        self.img_size_var = tk.StringVar(value="—")
        tk.Label(hdr, textvariable=self.img_size_var, bg=BG_PANEL,
                 fg=ACCENT_C, font=F_SM).pack(side="right", padx=(0,12))
        tk.Label(hdr, text="SIZE:", bg=BG_PANEL,
                 fg=FG_DIM, font=F_SM).pack(side="right")
        tk.Button(hdr, text="⊡ Reset Layout",
                  command=self._reset_sash_positions,
                  bg=BG_RAISED, fg=FG_MID, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=2,
                  activebackground=SEL_BG).pack(side="right", padx=(0, 16))

    # ── Left panel ──────────────────────────────────────────
    def _build_image_panel(self, parent):
        # Top strip: IMAGE I/O buttons (fixed height, not in paned window)
        top = tk.Frame(parent, bg=BG_PANEL)
        top.pack(fill="x", padx=6, pady=(6,2))
        section_header(top, "IMAGE I/O").pack(fill="x", pady=(0,2))
        bf = tk.Frame(top, bg=BG_PANEL); bf.pack(fill="x", pady=3)
        def _btn(p, text, cmd, fg):
            return tk.Button(p, text=text, command=cmd, bg=BG_RAISED,
                             fg=fg, font=F_MD, relief="flat", cursor="hand2",
                             padx=10, pady=5, activebackground=SEL_BG,
                             activeforeground=fg)
        _btn(bf,"📂 Open",   self.open_image,    ACCENT_C).pack(side="left",fill="x",expand=True,padx=(0,3))
        _btn(bf,"💾 Export", self.export_image,  ACCENT_G).pack(side="left",fill="x",expand=True,padx=(0,3))

        # Progress bar (fixed, always visible at bottom of top strip)
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(top, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill="x", pady=(4,2))

        # ── Vertical PanedWindow: Preview | Magnifier | Histogram ───────────
        self._vert_pane = tk.PanedWindow(parent, orient="vertical",
                               bg=BG_DEEP, sashwidth=6, sashrelief="flat",
                               sashpad=2)
        self._vert_pane.pack(fill="both", expand=True, padx=6, pady=(2,6))
        vpane = self._vert_pane

        # ── Pane 1: Preview ──────────────────────────────────────────────────
        prev_frm = tk.Frame(vpane, bg=BG_PANEL)
        vpane.add(prev_frm, minsize=180)

        section_header(prev_frm,"PREVIEW").pack(fill="x", pady=(4,2))
        zf = tk.Frame(prev_frm, bg=BG_PANEL); zf.pack(fill="x", pady=(0,3))
        tk.Label(zf, text="Zoom:", bg=BG_PANEL, fg=FG_MID, font=F_SM).pack(side="left")
        self._prev_zoom = 1.0
        self._pan = {}
        def _zbtn(txt, cmd):
            return tk.Button(zf, text=txt, command=cmd, bg=BG_RAISED,
                             fg=FG_MID, font=F_BOLD, relief="flat",
                             cursor="hand2", width=3, padx=2, pady=1,
                             activebackground=SEL_BG)
        _zbtn("−", self._preview_zoom_out).pack(side="left", padx=(4,1))
        self._zoom_pct_var = tk.StringVar(value="Fit")
        tk.Label(zf, textvariable=self._zoom_pct_var, bg=BG_RAISED,
                 fg=ACCENT_C, font=F_BOLD, width=5, anchor="center",
                 relief="flat").pack(side="left")
        _zbtn("+", self._preview_zoom_in).pack(side="left", padx=(1,4))
        for pct, lbl in [(50,"50%"),(100,"100%"),(200,"200%"),(400,"400%")]:
            tk.Button(zf, text=lbl, command=lambda v=pct: self._set_preview_zoom(v/100),
                      bg=BG_RAISED, fg=FG_MID, font=F_TINY, relief="flat",
                      cursor="hand2", padx=4, pady=1,
                      activebackground=SEL_BG).pack(side="left", padx=1)
        tk.Button(zf, text="Fit", command=self._preview_fit,
                  bg=BG_RAISED, fg=ACCENT_G, font=F_SM, relief="flat",
                  cursor="hand2", padx=6, pady=1,
                  activebackground=SEL_BG).pack(side="left", padx=(4,0))

        # ── Preview Rotation row ─────────────────────────────────────────
        rf = tk.Frame(prev_frm, bg=BG_PANEL); rf.pack(fill="x", pady=(0,2))
        tk.Label(rf, text="Rotate:", bg=BG_PANEL, fg=FG_MID, font=F_SM).pack(side="left", padx=(0,4))
        self._preview_rot_deg = tk.DoubleVar(value=0.0)
        self._preview_rot_spinbox = tk.Spinbox(
            rf, from_=-360.0, to=360.0, increment=1.0,
            textvariable=self._preview_rot_deg,
            width=6, font=F_MD, format="%.1f", relief="flat",
            bg=BG_RAISED, fg=ACCENT_C, buttonbackground=BG_RAISED,
            activebackground=SEL_BG,
            command=self._on_preview_rotate)
        self._preview_rot_spinbox.pack(side="left", padx=(0,4))
        self._preview_rot_spinbox.bind("<Return>",   lambda e: self._on_preview_rotate())
        self._preview_rot_spinbox.bind("<FocusOut>", lambda e: self._on_preview_rotate())
        tk.Label(rf, text="°", bg=BG_PANEL, fg=FG_MID, font=F_SM).pack(side="left", padx=(0,6))
        for deg, lbl in [(-90,"−90°"), (90,"90°"), (180,"180°")]:
            tk.Button(rf, text=lbl,
                      command=lambda d=deg: self._preview_set_rotation(d),
                      bg=BG_RAISED, fg=FG_MID, font=F_TINY, relief="flat",
                      cursor="hand2", padx=5, pady=1,
                      activebackground=SEL_BG).pack(side="left", padx=1)
        tk.Button(rf, text="⊘ Reset",
                  command=lambda: self._preview_set_rotation(0),
                  bg=BG_RAISED, fg=FG_DIM, font=F_TINY, relief="flat",
                  cursor="hand2", padx=5, pady=1,
                  activebackground=SEL_BG).pack(side="left", padx=(4,0))

        pf = tk.Frame(prev_frm, bg=BG_PANEL); pf.pack(fill="both", expand=True, pady=3)
        def _preview_canvas(parent, title):
            border = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
            border.pack(side="left", expand=True, fill="both",
                        padx=(0,2) if title=="ORIGINAL" else (2,0))
            inner = tk.Frame(border, bg=BG_CARD); inner.pack(fill="both", expand=True)
            tk.Label(inner, text=title, bg=BG_CARD,
                     fg=FG_DIM, font=F_SM).pack(pady=(3,0))
            c = tk.Canvas(inner, width=PREV_W, height=PREV_H,
                          bg="#606060", highlightthickness=0, cursor="crosshair")
            c.pack(fill="both", expand=True, padx=3, pady=3)
            return c

        self.cnv_orig = _preview_canvas(pf, "ORIGINAL")
        self.cnv_proc = _preview_canvas(pf, "PROCESSED")
        for c in (self.cnv_orig, self.cnv_proc):
            c.bind("<MouseWheel>", lambda e,cc=c: self._preview_wheel(e,cc))
            c.bind("<Button-4>",   lambda e,cc=c: self._preview_wheel(e,cc))
            c.bind("<Button-5>",   lambda e,cc=c: self._preview_wheel(e,cc))
            self._pan[id(c)] = [0, 0, 0, 0]
            c.bind("<ButtonPress-2>", lambda e,cc=c: self._pan_start(e,cc))
            c.bind("<B2-Motion>",     lambda e,cc=c: self._pan_move(e,cc))
            c.bind("<ButtonPress-3>", lambda e,cc=c: self._pan_start(e,cc))
            c.bind("<B3-Motion>",     lambda e,cc=c: self._pan_move(e,cc))
        self.cnv_orig.bind("<Double-Button-1>",
            lambda e: ZoomWindow(self.root,"Zoom — Original",lambda: self.original_pil))
        self.cnv_proc.bind("<Double-Button-1>",
            lambda e: ZoomWindow(self.root,"Zoom — Processed",
                lambda: self._get_processed_pil() or self.original_pil))
        self._set_placeholder_previews()

        # ── Pane 2: Magnifier ────────────────────────────────────────────────
        mag_frm = tk.Frame(vpane, bg=BG_PANEL)
        vpane.add(mag_frm, minsize=120)
        section_header(mag_frm,"MAGNIFIER  (click preview to lock spot)").pack(fill="x", pady=(4,2))
        self.magnifier = StaticMagnifier(mag_frm)
        self.cnv_orig.bind("<Button-1>",
            lambda e: self._magnify_at(e,self.cnv_orig,lambda: self.original_pil,"ORIG"))
        self.cnv_proc.bind("<Button-1>",
            lambda e: self._magnify_at(e,self.cnv_proc,
                lambda: self._get_processed_pil()
                        if self.working_arr is not None else self.original_pil,"PROC"))

        # ── Pane 3: Histogram ────────────────────────────────────────────────
        hist_frm = tk.Frame(vpane, bg=BG_PANEL)
        vpane.add(hist_frm, minsize=80)
        section_header(hist_frm,"HISTOGRAM").pack(fill="x", pady=(4,2))
        self.hist_canvas = tk.Canvas(hist_frm, height=135, bg=BG_CARD,
                                     highlightthickness=1, highlightbackground=BORDER)
        self.hist_canvas.pack(fill="both", expand=True, padx=6, pady=3)

    # ── Preview zoom helpers ─────────────────────────────────
    def _preview_zoom_in(self):  self._set_preview_zoom(self._prev_zoom*1.25)
    def _preview_zoom_out(self): self._set_preview_zoom(self._prev_zoom/1.25)
    def _set_preview_zoom(self, z):
        self._prev_zoom = max(0.1, min(16.0, z))
        self._zoom_pct_var.set(f"{self._prev_zoom*100:.0f}%")
        self._redraw_previews()
    def _preview_fit(self):
        self._prev_zoom = 1.0; self._zoom_pct_var.set("Fit")
        for k in self._pan: self._pan[k][:2] = [0, 0]
        self._redraw_previews()
    def _pan_start(self, event, cnv):
        p = self._pan[id(cnv)]; p[2] = event.x; p[3] = event.y
        cnv.configure(cursor="fleur")
    def _pan_move(self, event, cnv):
        p = self._pan[id(cnv)]
        p[0] += event.x - p[2]; p[1] += event.y - p[3]
        p[2] = event.x; p[3] = event.y
        self._redraw_previews()
    def _preview_wheel(self, event, canvas):
        f = 1.15 if not (event.num==5 or getattr(event,"delta",0)<0) else 1/1.15
        self._set_preview_zoom(self._prev_zoom * f)
    def _get_processed_pil(self):
        """Return the processed image as PIL, with current preview rotation applied."""
        if self.working_arr is None:
            return None
        pil = proc.array_to_pil(self.working_arr)
        try:
            deg = float(self._preview_rot_deg.get())
        except (ValueError, AttributeError, tk.TclError):
            deg = 0.0
        if deg != 0.0:
            pil = pil.rotate(-deg, expand=False,
                             resample=Image.BICUBIC, fillcolor=(0, 0, 0))
        return pil

    def _redraw_previews(self):
        if self.original_arr is not None:
            self._draw_on_canvas(self.cnv_orig, proc.array_to_pil(self.original_arr))
        pil = self._get_processed_pil()
        if pil is not None:
            self._draw_on_canvas(self.cnv_proc, pil)
    def _draw_on_canvas(self, cnv, pil):
        # winfo_width/height return 1 before first layout — force a geometry pass
        cw = cnv.winfo_width()
        ch = cnv.winfo_height()
        if cw <= 1 or ch <= 1:
            cnv.update_idletasks()
            cw = cnv.winfo_width()
            ch = cnv.winfo_height()
        if cw <= 1: cw = PREV_W
        if ch <= 1: ch = PREV_H
        scale = (min(cw/pil.width, ch/pil.height)
                 if self._zoom_pct_var.get()=="Fit" else self._prev_zoom)
        nw = max(1, int(pil.width*scale)); nh = max(1, int(pil.height*scale))
        resample = Image.NEAREST if scale >= 1.0 else Image.LANCZOS
        res = pil.resize((nw,nh), resample)
        p = self._pan.get(id(cnv), [0,0,0,0])
        x=(cw-nw)//2 + p[0]; y=(ch-nh)//2 + p[1]
        t = ImageTk.PhotoImage(res)
        cnv.delete("all"); cnv.create_image(x,y,anchor="nw",image=t); cnv._img=t
    def _magnify_at(self, event, cnv, get_pil_fn, source_name):
        pil = get_pil_fn()
        if pil is None: return
        cw = cnv.winfo_width() or PREV_W; ch = cnv.winfo_height() or PREV_H
        scale = (min(cw/pil.width, ch/pil.height)
                 if self._zoom_pct_var.get()=="Fit" else self._prev_zoom)
        nw = max(1,int(pil.width*scale)); nh = max(1,int(pil.height*scale))
        ox=(cw-nw)//2; oy=(ch-nh)//2
        px = max(0, min(pil.width-1,  int((event.x-ox)/scale)))
        py = max(0, min(pil.height-1, int((event.y-oy)/scale)))
        self.magnifier.click_magnify(pil, px, py, source_name)
    def _set_placeholder_previews(self):
        for cnv, txt in [(self.cnv_orig,"NO IMAGE"),(self.cnv_proc,"AWAITING…")]:
            ph = Image.new("RGB",(PREV_W,PREV_H),color="#505864")
            ImageDraw.Draw(ph).text((PREV_W//2-30,PREV_H//2-6),txt,fill="#aab4be")
            t = ImageTk.PhotoImage(ph)
            cnv.delete("all"); cnv.create_image(0,0,anchor="nw",image=t); cnv._img=t

    # ── Right panel ─────────────────────────────────────────
    def _build_controls(self, parent):
        bb = tk.Frame(parent, bg=BG_PANEL)
        bb.pack(fill="x", padx=6, pady=(6,0))
        tk.Button(bb, text="↺ Reset Tab Sliders", command=self.reset_tab_sliders,
                  bg=BG_RAISED, fg=ACCENT_O, font=F_BOLD, relief="flat",
                  cursor="hand2", padx=12, pady=5,
                  activebackground=SEL_BG).pack(side="left", padx=(0,4))
        tk.Button(bb, text="⟳ Reset All", command=self.reset_all,
                  bg=BG_RAISED, fg=ACCENT_R, font=F_BOLD, relief="flat",
                  cursor="hand2", padx=12, pady=5,
                  activebackground=SEL_BG).pack(side="left", padx=(0,8))
        tk.Label(bb, text="Right-click or double-click any slider to reset it",
                 bg=BG_PANEL, fg=FG_DIM, font=F_TINY).pack(side="left")

        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill="both", expand=True, padx=6, pady=4)
        self.notebook.bind("<<NotebookTabChanged>>",
                           lambda e: self._on_tab_change())

        self._build_wavelet_tab()
        self._build_fft_tab()
        self._build_color_tab()
        self._build_tools_tab()
        self._build_dering_tab()
        self._build_stats_tab()
        self._build_batch_tab()

    def _on_tab_change(self):
        try:
            self._current_tab_index = self.notebook.index(self.notebook.select())
        except Exception: pass

    def _scrollable_tab(self, title):
        outer = tk.Frame(self.notebook, bg=BG_PANEL)
        self.notebook.add(outer, text=title)
        cnv   = tk.Canvas(outer, bg=BG_PANEL, highlightthickness=0)
        vsb   = ttk.Scrollbar(outer, orient="vertical", command=cnv.yview)
        cnv.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y"); cnv.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(cnv, bg=BG_PANEL)
        cw    = cnv.create_window((0,0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: cnv.configure(scrollregion=cnv.bbox("all")))
        cnv.bind("<Configure>", lambda e: cnv.itemconfig(cw, width=e.width))
        # Scroll the tab canvas ONLY when the mouse wheel event originates from
        # the canvas background or the inner frame — never from child widgets
        # such as sliders or buttons (which have their own wheel behaviour).
        # Strategy: bind scroll directly to cnv and inner; child widgets that
        # receive wheel events do NOT propagate up so the panel stays still.
        def _mw(e):  cnv.yview_scroll(int(-1*(e.delta/120)),"units"); return "break"
        def _mw4(e): cnv.yview_scroll(-1,"units"); return "break"
        def _mw5(e): cnv.yview_scroll( 1,"units"); return "break"
        for w in (cnv, inner):
            w.bind("<MouseWheel>", _mw)
            w.bind("<Button-4>",   _mw4)
            w.bind("<Button-5>",   _mw5)
        return inner

    # Helper: register a slider with a tab index
    def _reg(self, tab_idx: int, slider: LabeledSlider) -> LabeledSlider:
        """Register slider in per-tab list and wire it to live processing."""
        self._tab_sliders[tab_idx].append(slider)
        slider.callback = lambda v: self._schedule_live(tab_idx)
        return slider

    def _schedule_live(self, tab_idx: int):
        self._pending_tab = tab_idx
        if self._live_after is not None:
            self.root.after_cancel(self._live_after)
        self._live_after = self.root.after(self.LIVE_DELAY, self._fire_live)

    def _fire_live(self):
        self._live_after = None
        if self.original_arr is None: return
        if self.processing:
            self._live_pending = True
            return
        self._live_pending = False

        # Capture ALL slider values on the main thread before the worker runs.
        # The full pipeline always runs in order: Wavelet → FFT → Color → Dering
        # so each tab operates on the previous tab's output.

        # ── Tab 0: Wavelet ──
        wv_params = self._get_wavelet_params()
        wv_fm     = self.wv_filter.get().split()[0]   # "gaussian", "zgaussian", etc.
        wv_cm     = self.wv_color_model.get().split()[0]  # "oklab", "hsl", "hsv"
        wv_conv   = self.wv_convolve.get().split()[0]      # "L", "RGB", "LRGB"
        wv_sf     = [float(self.wsf1.get()), float(self.wsf2.get()), float(self.wsf3.get())]
        wv_ps     = float(self.wv_pre_smooth.get())        # Pre-Smooth sigma
        # Power function: 1.0 = off (linear)
        wv_pf     = float(self.wv_powerfn_exp.get()) if self.wv_powerfn_enabled.get() else 1.0
        wv_zgf    = float(self.wv_zgauss_factor.get()) if hasattr(self, "wv_zgauss_factor") else 1.0
        wv_br     = float(self.wv_bilateral_radius.get()) if hasattr(self, "wv_bilateral_radius") else 2.0
        wv_bls    = [self.wbl1.get(), self.wbl2.get(), self.wbl3.get()] \
                    if wv_fm == "bilateral" and hasattr(self, "wbl1") else None
        src0      = self.original_arr.copy()
        wv_lvls   = wv_params

        # ── Tab 1: FFT ──
        fft_s     = float(self.fft_marker_start)   # 0-100 % frequency
        fft_e     = float(self.fft_marker_end)     # 0-100 % frequency
        fft_c     = float(self.fft_curve_slider.get())
        fft_layer = self.fft_layer.get()            # "POST" | "PRE1" | "PRE2" | "PRE3"
        fft_on    = self.fft_enabled.get()
        # Build pre_fft: list of (start, width, curve) or None per layer
        # Only populated when FFT is enabled and a PRE layer is selected
        _fft_params = (fft_s, max(0.1, fft_e - fft_s), fft_c) if fft_on and fft_s < 100.0 else None
        fft_pre = [
            _fft_params if (fft_on and fft_layer == "PRE1") else None,
            _fft_params if (fft_on and fft_layer == "PRE2") else None,
            _fft_params if (fft_on and fft_layer == "PRE3") else None,
        ]

        # ── Tab 2: Color ──
        r_g  = float(self.rgb_r.get())/100;   g_g  = float(self.rgb_g.get())/100
        b_g  = float(self.rgb_b.get())/100;   r_gm = float(self.gamma_r.get())/100
        g_gm = float(self.gamma_g.get())/100; b_gm = float(self.gamma_b.get())/100
        r_bp = float(self.black_r.get())/100  # black point 0-1
        g_bp = float(self.black_g.get())/100
        b_bp = float(self.black_b.get())/100
        sat  = float(self.saturation.get())/100
        vib  = float(self.vibrance.get())/100
        hue  = float(self.hue_rot.get())
        bri  = float(self.brightness.get())/255
        con  = float(self.contrast.get())/100

        # ── Tab 3: Tools ──
        _lc = self._get_lc_params()
        tl_br,tl_wr,tl_gr, tl_bg,tl_wg,tl_gg, tl_bb,tl_wb,tl_gb,         tl_lr,tl_lg,tl_lb, tl_def = _lc
        tl_clahe_on   = bool(self._clahe_enabled.get())
        tl_clahe_clip = float(self._clahe_clip.get())
        tl_clahe_tile = max(4, int(float(self._clahe_tile.get())))
        tl_clahe_str  = float(self._clahe_strength.get())
        tl_clahe_ch   = self._clahe_channel.get()

        # ── Tab 4: De-rind ──
        dr_enabled = bool(self.dr_enabled.get())
        dr_p = dict(
            edge          = float(self.dr_edge.get()),
            feather       = float(self.dr_feather.get()),
            smooth        = float(self.dr_smooth.get()),
            inset         = float(self.dr_inset.get()),
            gap_width     = float(self.dr_gap_width.get()),
            gap_angle     = float(self.dr_gap_angle.get()),
            saturn_mode   = bool(self.dr_saturn.get()),
            dark_edge     = bool(self.dr_dark_edge.get()),
            pre_blur      = float(self.dr_pre_blur.get()),
            show_ring_map = bool(self.dr_show_map.get()),
        )

        def _full_pipeline(
            src=src0,
            lvls=wv_lvls, fm=wv_fm, cm=wv_cm, conv=wv_conv, sf=wv_sf, ps=wv_ps, pf=wv_pf,
            zgf=wv_zgf, br=wv_br, bls=wv_bls,
            fs=fft_s, fe=fft_e, fc=fft_c, flayer=fft_layer, fon=fft_on,
            fpre=fft_pre,
            rg=r_g, gg=g_g, bg_=b_g,
            rgm=r_gm, ggm=g_gm, bgm=b_gm,
            rbp=r_bp, gbp=g_bp, bbp=b_bp,
            sat_=sat, vib_=vib, hue_=hue, bri_=bri, con_=con,
            dp=dr_p, dr_on=dr_enabled,
            tl_def=tl_def,
            tl_br=tl_br, tl_wr=tl_wr, tl_gr=tl_gr,
            tl_bg=tl_bg, tl_wg=tl_wg, tl_gg=tl_gg,
            tl_bb=tl_bb, tl_wb=tl_wb, tl_gb=tl_gb,
            tl_lr=tl_lr, tl_lg=tl_lg, tl_lb=tl_lb,
            tl_clahe_on=tl_clahe_on, tl_clahe_clip=tl_clahe_clip,
            tl_clahe_tile=tl_clahe_tile, tl_clahe_str=tl_clahe_str,
            tl_clahe_ch=tl_clahe_ch,
        ):
            img = proc.wavelet_sharpen(src, lvls, fm, color_model=cm, convolve=conv,
                                       pre_fft=fpre, sharp_filter=sf, pre_smooth=ps,
                                       power_fn=pf, zgauss_factor=zgf,
                                       bilateral_radius=br, bilateral_layers=bls)
            # POST FFT: applied after all wavelet layers
            if fon and flayer == "POST" and fs < 100.0:
                img = proc.fft_denoise(img, fft_start=fs, fft_width=max(0.1, fe-fs), fft_curve=fc)
            img = proc.apply_color_adjustments(
                img, r_gain=rg, g_gain=gg, b_gain=bg_,
                r_black=rbp, g_black=gbp, b_black=bbp,
                r_gamma=rgm, g_gamma=ggm, b_gamma=bgm,
                saturation=sat_, vibrance=vib_, hue_rotation=hue_,
                brightness=bri_, contrast=con_)
            if not tl_def:
                img = proc.apply_levels_curves(
                    img,
                    black_r=tl_br, white_r=tl_wr, gamma_r=tl_gr,
                    black_g=tl_bg, white_g=tl_wg, gamma_g=tl_gg,
                    black_b=tl_bb, white_b=tl_wb, gamma_b=tl_gb,
                    curve_lut_r=tl_lr, curve_lut_g=tl_lg, curve_lut_b=tl_lb)
            if tl_clahe_on:
                img = proc.apply_clahe(img,
                    clip_limit=tl_clahe_clip, tile_grid=tl_clahe_tile,
                    channel_mode=tl_clahe_ch, strength=tl_clahe_str)
            if dr_on:
                img = proc.apply_derind(img, **dp)
            return img

        self._run_in_thread(_full_pipeline, "PROCESSING")

    # ── Wavelet Tab ─────────────────────────────────────────
    def _build_wavelet_tab(self):
        TAB = 0
        f = self._scrollable_tab("⟴  Wavelet")

        guide = tk.Frame(f, bg="#e8f0fb", padx=10, pady=8)
        guide.pack(fill="x", padx=6, pady=(8,4))
        tk.Label(guide, text="▶  Workflow", bg="#e8f0fb", fg=ACCENT_C, font=F_BOLD).pack(anchor="w")
        tk.Label(guide,
                 text="1. Move the Sharpen sliders (0–200) per layer to taste\n"
                      "2. Click Estimate Filter — confirms safe decomposition scales\n"
                      "3. Filter type changes sharpening character (Z-Gaussian = crispest)",
                 bg="#e8f0fb", fg=FG_MID, font=F_SM,
                 justify="left", wraplength=480).pack(anchor="w", pady=(2,0))

        # ── Sharpen levels ──
        section_header(f, "SHARPENING LAYERS", ACCENT_C).pack(fill="x", padx=6)

        def _level_card(parent, title, subtitle, accent, sh_def, dn_def, sigma_def):
            card = card_frame(parent, title, accent, subtitle=subtitle)
            sh = self._reg(TAB, LabeledSlider(card, "Sharpen  (0–200)", 0, 200, sh_def, accent, "{:.0f}"))
            sh.pack(fill="x", pady=1)
            # Denoise hidden — kept wired but not shown
            dn = self._reg(TAB, LabeledSlider(card, "Denoise  (noise gate)", 0, 100, dn_def, FG_MID, "{:.0f}"))
            # Decomp σ hidden — kept wired but not shown
            sg = self._reg(TAB, LabeledSlider(card, "Decomp σ  (filter radius, px)", 0.5, 30.0, sigma_def, accent, "{:.2f}"))
            # Per-layer SharpenFilter — updated by Autosize when enabled
            sf = self._reg(TAB, LabeledSlider(card, "SharpenFilter  (0=off)", 0.0, 2.0, 0.0, accent, "{:.3f}"))
            sf.pack(fill="x", pady=1)
            # Bilateral checkbox — shown only when bilateral filter is selected
            bl_var = tk.BooleanVar(value=True)
            bl_chk = tk.Checkbutton(card,
                text="Use bilateral on this layer  (uncheck = Gaussian for this layer)",
                variable=bl_var, bg=BG_CARD, fg=FG_MID, font=F_SM,
                activebackground=BG_CARD, selectcolor=BG_RAISED,
                command=lambda: self._schedule_live(0))
            return sh, dn, sg, sf, bl_var, bl_chk

        self.ws1, self.wt1, self.wsz1, self.wsf1, self.wbl1, self._bl_chk1 = _level_card(
            f, "LAYER 1  ·  Fine Detail  (craters, fine grain)", "~0.5 px", ACCENT_C, 0, 0, 0.5)
        self.ws2, self.wt2, self.wsz2, self.wsf2, self.wbl2, self._bl_chk2 = _level_card(
            f, "LAYER 2  ·  Mid Detail  (filaments, dust lanes)", "~1 px", ACCENT_G, 0, 0, 1.0)
        self.ws3, self.wt3, self.wsz3, self.wsf3, self.wbl3, self._bl_chk3 = _level_card(
            f, "LAYER 3  ·  Large Structure  (belts, arms)", "~2 px", ACCENT_P, 0, 0, 2.0)

        # ── Convolve Channel Selector ──
        section_header(f, "CONVOLVE CHANNEL", ACCENT_C).pack(fill="x", padx=6, pady=(10,0))
        cc = card_frame(f, subtitle="Which channels to sharpen")
        tk.Label(cc, text="Convolve:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(anchor="w")
        self.wv_convolve = ttk.Combobox(cc,
            values=["L  (luminance only, safest)", "RGB  (all channels)", "LRGB  (L first, then RGB)"],
            state="readonly", font=F_SM)
        self.wv_convolve.set("LRGB  (L first, then RGB)")
        self.wv_convolve.pack(fill="x", pady=2)
        self.wv_convolve.bind("<<ComboboxSelected>>", lambda e: self._schedule_live(0))

        # ── Filter Type + Estimate ──
        section_header(f, "SHARPEN FILTER", ACCENT_C).pack(fill="x", padx=6, pady=(10,0))
        ff = card_frame(f, subtitle="Filter type affects character — Z-Gaussian = crispest/most aggressive")

        # Pre-Smooth — suppress sub-pixel drizzle/noise before decomposition
        self.wv_pre_smooth = self._reg(0, LabeledSlider(
            ff, "Pre-Smooth σ  (0=off, use if moire visible)", 0.0, 5.0, 0.0, ACCENT_C, "{:.2f}"))
        self.wv_pre_smooth.pack(fill="x", pady=(2,2))
        tk.Label(ff, text="Eliminates moire/drizzle artefacts before sharpening. Match to Layer-1 σ.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack(anchor="w", padx=4, pady=(0,6))

        # SharpenFilter is now per-layer (inside each layer card above).
        # Autosize updates all three when enabled.

        # Color model (Oklab default)
        tk.Label(ff, text="Color model:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(anchor="w")
        self.wv_color_model = ttk.Combobox(ff,
            values=["oklab (default)", "hsl", "hsv"],
            state="readonly", font=F_SM)
        self.wv_color_model.set("oklab (default)")
        self.wv_color_model.pack(fill="x", pady=(2,6))
        self.wv_color_model.bind("<<ComboboxSelected>>", lambda e: self._schedule_live(0))

        tk.Label(ff, text="Filter type:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(anchor="w")
        self.wv_filter = ttk.Combobox(ff,
            values=["gaussian", "zgaussian (Z-Gaussian)", "bilateral", "b3 (B3-spline)"],
            state="readonly", font=F_SM)
        self.wv_filter.set("gaussian")
        self.wv_filter.pack(fill="x", pady=2)
        self.wv_filter.bind("<<ComboboxSelected>>", lambda e: self._on_filter_change())

        # ── Bilateral extra controls (hidden until bilateral selected) ──
        self._bilateral_frame = tk.Frame(ff, bg=BG_CARD)
        br_row = tk.Frame(self._bilateral_frame, bg=BG_CARD)
        br_row.pack(fill="x", pady=(4, 0))
        tk.Label(br_row, text="Radius  (0–10):", bg=BG_CARD, fg=FG_MID,
                 font=F_SM, width=20, anchor="w").pack(side="left", padx=(0, 4))
        self.wv_bilateral_radius = tk.DoubleVar(value=2.0)
        br_spin = tk.Spinbox(br_row, from_=0.0, to=10.0, increment=0.5,
                             textvariable=self.wv_bilateral_radius,
                             width=6, font=F_MD, format="%.1f", relief="flat",
                             bg=BG_RAISED, fg=ACCENT_C, buttonbackground=BG_RAISED,
                             activebackground=SEL_BG,
                             command=lambda: self._schedule_live(0))
        br_spin.pack(side="left")
        br_spin.bind("<Return>",   lambda e: self._schedule_live(0))
        br_spin.bind("<FocusOut>", lambda e: self._schedule_live(0))
        tk.Label(self._bilateral_frame,
                 text="Controls spatial smoothing width. Higher = smoother flat areas.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack(anchor="w", padx=4, pady=(2, 4))
        tk.Label(self._bilateral_frame, text="Per-layer bilateral:",
                 bg=BG_CARD, fg=FG_MID, font=F_SM).pack(anchor="w", padx=2)

        # ── Z-Gaussian extra controls (hidden until zgaussian selected) ──
        self._zgauss_frame = tk.Frame(ff, bg=BG_CARD)
        zf_row = tk.Frame(self._zgauss_frame, bg=BG_CARD)
        zf_row.pack(fill="x", pady=(4, 0))
        tk.Label(zf_row, text="Factor  (0–1):", bg=BG_CARD, fg=FG_MID,
                 font=F_SM, width=20, anchor="w").pack(side="left", padx=(0, 4))
        self.wv_zgauss_factor = tk.DoubleVar(value=1.0)
        zf_spin = tk.Spinbox(zf_row, from_=0.0, to=1.0, increment=0.05,
                             textvariable=self.wv_zgauss_factor,
                             width=6, font=F_MD, format="%.2f", relief="flat",
                             bg=BG_RAISED, fg=ACCENT_C, buttonbackground=BG_RAISED,
                             activebackground=SEL_BG,
                             command=lambda: self._schedule_live(0))
        zf_spin.pack(side="left")
        zf_spin.bind("<Return>",   lambda e: self._schedule_live(0))
        zf_spin.bind("<FocusOut>", lambda e: self._schedule_live(0))
        tk.Label(self._zgauss_frame,
                 text="0 = full Z-Gaussian (strongest, use ~30% of Gaussian slider values)  ·  1 = identical to Gaussian.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack(anchor="w", padx=4, pady=(2, 4))

        # Autosize checkbox
        self.wv_autosize = tk.BooleanVar(value=False)
        tk.Checkbutton(ff, text="Autosize Filter  (auto-updates σ when sharpen changes)",
                       variable=self.wv_autosize, bg=BG_CARD, fg=FG_MID, font=F_SM,
                       activebackground=BG_CARD, selectcolor=BG_RAISED,
                       command=self._on_autosize_toggle).pack(anchor="w", pady=(4,2))

        tk.Button(ff, text="⟴  Estimate Filter",
                  command=self.run_estimate_sharpen,
                  bg=BG_RAISED, fg=ACCENT_C, font=F_MD, relief="flat",
                  cursor="hand2", padx=8, pady=4,
                  activebackground=SEL_BG).pack(fill="x", pady=(6,2))
        self.estimate_lbl = tk.Label(ff, text="", bg=BG_CARD, fg=FG_DIM, font=F_TINY,
                                     wraplength=360, justify="left")
        self.estimate_lbl.pack(anchor="w", padx=4, pady=(0,4))

        # ── Power Function ──────────────────────────────────────────────────
        sep2 = tk.Frame(ff, height=1, bg=BORDER)
        sep2.pack(fill="x", pady=(8, 4))

        pf_row = tk.Frame(ff, bg=BG_CARD)
        pf_row.pack(fill="x", pady=(2, 0))

        self.wv_powerfn_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(pf_row, text="Power Function  x^y applied to wavelet coefficients",
                       variable=self.wv_powerfn_enabled, bg=BG_CARD, fg=FG_MID,
                       font=F_SM, activebackground=BG_CARD, selectcolor=BG_RAISED,
                       command=self._on_powerfn_toggle).pack(side="left", anchor="w")

        pf_exp_row = tk.Frame(ff, bg=BG_CARD)
        pf_exp_row.pack(fill="x", pady=(2, 4))
        tk.Label(pf_exp_row, text="Exponent (y):", bg=BG_CARD, fg=FG_MID,
                 font=F_SM, width=24, anchor="w").pack(side="left", padx=(0, 4))
        self.wv_powerfn_exp = tk.DoubleVar(value=1.0)
        pf_spinbox = tk.Spinbox(
            pf_exp_row, from_=0.10, to=4.00, increment=0.05,
            textvariable=self.wv_powerfn_exp, width=7, font=F_MD,
            format="%.2f", relief="flat", bg=BG_RAISED, fg=ACCENT_P,
            buttonbackground=BG_RAISED, activebackground=SEL_BG,
            disabledforeground=FG_DIM,
            command=self._on_powerfn_change)
        pf_spinbox.pack(side="left")
        pf_spinbox.bind("<Return>",    lambda e: self._on_powerfn_change())
        pf_spinbox.bind("<FocusOut>",  lambda e: self._on_powerfn_change())
        self._pf_spinbox = pf_spinbox

        tk.Label(pf_exp_row,
                 text="  >1 = boost large coeff  |  <1 = boost small coeff  |  1.0 = linear (off)",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack(side="left", padx=(8, 0))

        # Initial spinbox state
        self._pf_spinbox.config(state="disabled")

        # ── Wire wavelet sliders → pipeline ──
        def _sharpen_cb(val):
            if self.wv_autosize.get():
                self._run_autosize()   # updates sigma sliders, which fire their own cb
            self._schedule_live(0)
        def _live_cb(val):
            self._schedule_live(0)
        for _s in [self.ws1, self.ws2, self.ws3]:
            _s.callback = _sharpen_cb
        for _s in [self.wt1, self.wt2, self.wt3, self.wsz1, self.wsz2, self.wsz3]:
            _s.callback = _live_cb

        # _wv_sigmas used by Estimate Filter label; sigma sliders are source of truth
        self._wv_sigmas = [
            float(self.wsz1.get()),
            float(self.wsz2.get()),
            float(self.wsz3.get()),
        ]

    def _run_autosize(self):
        """Recompute sigma and SharpenFilter sliders from sharpen values (Autosize Filter)."""
        img = self.original_arr  # may be None before image is loaded
        for sl_sh, sl_sg, sl_sf, layer_idx in [
            (self.ws1, self.wsz1, self.wsf1, 0),
            (self.ws2, self.wsz2, self.wsf2, 1),
            (self.ws3, self.wsz3, self.wsf3, 2),
        ]:
            sigma = proc.estimate_filter_sigma(sl_sh.get(), layer_idx, img)
            sl_sg.set(round(sigma, 2), fire_callback=False)
            sf_val = proc.estimate_sharpen_filter(sl_sh.get(), sigma, layer_idx)
            sl_sf.set(round(sf_val, 3), fire_callback=False)

    def _update_sigma_labels(self):
        """Sync sigma slider displays from _wv_sigmas (used by Estimate Filter)."""
        for sl_sg, sigma in zip([self.wsz1, self.wsz2, self.wsz3], self._wv_sigmas):
            sl_sg.set(round(sigma, 2), fire_callback=False)

    def _on_autosize_toggle(self):
        if self.wv_autosize.get():
            self._run_autosize()
            self._schedule_live(0)

    def _on_filter_change(self):
        fm = self.wv_filter.get().split()[0]
        # Show/hide bilateral controls
        if fm == "bilateral":
            self._bilateral_frame.pack(fill="x", pady=(2, 0))
            for chk in [self._bl_chk1, self._bl_chk2, self._bl_chk3]:
                chk.pack(anchor="w", padx=4, pady=(2, 4))
        else:
            self._bilateral_frame.pack_forget()
            for chk in [self._bl_chk1, self._bl_chk2, self._bl_chk3]:
                chk.pack_forget()
        # Show/hide Z-Gaussian factor control
        if fm == "zgaussian":
            self._zgauss_frame.pack(fill="x", pady=(2, 0))
        else:
            self._zgauss_frame.pack_forget()
        self._schedule_live(0)

    def _on_powerfn_toggle(self):
        """Enable / disable the power function spinbox and re-run pipeline."""
        enabled = self.wv_powerfn_enabled.get()
        self._pf_spinbox.config(state="normal" if enabled else "disabled")
        self._schedule_live(0)

    def _on_powerfn_change(self):
        """Validate spinbox value and re-run pipeline."""
        try:
            v = float(self.wv_powerfn_exp.get())
            v = max(0.10, min(4.00, v))
            self.wv_powerfn_exp.set(round(v, 2))
        except (ValueError, tk.TclError):
            self.wv_powerfn_exp.set(1.0)
        if self.wv_powerfn_enabled.get():
            self._schedule_live(0)

    # ── FFT Tab ─────────────────────────────────────────────
    def _build_fft_tab(self):
        TAB = 1
        f = self._scrollable_tab("◈  FFT")

        # FFT state: two draggable markers (0-100 %) + curve shape
        self.fft_marker_start = 60.0   # left teal marker — filter passband end
        self.fft_marker_end   = 90.0   # right teal marker — full stop start
        self._fft_dragging    = None   # "start" | "end" | None
        self.fft_layer        = tk.StringVar(value="POST")

        tk.Label(f, text="Drag the teal markers to set the filter band.  "
                         "Pink = unfiltered spectrum · Green = filtered · Blue = filter curve.",
                 bg=BG_PANEL, fg=FG_DIM, font=F_SM,
                 justify="left", wraplength=480).pack(fill="x", padx=10, pady=(8,4))

        # ── Interactive graph ────────────────────────────────
        section_header(f, "FREQUENCY SPECTRUM  &  FILTER CURVE", ACCENT_O).pack(fill="x", padx=6)
        GH = 360   # graph height px
        self.fft_canvas = tk.Canvas(f, height=GH, bg="#f5f0e8",
                                    highlightthickness=1, highlightbackground=BORDER,
                                    cursor="crosshair")
        self.fft_canvas.pack(fill="x", padx=6, pady=3)
        self.fft_canvas.bind("<ButtonPress-1>",   self._fft_mouse_down)
        self.fft_canvas.bind("<B1-Motion>",       self._fft_mouse_drag)
        self.fft_canvas.bind("<ButtonRelease-1>", self._fft_mouse_up)
        self.fft_canvas.bind("<Configure>",       lambda e: self._redraw_fft_graph())

        # Legend
        leg = tk.Frame(f, bg=BG_PANEL); leg.pack(fill="x", padx=8, pady=(0,4))
        for col, txt in [("#e040fb","Unfiltered"), ("#00c853","Filtered"), ("#2196f3","Filter curve")]:
            tk.Frame(leg, bg=col, width=18, height=3).pack(side="left", padx=(0,2), pady=6)
            tk.Label(leg, text=txt, bg=BG_PANEL, fg=FG_MID, font=F_TINY).pack(side="left", padx=(0,12))

        # ── Controls ─────────────────────────────────────────
        cf = card_frame(f, "FILTER SETTINGS", ACCENT_O)

        # Curve shape slider (replaces dropdown)
        # 0 = concave-down / gentle  ·  50 = linear  ·  100 = concave-up / aggressive
        row1 = tk.Frame(cf, bg=BG_CARD); row1.pack(fill="x", pady=(4,2))
        self.fft_curve_slider = self._reg(TAB, LabeledSlider(
            cf, "Curve  (gentle ◀ 0─────50─────100 ▶ aggressive)",
            0.0, 100.0, 25.0, ACCENT_O, "{:.0f}"))
        self.fft_curve_slider.pack(fill="x", pady=(0,4))
        self.fft_curve_slider.callback = lambda v: (self._schedule_live(TAB), self._redraw_fft_graph())

        # Start/end readouts (updated by dragging)
        row2 = tk.Frame(cf, bg=BG_CARD); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="▶ Start:", bg=BG_CARD, fg="#009688", font=F_SM,
                 width=10, anchor="w").pack(side="left")
        self.fft_start_lbl = tk.Label(row2, text="60%", bg=BG_CARD, fg="#009688", font=F_BOLD)
        self.fft_start_lbl.pack(side="left", padx=(0,20))
        tk.Label(row2, text="◀ End:", bg=BG_CARD, fg="#009688", font=F_SM).pack(side="left")
        self.fft_end_lbl = tk.Label(row2, text="90%", bg=BG_CARD, fg="#009688", font=F_BOLD)
        self.fft_end_lbl.pack(side="left", padx=4)

        # ON/OFF toggle
        row3 = tk.Frame(cf, bg=BG_CARD); row3.pack(fill="x", pady=4)
        self.fft_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(row3, text="Enable FFT Denoise", variable=self.fft_enabled,
                       bg=BG_CARD, fg=ACCENT_O, font=F_BOLD,
                       activebackground=BG_CARD, selectcolor=BG_RAISED,
                       command=self._fft_toggle
                       ).pack(side="left")
        self.fft_disabled_lbl = tk.Label(row3,
            text="⚠ bars have no effect until enabled",
            bg=BG_CARD, fg=ACCENT_R, font=F_TINY)
        self.fft_disabled_lbl.pack(side="left", padx=8)

        # Auto Denoise button
        row4 = tk.Frame(cf, bg=BG_CARD); row4.pack(fill="x", pady=(2,4))
        tk.Button(row4, text="⟴  Auto Denoise",
                  command=self._fft_auto_denoise,
                  bg=BG_RAISED, fg=ACCENT_O, font=F_MD, relief="flat",
                  cursor="hand2", padx=8, pady=4,
                  activebackground=SEL_BG).pack(side="left")
        self.fft_auto_lbl = tk.Label(row4, text="", bg=BG_CARD, fg=FG_DIM, font=F_TINY)
        self.fft_auto_lbl.pack(side="left", padx=8)

        # Layer selector — PRE/POST layers
        lf = card_frame(f, "LAYER", ACCENT_O)
        layers = [("POST — All Layers (after wavelet)", "POST"),
                  ("PRE  — Layer 1 (before Layer 1 sharpen)", "PRE1"),
                  ("PRE  — Layer 2 (before Layer 2 sharpen)", "PRE2"),
                  ("PRE  — Layer 3 (before Layer 3 sharpen)", "PRE3")]
        for txt, val in layers:
            fg_c = ACCENT_O if val == "POST" else FG_MID
            tk.Radiobutton(lf, text=txt, variable=self.fft_layer, value=val,
                           bg=BG_CARD, fg=fg_c, font=F_SM,
                           activebackground=BG_CARD, selectcolor=BG_RAISED,
                           command=lambda: self._schedule_live(TAB)).pack(anchor="w", pady=1)

        self._redraw_fft_graph()

    # ── FFT graph drag helpers ───────────────────────────────
    def _fft_toggle(self):
        """Called when Enable FFT Denoise checkbox is toggled."""
        if self.fft_enabled.get():
            self.fft_disabled_lbl.pack_forget()
        else:
            self.fft_disabled_lbl.pack(side="left", padx=8)
        self._schedule_live(1)
        self._redraw_fft_graph()

    def _fft_x_to_pct(self, x):
        cw = max(self.fft_canvas.winfo_width(), 400)
        return max(0.0, min(100.0, x / cw * 100.0))

    def _fft_mouse_down(self, event):
        """Start dragging whichever marker is closest."""
        pct  = self._fft_x_to_pct(event.x)
        cw   = max(self.fft_canvas.winfo_width(), 400)
        xs   = self.fft_marker_start / 100.0 * cw
        xe   = self.fft_marker_end   / 100.0 * cw
        self._fft_dragging = "start" if abs(event.x - xs) <= abs(event.x - xe) else "end"

    def _fft_mouse_drag(self, event):
        if not self._fft_dragging: return
        pct = self._fft_x_to_pct(event.x)
        if self._fft_dragging == "start":
            self.fft_marker_start = min(pct, self.fft_marker_end - 2.0)
        else:
            self.fft_marker_end = max(pct, self.fft_marker_start + 2.0)
        self.fft_start_lbl.configure(text=f"{self.fft_marker_start:.0f}%")
        self.fft_end_lbl.configure(text=f"{self.fft_marker_end:.0f}%")
        self._redraw_fft_graph()

    def _fft_mouse_up(self, event):
        if self._fft_dragging:
            self._fft_dragging = None
            self._schedule_live(1)

    def _draw_fft_graph(self):
        """Draw FFT graph: unfiltered (pink), filtered (green), filter curve (blue)."""
        c = self.fft_canvas
        c.delete("all")
        cw  = max(c.winfo_width(), 400)
        GH  = max(c.winfo_height(), 360)
        PAD_B = 22   # bottom axis strip
        ph    = GH - PAD_B  # usable plot height

        BINS = 80

        # ── Background ───────────────────────────────────────
        c.create_rectangle(0, 0, cw, GH, fill="#f5f0e8", outline="")
        # Vertical dashed grid lines (every 10%)
        for pct in range(0, 101, 10):
            gx = int(pct / 100.0 * cw)
            c.create_line(gx, 0, gx, ph, fill="#d0c8b0", width=1, dash=(3,3))

        # ── Filter curve ─────────────────────────────────────
        fft_start = getattr(self, "fft_marker_start", 60.0)
        fft_end   = getattr(self, "fft_marker_end",   90.0)
        fft_width = max(0.1, fft_end - fft_start)
        try:    curve_shape = float(self.fft_curve_slider.get())
        except: curve_shape = 25.0
        filt = proc.build_fft_filter_curve(fft_start, fft_width, curve_shape, BINS)

        # ── Power spectra (unfiltered & filtered) ────────────
        raw_spec = getattr(self, "_fft_spectrum", None)
        if raw_spec is not None:
            # Interpolate spectrum to BINS resolution
            import numpy as np
            sp = np.interp(np.linspace(0,1,BINS), np.linspace(0,1,len(raw_spec)), raw_spec)
        else:
            import numpy as np
            x = np.linspace(0, 1, BINS)
            sp = np.exp(-5 * x) * 0.9 + 0.05 * np.exp(-30 * (x - 0.15)**2)
            sp = sp / sp.max()

        # Unfiltered — pink/magenta polyline
        pts_raw = []
        for i, v in enumerate(sp):
            px_ = int((i + 0.5) * cw / BINS)
            py_ = int(ph - 4 - v * (ph - 8))
            pts_raw.extend([px_, py_])
        if len(pts_raw) >= 4:
            c.create_line(pts_raw, fill="#e040fb", width=2, smooth=True)

        # Filtered — green polyline (spectrum × filter)
        filt_sp = sp * filt
        pts_filt = []
        for i, v in enumerate(filt_sp):
            px_ = int((i + 0.5) * cw / BINS)
            py_ = int(ph - 4 - v * (ph - 8))
            pts_filt.extend([px_, py_])
        if len(pts_filt) >= 4:
            c.create_line(pts_filt, fill="#00c853", width=2, smooth=True)

        # Filter curve — blue polyline (scaled to full height)
        pts_flt = []
        for i, v in enumerate(filt):
            px_ = int((i + 0.5) * cw / BINS)
            py_ = int(ph - 4 - v * (ph - 8))
            pts_flt.extend([px_, py_])
        if len(pts_flt) >= 4:
            c.create_line(pts_flt, fill="#2196f3", width=2, smooth=True)

        # ── Teal marker lines with arrows ────────────────────
        sx = int(fft_start / 100.0 * cw)
        ex = int(fft_end   / 100.0 * cw)
        # Shaded stopband region
        c.create_rectangle(ex, 0, cw, ph, fill="#e0d8c0", outline="", stipple="gray25")
        # Start marker
        c.create_line(sx, 0, sx, ph, fill="#009688", width=2)
        c.create_polygon(sx-7, ph-2, sx+7, ph-2, sx, ph+10, fill="#009688", outline="")
        # End marker
        c.create_line(ex, 0, ex, ph, fill="#009688", width=2)
        c.create_polygon(ex-7, ph-2, ex+7, ph-2, ex, ph+10, fill="#009688", outline="")
        # ── Curve (middle) marker — orange upward triangle ───
        # Positioned at the x midpoint of the rolloff band,
        # y position reflects the filter value at that point (visual feedback).
        mx = (sx + ex) // 2
        curve_v = float(filt[min(int(mx / cw * BINS), BINS-1)])
        my = int(ph - 4 - curve_v * (ph - 8))
        # Vertical dashed line at midpoint
        c.create_line(mx, 0, mx, ph, fill="#e65100", width=1, dash=(3,3))
        # Upward triangle at curve height
        c.create_polygon(mx-8, my+14, mx+8, my+14, mx, my, fill="#e65100", outline="")
        c.create_text(mx, my-8, text=f"{curve_shape:.0f}", fill="#e65100", font=F_TINY, anchor="s")

        # ── Axis ─────────────────────────────────────────────
        c.create_line(0, ph, cw, ph, fill="#888", width=1)
        for pct, lbl in [(0,"DC"), (25,"25%"), (50,"50%"), (75,"75%"), (100,"Nyquist")]:
            ax = int(pct / 100.0 * cw)
            if pct == 0:
                anchor_, x_ = "sw", max(ax, 2)
            elif pct == 100:
                anchor_, x_ = "se", min(ax, cw - 2)
            else:
                anchor_, x_ = "s", ax
            c.create_text(x_, GH-2, anchor=anchor_, text=lbl, fill=FG_DIM, font=F_TINY)

        # ── Enabled indicator ────────────────────────────────
        try:
            enabled = self.fft_enabled.get()
        except: enabled = False
        if enabled:
            c.create_rectangle(cw-52, 4, cw-4, 24, fill=ACCENT_O, outline="")
            c.create_text(cw-28, 14, anchor="center", text="ON", fill="white", font=F_BOLD)
        else:
            c.create_rectangle(cw-72, 4, cw-4, 24, fill="#cccccc", outline="")
            c.create_text(cw-38, 14, anchor="center", text="OFF", fill="#666666", font=F_BOLD)
            # Dim overlay to show filter is inactive
            c.create_rectangle(0, 0, cw, ph, fill="#f5f0e8", outline="", stipple="gray50")
            c.create_text(cw//2, ph//2, text="FFT DENOISE DISABLED",
                         fill="#999999", font=F_BOLD, anchor="center")

    def _redraw_fft_graph(self):
        self._draw_fft_graph()

    # ── Color Tab ───────────────────────────────────────────
    def _build_color_tab(self):
        TAB = 2
        f = self._scrollable_tab("◉  RGB")
        tk.Label(f, text="Correct atmospheric dispersion, sensor bias, and adjust tone.",
                 bg=BG_PANEL, fg=FG_DIM, font=F_SM,
                 justify="left", wraplength=480).pack(fill="x", padx=10, pady=(8,4))

        cr = card_frame(f,"RED CHANNEL",ACCENT_R)
        self.rgb_r   = self._reg(TAB, LabeledSlider(cr,"Gain % (0–100)",    0,200,100,ACCENT_R,lambda v: f"{v/2:.0f}"))
        self.rgb_r.pack(fill="x",pady=2)
        self.black_r = self._reg(TAB, LabeledSlider(cr,"Black Point (0–100%)", 0,100,0,ACCENT_R,"{:.1f}"))
        self.black_r.pack(fill="x",pady=2)
        self.gamma_r = self._reg(TAB, LabeledSlider(cr,"Gamma ÷100 (0.5–2.0)", 50,200,100,ACCENT_R,"{:.0f}"))
        self.gamma_r.pack(fill="x",pady=2)

        cg = card_frame(f,"GREEN CHANNEL",ACCENT_G)
        self.rgb_g   = self._reg(TAB, LabeledSlider(cg,"Gain % (0–100)",    0,200,100,ACCENT_G,lambda v: f"{v/2:.0f}"))
        self.rgb_g.pack(fill="x",pady=2)
        self.black_g = self._reg(TAB, LabeledSlider(cg,"Black Point (0–100%)", 0,100,0,ACCENT_G,"{:.1f}"))
        self.black_g.pack(fill="x",pady=2)
        self.gamma_g = self._reg(TAB, LabeledSlider(cg,"Gamma ÷100 (0.5–2.0)", 50,200,100,ACCENT_G,"{:.0f}"))
        self.gamma_g.pack(fill="x",pady=2)

        cb2 = card_frame(f,"BLUE CHANNEL","#2563eb")
        self.rgb_b   = self._reg(TAB, LabeledSlider(cb2,"Gain % (0–100)",   0,200,100,"#2563eb",lambda v: f"{v/2:.0f}"))
        self.rgb_b.pack(fill="x",pady=2)
        self.black_b = self._reg(TAB, LabeledSlider(cb2,"Black Point (0–100%)", 0,100,0,"#2563eb","{:.1f}"))
        self.black_b.pack(fill="x",pady=2)
        self.gamma_b = self._reg(TAB, LabeledSlider(cb2,"Gamma ÷100 (0.5–2.0)",50,200,100,"#2563eb","{:.0f}"))
        self.gamma_b.pack(fill="x",pady=2)

        tk.Button(f, text="◎  AUTO RGB BALANCE", command=self.auto_balance,
                  bg=BG_RAISED, fg=ACCENT_G, font=F_BOLD, relief="flat",
                  cursor="hand2", padx=12, pady=5,
                  activebackground=SEL_BG).pack(fill="x", padx=6, pady=(4,2))

        cs2 = card_frame(f,"SATURATION & TONE",ACCENT_C)

        self.saturation = self._reg(TAB, LabeledSlider(cs2,"Saturation (0–100)", 0,200,100,ACCENT_C,lambda v: f"{v/2:.0f}"))
        self.saturation.pack(fill="x",pady=2)
        self.vibrance   = self._reg(TAB, LabeledSlider(cs2,"Vibrance (0–100)",   0,200,100,ACCENT_C,lambda v: f"{v/2:.0f}"))
        self.vibrance.pack(fill="x",pady=2)
        self.hue_rot    = self._reg(TAB, LabeledSlider(cs2,"Hue Rotation (°)", -180,180,0,FG_MID,"{:.0f}°"))
        self.hue_rot.pack(fill="x",pady=2)
        self.brightness = self._reg(TAB, LabeledSlider(cs2,"Brightness",      -100,100,0,FG_MID))
        self.brightness.pack(fill="x",pady=2)
        self.contrast   = self._reg(TAB, LabeledSlider(cs2,"Contrast",        -100,100,0,FG_MID))
        self.contrast.pack(fill="x",pady=2)

        tk.Button(f, text="◎  AUTO WHITE BALANCE", command=self.auto_white_balance,
                  bg=BG_RAISED, fg=ACCENT_G, font=F_BOLD, relief="flat",
                  cursor="hand2", padx=12, pady=6,
                  activebackground=SEL_BG).pack(fill="x", padx=6, pady=8)

    # ── Tools Tab ───────────────────────────────────────────────────────────
    def _build_tools_tab(self):
        TAB = 3
        f = self._scrollable_tab("⚙  Tools")

        # ── LEVELS & CURVES ─────────────────────────────────────────────────
        section_header(f, "LEVELS & CURVES", ACCENT_C).pack(fill="x", padx=6)
        lc = card_frame(f, subtitle="Per-channel black/white point, gamma, and tone curve")

        chan_row = tk.Frame(lc, bg=BG_CARD); chan_row.pack(fill="x", pady=(2,4))
        tk.Label(chan_row, text="Channel:", bg=BG_CARD, fg=FG_MID,
                 font=F_SM).pack(side="left")
        self._lc_channel = tk.StringVar(value="All")
        for ch in ["All", "R", "G", "B"]:
            tk.Radiobutton(chan_row, text=ch, variable=self._lc_channel, value=ch,
                           bg=BG_CARD, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                           activebackground=BG_CARD, font=F_SM,
                           command=self._on_lc_channel_change).pack(side="left", padx=(6,0))

        def _lc_sb(parent, label, var, from_, to, inc, fmt, accent):
            row = tk.Frame(parent, bg=BG_CARD); row.pack(fill="x", pady=1)
            tk.Label(row, text=label, bg=BG_CARD, fg=FG_MID, font=F_SM,
                     width=14, anchor="w").pack(side="left")
            sb = tk.Spinbox(row, from_=from_, to=to, increment=inc,
                            textvariable=var, width=7, font=F_MD, format=fmt,
                            relief="flat", bg=BG_RAISED, fg=accent,
                            buttonbackground=BG_RAISED, activebackground=SEL_BG)
            sb.pack(side="left")
            var.trace_add("write", lambda *_: self._schedule_live(0))
            sb.bind("<Return>",   lambda e: self._schedule_live(0))
            sb.bind("<FocusOut>", lambda e: self._schedule_live(0))

        self._lc_all_frame = tk.Frame(lc, bg=BG_CARD)
        self._lc_black_all = tk.DoubleVar(value=0.0)
        self._lc_white_all = tk.DoubleVar(value=1.0)
        self._lc_gamma_all = tk.DoubleVar(value=1.0)
        _lc_sb(self._lc_all_frame, "Black point:", self._lc_black_all, 0.0, 0.99, 0.01, "%.2f", ACCENT_C)
        _lc_sb(self._lc_all_frame, "White point:", self._lc_white_all, 0.01, 1.0,  0.01, "%.2f", ACCENT_C)
        _lc_sb(self._lc_all_frame, "Gamma:",       self._lc_gamma_all, 0.1,  4.0,  0.05, "%.2f", ACCENT_C)

        self._lc_rgb_frame = tk.Frame(lc, bg=BG_CARD)
        self._lc_black = {c: tk.DoubleVar(value=0.0) for c in "RGB"}
        self._lc_white = {c: tk.DoubleVar(value=1.0) for c in "RGB"}
        self._lc_gamma = {c: tk.DoubleVar(value=1.0) for c in "RGB"}
        _acc = {"R": ACCENT_O, "G": ACCENT_G, "B": ACCENT_C}
        for ch in "RGB":
            _lc_sb(self._lc_rgb_frame, f"{ch} Black:", self._lc_black[ch], 0.0,  0.99, 0.01, "%.2f", _acc[ch])
            _lc_sb(self._lc_rgb_frame, f"{ch} White:", self._lc_white[ch], 0.01, 1.0,  0.01, "%.2f", _acc[ch])
            _lc_sb(self._lc_rgb_frame, f"{ch} Gamma:", self._lc_gamma[ch], 0.1,  4.0,  0.05, "%.2f", _acc[ch])
        self._lc_all_frame.pack(fill="x")

        tk.Label(lc, text="Tone Curve  (click=add point  \u00b7  right-click=remove)",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack(anchor="w", padx=4, pady=(6,2))
        CURVE_SZ = 300
        curve_outer = tk.Frame(lc, bg=BORDER, padx=1, pady=1)
        curve_outer.pack(padx=4, pady=(0,4))
        self._curve_canvas = tk.Canvas(curve_outer, width=CURVE_SZ, height=CURVE_SZ,
                                       bg="#1a1e26", highlightthickness=0)
        self._curve_canvas.pack()
        self._curve_size = CURVE_SZ
        self._curve_pts  = {c: [[0.0,0.0],[1.0,1.0]] for c in ["All","R","G","B"]}
        self._curve_dragging = None
        self._curve_canvas.bind("<Button-1>",       self._curve_click)
        self._curve_canvas.bind("<B1-Motion>",       self._curve_drag)
        self._curve_canvas.bind("<ButtonRelease-1>", self._curve_release)
        self._curve_canvas.bind("<Button-3>",        self._curve_remove)

        btn_row = tk.Frame(lc, bg=BG_CARD); btn_row.pack(fill="x", padx=4, pady=(0,4))
        tk.Button(btn_row, text="\u2298  Reset Curve", command=self._lc_reset_curve,
                  bg=BG_RAISED, fg=FG_DIM, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=3,
                  activebackground=SEL_BG).pack(side="left")
        tk.Button(btn_row, text="\u2298  Reset All", command=self._lc_reset_all,
                  bg=BG_RAISED, fg=FG_DIM, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=3,
                  activebackground=SEL_BG).pack(side="left", padx=(4,0))
        self._draw_curve_canvas()

        # ── CLAHE ────────────────────────────────────────────────────────────
        section_header(f, "CLAHE", ACCENT_P).pack(fill="x", padx=6, pady=(10,0))
        cl = card_frame(f, subtitle="Contrast Limited Adaptive Histogram Equalisation")

        self._clahe_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(cl, text="Enable CLAHE",
                       variable=self._clahe_enabled, bg=BG_CARD, fg=FG_BRIGHT,
                       font=F_SM, activebackground=BG_CARD, selectcolor=BG_RAISED,
                       command=lambda: self._schedule_live(0)).pack(anchor="w", pady=(2,4))

        def _cl_sb(label, var, from_, to, inc, fmt):
            row = tk.Frame(cl, bg=BG_CARD); row.pack(fill="x", pady=1)
            tk.Label(row, text=label, bg=BG_CARD, fg=FG_MID, font=F_SM,
                     width=16, anchor="w").pack(side="left")
            sb = tk.Spinbox(row, from_=from_, to=to, increment=inc,
                            textvariable=var, width=7, font=F_MD, format=fmt,
                            relief="flat", bg=BG_RAISED, fg=ACCENT_P,
                            buttonbackground=BG_RAISED, activebackground=SEL_BG)
            sb.pack(side="left")
            def _on_write(*_):
                self._clahe_enabled.set(True)   # auto-enable when tweaking values
                self._schedule_live(0)
            var.trace_add("write", _on_write)
            sb.bind("<Return>",   lambda e: (self._clahe_enabled.set(True), self._schedule_live(0)))
            sb.bind("<FocusOut>", lambda e: self._schedule_live(0))

        self._clahe_clip     = tk.DoubleVar(value=0.5)
        self._clahe_tile     = tk.DoubleVar(value=4.0)
        self._clahe_strength = tk.DoubleVar(value=0.05)
        _cl_sb("Clip Limit:",  self._clahe_clip,     0.5, 10.0, 0.5,  "%.1f")
        _cl_sb("Tile Grid:",   self._clahe_tile,     4,   64,   4,    "%.0f")
        _cl_sb("Strength:",    self._clahe_strength, 0.0, 1.0,  0.05, "%.2f")

        cr2 = tk.Frame(cl, bg=BG_CARD); cr2.pack(fill="x", pady=(4,2))
        tk.Label(cr2, text="Apply to:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(side="left")
        self._clahe_channel = tk.StringVar(value="luminance")
        for val, lbl in [("luminance","Luminance only"),("rgb","RGB channels")]:
            tk.Radiobutton(cr2, text=lbl, variable=self._clahe_channel, value=val,
                           bg=BG_CARD, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                           activebackground=BG_CARD, font=F_SM,
                           command=lambda: self._schedule_live(0)).pack(side="left", padx=(6,0))
        tk.Label(cl,
                 text="Clip Limit: higher = stronger contrast (default 0.5).\n"
                      "Tile Grid: smaller = more local contrast (default 4).\n"
                      "Luminance only is safer \u2014 RGB mode can shift colours.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY,
                 justify="left", wraplength=360).pack(anchor="w", padx=4, pady=(4,4))
        tk.Button(cl, text="\u2298  Reset CLAHE",
                  command=self._clahe_reset,
                  bg=BG_RAISED, fg=FG_DIM, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=3,
                  activebackground=SEL_BG).pack(anchor="w", padx=4, pady=(0,4))

    # ── Tools Tab helpers ────────────────────────────────────────────────────

    def _on_lc_channel_change(self):
        ch = self._lc_channel.get()
        if ch == "All":
            self._lc_rgb_frame.pack_forget()
            self._lc_all_frame.pack(fill="x")
        else:
            self._lc_all_frame.pack_forget()
            self._lc_rgb_frame.pack(fill="x")
        self._draw_curve_canvas()
        self._schedule_live(0)

    def _curve_pt_to_canvas(self, px, py):
        sz = self._curve_size
        return int(px * (sz-1)), int((1.0-py) * (sz-1))

    def _canvas_to_curve_pt(self, cx, cy):
        sz = self._curve_size
        return cx / (sz-1), 1.0 - cy / (sz-1)

    def _draw_curve_canvas(self):
        import numpy as _np
        cnv = self._curve_canvas
        sz  = self._curve_size
        ch  = self._lc_channel.get()
        pts = self._curve_pts[ch]
        cnv.delete("all")
        for i in range(1, 4):
            v = int(i * sz / 4)
            cnv.create_line(v, 0, v, sz, fill="#2a2e38", width=1)
            cnv.create_line(0, v, sz, v, fill="#2a2e38", width=1)
        cnv.create_line(0, sz-1, sz-1, 0, fill="#2a2e38", width=1, dash=(4,4))
        arr = self.working_arr if self.working_arr is not None else self.original_arr
        if arr is not None:
            cidx = {"All":None,"R":0,"G":1,"B":2}.get(ch)
            data = (0.299*arr[...,0]+0.587*arr[...,1]+0.114*arr[...,2]).flatten() \
                   if cidx is None else arr[...,cidx].flatten()
            hist, _ = _np.histogram(data, bins=64, range=(0,1))
            hmax = hist.max() if hist.max() > 0 else 1
            bw = sz / 64
            hcol = {"All":"#6a8aaa","R":"#aa5555","G":"#55aa55","B":"#5577cc"}.get(ch,"#6a8aaa")
            for i, h in enumerate(hist):
                bh = int(h / hmax * (sz * 0.7))
                cnv.create_rectangle(int(i*bw), sz, int((i+1)*bw), sz-bh,
                                     fill=hcol, outline="")
        if len(pts) >= 2:
            lut = proc._build_curve_lut(pts)
            coords = []
            for i in range(sz):
                t = i / (sz-1)
                idx = min(int(t*255), 255)
                _, cy = self._curve_pt_to_canvas(t, float(lut[idx]))
                coords += [i, cy]
            lcol = {"All":"#60a0d0","R":"#e06060","G":"#60c060","B":"#6080e0"}.get(ch,"#60a0d0")
            cnv.create_line(coords, fill=lcol, width=2)
        for i, (px, py) in enumerate(pts):
            cx, cy = self._curve_pt_to_canvas(px, py)
            cnv.create_oval(cx-5,cy-5,cx+5,cy+5, fill=ACCENT_C, outline="white", width=1)

    def _curve_hit_test(self, cx, cy):
        ch = self._lc_channel.get()
        best, best_d = None, 12
        for i, (px, py) in enumerate(self._curve_pts[ch]):
            ox, oy = self._curve_pt_to_canvas(px, py)
            d = ((cx-ox)**2+(cy-oy)**2)**0.5
            if d < best_d:
                best, best_d = i, d
        return best

    def _curve_click(self, event):
        ch  = self._lc_channel.get()
        pts = self._curve_pts[ch]
        hit = self._curve_hit_test(event.x, event.y)
        if hit is not None:
            self._curve_dragging = hit
        else:
            nx, ny = self._canvas_to_curve_pt(event.x, event.y)
            nx = max(0.0, min(1.0, nx))
            ny = max(0.0, min(1.0, ny))
            pts.append([nx, ny])
            pts.sort(key=lambda p: p[0])
            self._curve_dragging = next(i for i,(x,y) in enumerate(pts) if x==nx and y==ny)
            self._draw_curve_canvas()
            self._schedule_live(0)

    def _curve_drag(self, event):
        if self._curve_dragging is None: return
        ch  = self._lc_channel.get()
        pts = self._curve_pts[ch]
        i   = self._curve_dragging
        nx, ny = self._canvas_to_curve_pt(event.x, event.y)
        xmin = pts[i-1][0]+0.01 if i > 0 else 0.0
        xmax = pts[i+1][0]-0.01 if i < len(pts)-1 else 1.0
        pts[i][0] = max(xmin, min(xmax, nx))
        pts[i][1] = max(0.0, min(1.0, ny))
        self._draw_curve_canvas()
        self._schedule_live(0)

    def _curve_release(self, event):
        self._curve_dragging = None

    def _curve_remove(self, event):
        ch  = self._lc_channel.get()
        pts = self._curve_pts[ch]
        hit = self._curve_hit_test(event.x, event.y)
        if hit is not None and 0 < hit < len(pts)-1:
            pts.pop(hit)
            self._draw_curve_canvas()
            self._schedule_live(0)

    def _clahe_reset(self):
        """Reset all CLAHE controls to defaults."""
        self._clahe_enabled.set(False)
        self._clahe_clip.set(0.5)
        self._clahe_tile.set(4.0)
        self._clahe_strength.set(0.05)
        self._clahe_channel.set("luminance")
        self._schedule_live(0)

    def _lc_reset_curve(self):
        ch = self._lc_channel.get()
        self._curve_pts[ch] = [[0.0,0.0],[1.0,1.0]]
        self._draw_curve_canvas()
        self._schedule_live(0)

    def _lc_reset_all(self):
        for ch in ["All","R","G","B"]:
            self._curve_pts[ch] = [[0.0,0.0],[1.0,1.0]]
        self._lc_black_all.set(0.0); self._lc_white_all.set(1.0); self._lc_gamma_all.set(1.0)
        for ch in "RGB":
            self._lc_black[ch].set(0.0); self._lc_white[ch].set(1.0); self._lc_gamma[ch].set(1.0)
        self._draw_curve_canvas()
        self._schedule_live(0)

    def _get_lc_params(self):
        ch = self._lc_channel.get()
        if ch == "All":
            bl=float(self._lc_black_all.get()); wh=float(self._lc_white_all.get()); gm=float(self._lc_gamma_all.get())
            br=bl; wr=wh; gr=gm; bg=bl; wg=wh; gg=gm; bb=bl; wb=wh; gb=gm
            lut=proc._build_curve_lut(self._curve_pts["All"]); lr=lut; lg=lut; lb=lut
        else:
            br=float(self._lc_black["R"].get()); wr=float(self._lc_white["R"].get()); gr=float(self._lc_gamma["R"].get())
            bg=float(self._lc_black["G"].get()); wg=float(self._lc_white["G"].get()); gg=float(self._lc_gamma["G"].get())
            bb=float(self._lc_black["B"].get()); wb=float(self._lc_white["B"].get()); gb=float(self._lc_gamma["B"].get())
            lr=proc._build_curve_lut(self._curve_pts["R"])
            lg=proc._build_curve_lut(self._curve_pts["G"])
            lb=proc._build_curve_lut(self._curve_pts["B"])
        def _curve_is_identity(pts):
            """True only if the curve is the exact identity: two points at (0,0) and (1,1)."""
            return (len(pts) == 2
                    and abs(pts[0][0]) < 0.001 and abs(pts[0][1]) < 0.001
                    and abs(pts[1][0] - 1.0) < 0.001 and abs(pts[1][1] - 1.0) < 0.001)
        is_default=(br==0 and wr==1 and gr==1 and bg==0 and wg==1 and gg==1 and bb==0 and wb==1 and gb==1
                    and all(_curve_is_identity(self._curve_pts[c]) for c in ["All","R","G","B"]))
        return br,wr,gr,bg,wg,gg,bb,wb,gb,lr,lg,lb,is_default


    # ── De-rind Tab ────────────────────────────────────────────
    def _build_dering_tab(self):
        TAB = 4
        f = self._scrollable_tab("◎  De-rind")

        # ── Enable + Auto ────────────────────────────────────────
        en_row = tk.Frame(f, bg=BG_PANEL)
        en_row.pack(fill="x", padx=10, pady=(8, 2))
        self.dr_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(
            en_row, text="ENABLE DE-RIND", variable=self.dr_enabled,
            bg=BG_PANEL, fg=ACCENT_O, selectcolor=BG_RAISED,
            activebackground=BG_PANEL, activeforeground=ACCENT_O,
            font=F_BOLD, anchor="w", indicatoron=True,
            command=lambda: self._schedule_live(TAB),
        ).pack(side="left")
        tk.Button(en_row, text="⟴  Auto De-rind",
                  command=self._auto_dering,
                  bg=BG_RAISED, fg=ACCENT_P, font=F_MD, relief="flat",
                  cursor="hand2", padx=8, pady=3,
                  activebackground=SEL_BG).pack(side="left", padx=(12, 0))
        self.dr_auto_lbl = tk.Label(en_row, text="", bg=BG_PANEL, fg=FG_DIM, font=F_TINY)
        self.dr_auto_lbl.pack(side="left", padx=8)

        tk.Label(f, text="Suppresses the halo/rind artifact around bright planetary limbs after heavy sharpening.",
                 bg=BG_PANEL, fg=FG_DIM, font=F_SM,
                 justify="left", wraplength=480).pack(fill="x", padx=10, pady=(2, 6))

        # ── Main controls ────────────────────────────────────────
        cm = card_frame(f, "MASK", ACCENT_P)

        self.dr_edge    = self._reg(TAB, LabeledSlider(cm, "Edge  (outer extent, px)",    1, 40, 8,  ACCENT_P, "{:.0f}"))
        self.dr_edge.pack(fill="x", pady=2)
        self.dr_feather = self._reg(TAB, LabeledSlider(cm, "Feather  (inward falloff, px)", 0, 30, 4, ACCENT_P, "{:.0f}"))
        self.dr_feather.pack(fill="x", pady=2)
        self.dr_smooth  = self._reg(TAB, LabeledSlider(cm, "Smooth  (mask breadth, px)",  0, 20, 2,  FG_MID,   "{:.0f}"))
        self.dr_smooth.pack(fill="x", pady=2)
        self.dr_inset   = self._reg(TAB, LabeledSlider(cm, "Inset  (pull mask inward, px)", 0, 60, 0, FG_MID,   "{:.0f}"))
        self.dr_inset.pack(fill="x", pady=2)

        ae_row = tk.Frame(cm, bg=BG_CARD); ae_row.pack(fill="x", pady=(4, 2))
        tk.Button(ae_row, text="⟴  Auto Edge",
                  command=self._auto_edge,
                  bg=BG_RAISED, fg=ACCENT_P, font=F_MD, relief="flat",
                  cursor="hand2", padx=8, pady=3,
                  activebackground=SEL_BG).pack(side="left")
        self.dr_edge_lbl = tk.Label(ae_row, text="", bg=BG_CARD, fg=FG_DIM, font=F_TINY)
        self.dr_edge_lbl.pack(side="left", padx=8)

        # ── Gap controls ─────────────────────────────────────────
        cg = card_frame(f, "GAP", ACCENT_P)
        tk.Label(cg, text="Restrict the mask to exclude part of the ring arc (e.g. Saturn’s rings).",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY, wraplength=440, justify="left").pack(anchor="w", pady=(0,4))

        # Gap Width row
        gw_row = tk.Frame(cg, bg=BG_CARD); gw_row.pack(fill="x", pady=2)
        tk.Label(gw_row, text="Gap Width (°)", bg=BG_CARD, fg=FG_MID, font=F_SM, width=18, anchor="w").pack(side="left")
        self.dr_gap_width = tk.DoubleVar(value=0.0)
        self._dr_gap_width_lbl = tk.Label(gw_row, textvariable=self.dr_gap_width,
                                           bg=BG_CARD, fg=ACCENT_P, font=F_MD, width=6, anchor="e")
        self._dr_gap_width_lbl.pack(side="right")
        gw_spin = tk.Spinbox(gw_row, from_=0, to=180, increment=5,
                              textvariable=self.dr_gap_width, width=6,
                              font=F_SM, relief="flat", bg=BG_RAISED,
                              command=lambda: self._schedule_live(TAB))
        gw_spin.pack(side="right", padx=4)
        gw_spin.bind("<MouseWheel>", lambda e: self._spinbox_wheel(e, self.dr_gap_width, 5, 0, 180, TAB))
        gw_spin.bind("<Button-4>",   lambda e: self._spinbox_wheel(e, self.dr_gap_width, 5, 0, 180, TAB))
        gw_spin.bind("<Button-5>",   lambda e: self._spinbox_wheel(e, self.dr_gap_width, 5, 0, 180, TAB))
        gw_spin.bind("<FocusOut>",   lambda e: self._schedule_live(TAB))
        gw_spin.bind("<Return>",     lambda e: self._schedule_live(TAB))

        # Gap Angle row
        ga_row = tk.Frame(cg, bg=BG_CARD); ga_row.pack(fill="x", pady=2)
        tk.Label(ga_row, text="Gap Angle (°)", bg=BG_CARD, fg=FG_MID, font=F_SM, width=18, anchor="w").pack(side="left")
        self.dr_gap_angle = tk.DoubleVar(value=0.0)
        tk.Label(ga_row, textvariable=self.dr_gap_angle,
                 bg=BG_CARD, fg=ACCENT_P, font=F_MD, width=6, anchor="e").pack(side="right")
        ga_spin = tk.Spinbox(ga_row, from_=0, to=359, increment=5,
                              textvariable=self.dr_gap_angle, width=6,
                              font=F_SM, relief="flat", bg=BG_RAISED,
                              command=lambda: self._schedule_live(TAB))
        ga_spin.pack(side="right", padx=4)
        ga_spin.bind("<MouseWheel>", lambda e: self._spinbox_wheel(e, self.dr_gap_angle, 5, 0, 359, TAB))
        ga_spin.bind("<Button-4>",   lambda e: self._spinbox_wheel(e, self.dr_gap_angle, 5, 0, 359, TAB))
        ga_spin.bind("<Button-5>",   lambda e: self._spinbox_wheel(e, self.dr_gap_angle, 5, 0, 359, TAB))
        ga_spin.bind("<FocusOut>",   lambda e: self._schedule_live(TAB))
        ga_spin.bind("<Return>",     lambda e: self._schedule_live(TAB))

        # Saturn checkbox
        sat_row = tk.Frame(cg, bg=BG_CARD); sat_row.pack(fill="x", pady=(4,2))
        self.dr_saturn = tk.BooleanVar(value=False)
        tk.Checkbutton(sat_row, text="Saturn mode  (auto-gap both sides)",
                       variable=self.dr_saturn, bg=BG_CARD, fg=FG_MID,
                       selectcolor=BG_RAISED, activebackground=BG_CARD,
                       font=F_SM, command=lambda: self._schedule_live(TAB)
                       ).pack(side="left")

        # ── Show ring map ─────────────────────────────────────────
        map_row = tk.Frame(f, bg=BG_PANEL); map_row.pack(fill="x", padx=10, pady=(6,2))
        self.dr_show_map = tk.BooleanVar(value=False)
        tk.Checkbutton(map_row, text="Show De-rind Mask overlay",
                       variable=self.dr_show_map, bg=BG_PANEL, fg=FG_MID,
                       selectcolor=BG_RAISED, activebackground=BG_PANEL,
                       font=F_SM, command=lambda: self._schedule_live(TAB)
                       ).pack(side="left")

        # ── Advanced (collapsible) ────────────────────────────────
        adv_hdr = tk.Frame(f, bg=BG_PANEL); adv_hdr.pack(fill="x", padx=6, pady=(8, 0))
        self._dr_adv_open = tk.BooleanVar(value=False)
        self._dr_adv_btn  = tk.Button(adv_hdr, text="▶  Advanced",
                  command=self._toggle_dr_advanced,
                  bg=BG_PANEL, fg=FG_MID, font=F_SM, relief="flat",
                  cursor="hand2", anchor="w", activebackground=BG_PANEL)
        self._dr_adv_btn.pack(side="left")

        self._dr_adv_frame = tk.Frame(f, bg=BG_PANEL)

        ca = card_frame(self._dr_adv_frame, "ADVANCED", ACCENT_C)
        ca.pack(fill="x", padx=6, pady=(4,2))

        # Dark edge toggle (on by default)
        self.dr_dark_edge = tk.BooleanVar(value=True)
        tk.Checkbutton(ca, text="Dark Edge  (suppress diffraction rings outside limb)",
                       variable=self.dr_dark_edge, bg=BG_CARD, fg=FG_MID,
                       selectcolor=BG_RAISED, activebackground=BG_CARD,
                       font=F_SM, command=lambda: self._schedule_live(TAB)
                       ).pack(anchor="w", pady=2)
        tk.Label(ca, text="Especially useful on Mars to suppress bright rings well outside the limb.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY, wraplength=440, justify="left").pack(anchor="w", pady=(0,6))

        # Pre-blur
        self.dr_pre_blur = self._reg(TAB, LabeledSlider(ca, "Pre-blur σ  (0=off)", 0, 5, 0, FG_MID, "{:.1f}"))
        self.dr_pre_blur.pack(fill="x", pady=2)
        tk.Label(ca, text="Blur the image before de-rinding. Useful when ringing is very strong.",
                 bg=BG_CARD, fg=FG_DIM, font=F_TINY, wraplength=440, justify="left").pack(anchor="w", pady=(0,4))

    def _spinbox_wheel(self, event, var, step, lo, hi, tab):
        """Mouse-wheel handler for Gap spinboxes."""
        delta = -step if (event.num == 5 or getattr(event, "delta", 0) < 0) else step
        new_val = (var.get() + delta - lo) % (hi - lo + step) + lo
        var.set(round(new_val, 1))
        self._schedule_live(tab)

    def _toggle_dr_advanced(self):
        if self._dr_adv_open.get():
            self._dr_adv_frame.pack_forget()
            self._dr_adv_open.set(False)
            self._dr_adv_btn.configure(text="▶  Advanced")
        else:
            self._dr_adv_frame.pack(fill="x", padx=0, pady=(0, 4))
            self._dr_adv_open.set(True)
            self._dr_adv_btn.configure(text="▼  Advanced")

    def _auto_edge(self):
        """Estimate Edge extent by measuring how far the halo/ringing extends from the limb."""
        import numpy as np
        from scipy.ndimage import distance_transform_edt, gaussian_filter

        src = self.working_arr if self.working_arr is not None else self.original_arr
        if src is None:
            self.dr_edge_lbl.configure(text="Load an image first"); return

        lum = (0.2126*src[...,0] + 0.7152*src[...,1] + 0.0722*src[...,2]).astype(np.float64)

        # Robust disk detection
        lum_max    = float(np.percentile(lum, 99.5))
        disk_thresh = max(lum_max * 0.15, 0.01)
        disk_mask   = lum > disk_thresh
        dist_sky    = distance_transform_edt(~disk_mask)

        # Deep sky background (far from limb)
        deep_sky_mask = dist_sky > 40
        if deep_sky_mask.sum() < 100:
            deep_sky_mask = dist_sky > 20
        sky_bg    = float(np.percentile(lum[deep_sky_mask], 85)) if deep_sky_mask.any() else 0.0
        ring_thresh = sky_bg + (lum_max - sky_bg) * 0.015

        # Find where sky brightness drops to near-background
        edge_px = 10
        for d in range(1, 40):
            shell = lum[(dist_sky >= d) & (dist_sky < d + 1)]
            if len(shell) < 10:
                continue
            if float(np.mean(shell)) <= ring_thresh:
                edge_px = max(d + 2, 4)
                break
        else:
            edge_px = 20

        edge_px = int(np.clip(edge_px, 4, 35))
        self.dr_edge.set(edge_px, fire_callback=False)
        self.dr_edge_lbl.configure(text=f"edge={edge_px}px")
        self._schedule_live(3)

    def _auto_dering(self):
        """Estimate best-guess de-rind parameters from the current image."""
        import numpy as np
        src = self.working_arr if self.working_arr is not None else self.original_arr
        if src is None:
            self.dr_auto_lbl.configure(text="Load an image first"); return

        import numpy as np
        from scipy.ndimage import distance_transform_edt
        lum = (0.2126*src[...,0] + 0.7152*src[...,1] + 0.0722*src[...,2]).astype(np.float64)

        # Robust disk detection: use fraction of image peak
        lum_max   = float(np.percentile(lum, 99.5))
        disk_thresh = max(lum_max * 0.15, 0.01)
        disk_mask   = lum > disk_thresh
        dist_sky    = distance_transform_edt(~disk_mask)

        # Estimate edge extent: find where sky brightness drops to near-background
        deep_sky_mask = dist_sky > 40
        if deep_sky_mask.sum() < 100:
            deep_sky_mask = dist_sky > 20
        sky_bg    = float(np.percentile(lum[deep_sky_mask], 85)) if deep_sky_mask.any() else 0.0
        ring_thresh = sky_bg + (lum_max - sky_bg) * 0.015

        edge_px = 10
        for d in range(1, 40):
            shell = lum[(dist_sky >= d) & (dist_sky < d + 1)]
            if len(shell) < 10:
                continue
            if float(np.mean(shell)) <= ring_thresh:
                edge_px = max(d + 2, 4)
                break
        else:
            edge_px = 16

        edge_px    = int(np.clip(edge_px, 4, 35))
        feather_px = max(2, edge_px // 3)

        self.dr_edge.set(edge_px, fire_callback=False)
        self.dr_feather.set(feather_px, fire_callback=False)
        self.dr_smooth.set(1, fire_callback=False)
        self.dr_inset.set(0, fire_callback=False)
        self.dr_gap_width.set(0.0)
        self.dr_gap_angle.set(0.0)
        self.dr_saturn.set(False)
        self.dr_dark_edge.set(True)
        self.dr_pre_blur.set(0.0, fire_callback=False)
        self.dr_show_map.set(False)
        self.dr_enabled.set(True)
        self.dr_auto_lbl.configure(text=f"edge={edge_px}px  feather={feather_px}px")
        self._schedule_live(3)
    # ── Stats Tab ────────────────────────────────────────────
    # ── Batch Tab ────────────────────────────────────────────
    def _build_batch_tab(self):
        f = self._scrollable_tab("⬡  Batch")

        tk.Label(f, text="Apply current Wavelet / FFT / RGB / De-rind settings to multiple files.",
                 bg=BG_PANEL, fg=FG_DIM, font=F_SM,
                 justify="left", wraplength=480).pack(fill="x", padx=10, pady=(6, 2))

        # ── INPUT FILES ────────────────────────────────────
        cf = card_frame(f, "INPUT FILES", ACCENT_C)

        # Buttons + count on one row
        btn_row = tk.Frame(cf, bg=BG_CARD); btn_row.pack(fill="x", pady=(0,3))
        tk.Button(btn_row, text="＋ Add",
                  command=self._batch_add_files,
                  bg=BG_RAISED, fg=ACCENT_C, font=F_SM, relief="flat",
                  cursor="hand2", padx=7, pady=2,
                  activebackground=SEL_BG).pack(side="left")
        tk.Button(btn_row, text="✕ Remove",
                  command=self._batch_remove_selected,
                  bg=BG_RAISED, fg=ACCENT_O, font=F_SM, relief="flat",
                  cursor="hand2", padx=7, pady=2,
                  activebackground=SEL_BG).pack(side="left", padx=(4,0))
        tk.Button(btn_row, text="⊘ Clear",
                  command=self._batch_clear,
                  bg=BG_RAISED, fg=FG_MID, font=F_SM, relief="flat",
                  cursor="hand2", padx=7, pady=2,
                  activebackground=SEL_BG).pack(side="left", padx=(4,0))
        self._batch_count_lbl = tk.Label(btn_row, text="0 files",
                                          bg=BG_CARD, fg=FG_DIM, font=F_SM)
        self._batch_count_lbl.pack(side="left", padx=10)

        # Compact listbox — 5 rows
        lb_frame = tk.Frame(cf, bg=BG_CARD); lb_frame.pack(fill="x")
        lb_scroll = tk.Scrollbar(lb_frame, orient="vertical")
        self._batch_listbox = tk.Listbox(
            lb_frame, height=5, font=F_SM,
            bg=BG_RAISED, fg=FG_MID, selectbackground=SEL_BG,
            relief="flat", bd=0, activestyle="none",
            yscrollcommand=lb_scroll.set, selectmode="extended")
        lb_scroll.config(command=self._batch_listbox.yview)
        lb_scroll.pack(side="right", fill="y")
        self._batch_listbox.pack(side="left", fill="x", expand=True)

        # ── ALIGNMENT + ROTATION (merged card) ─────────────
        car = card_frame(f, "ALIGNMENT & ROTATION", ACCENT_C)

        # Top row: align checkbox
        self._batch_align = tk.BooleanVar(value=False)
        tk.Checkbutton(car,
                       text="Align planet disks to common centre  (shifts each image to match first file)",
                       variable=self._batch_align,
                       bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                       activebackground=BG_CARD, font=F_SM).pack(anchor="w")

        tk.Frame(car, bg=BORDER, height=1).pack(fill="x", pady=(4,4))

        # Rotation header row
        rot_hdr = tk.Frame(car, bg=BG_CARD); rot_hdr.pack(fill="x")
        self._batch_rotate_on = tk.BooleanVar(value=False)
        tk.Checkbutton(rot_hdr, text="Rotate all images",
                       variable=self._batch_rotate_on,
                       bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                       activebackground=BG_CARD, font=F_SM,
                       command=self._batch_rotate_toggle).pack(side="left")
        tk.Label(rot_hdr, text="(negative = counter-clockwise)",
                 bg=BG_CARD, fg=FG_DIM, font=F_SM).pack(side="left", padx=8)

        # Presets + spinbox + expand + preview all on two rows
        rot_row1 = tk.Frame(car, bg=BG_CARD); rot_row1.pack(fill="x", pady=(3,2))
        self._batch_rot_preset_frame = rot_row1
        for deg in [45, 90, 180, -45, -90]:
            tk.Button(rot_row1, text=f"{deg}°",
                      command=lambda d=deg: self._batch_set_rotation(d),
                      bg=BG_RAISED, fg=FG_MID, font=F_SM, relief="flat",
                      cursor="hand2", padx=7, pady=2,
                      activebackground=SEL_BG).pack(side="left", padx=(0,3))
        # Spinbox inline
        tk.Label(rot_row1, text="Custom:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(side="left", padx=(8,0))
        self._batch_rot_deg = tk.DoubleVar(value=0.0)
        self._batch_rot_entry = tk.Spinbox(
            rot_row1, from_=-360, to=360, increment=1,
            textvariable=self._batch_rot_deg,
            font=F_SM, width=7, relief="flat", bg=BG_RAISED)
        self._batch_rot_entry.pack(side="left", padx=(4,0))
        tk.Label(rot_row1, text="°", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(side="left", padx=(2,0))

        rot_row2 = tk.Frame(car, bg=BG_CARD); rot_row2.pack(fill="x", pady=(0,4))
        self._batch_rot_expand = tk.BooleanVar(value=False)
        self._batch_rot_expand_cb = tk.Checkbutton(
            rot_row2, text="Expand canvas to fit  (may change image size)",
            variable=self._batch_rot_expand,
            bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
            activebackground=BG_CARD, font=F_SM,
            command=self._batch_update_rot_preview)
        self._batch_rot_expand_cb.pack(side="left")

        # Live rotation preview canvas (180×180 inset)
        prev_outer = tk.Frame(car, bg=BORDER, padx=1, pady=1)
        prev_outer.pack(anchor="w", pady=(2,0))
        self._batch_rot_canvas = tk.Canvas(
            prev_outer, width=180, height=180,
            bg="#303030", highlightthickness=0)
        self._batch_rot_canvas.pack()
        self._batch_rot_canvas_lbl = tk.Label(
            car, text="Enable rotation to see preview",
            bg=BG_CARD, fg=FG_DIM, font=("Consolas",11))
        self._batch_rot_canvas_lbl.pack(anchor="w")

        # Trace spinbox changes for live update
        self._batch_rot_deg.trace_add("write", lambda *_: self._batch_update_rot_preview())
        self._batch_rot_deg.trace_add("write", lambda *_: self._sync_batch_rot_to_preview())

        self._batch_rotate_toggle()

        # ── OUTPUT ─────────────────────────────────────────
        co = card_frame(f, "OUTPUT", ACCENT_G)

        of_row = tk.Frame(co, bg=BG_CARD); of_row.pack(fill="x", pady=(0,2))
        tk.Label(of_row, text="Save to:", bg=BG_CARD, fg=FG_MID, font=F_SM, width=9, anchor="w").pack(side="left")
        self._batch_out_dir = tk.StringVar(value="")
        tk.Entry(of_row, textvariable=self._batch_out_dir,
                 font=F_SM, bg=BG_RAISED, relief="flat", bd=2).pack(side="left", fill="x", expand=True, padx=(4,4))
        tk.Button(of_row, text="Browse…", command=self._batch_browse_output,
                  bg=BG_RAISED, fg=FG_MID, font=F_SM, relief="flat",
                  cursor="hand2", padx=6, pady=2,
                  activebackground=SEL_BG).pack(side="left")

        fn_row = tk.Frame(co, bg=BG_CARD); fn_row.pack(fill="x", pady=(0,2))
        tk.Label(fn_row, text="Folder name:", bg=BG_CARD, fg=FG_MID, font=F_SM, anchor="w").pack(side="left")
        self._batch_subfolder = tk.StringVar(value="")
        tk.Entry(fn_row, textvariable=self._batch_subfolder,
                 font=F_SM, bg=BG_RAISED, relief="flat", bd=2, width=26).pack(side="left", padx=(4,0))
        self._batch_path_lbl = tk.Label(co, text="", bg=BG_CARD, fg=FG_DIM,
                                         font=("Consolas",11), anchor="w")
        self._batch_path_lbl.pack(fill="x")
        self._batch_out_dir.trace_add("write", lambda *_: self._batch_update_path_lbl())
        self._batch_subfolder.trace_add("write", lambda *_: self._batch_update_path_lbl())

        fmt_row = tk.Frame(co, bg=BG_CARD); fmt_row.pack(fill="x", pady=(4,0))
        tk.Label(fmt_row, text="Format:", bg=BG_CARD, fg=FG_MID, font=F_SM, width=9, anchor="w").pack(side="left")
        self._batch_fmt = tk.StringVar(value="TIFF 16-bit")
        for fmt_opt in ["TIFF 16-bit", "PNG 8-bit", "JPEG"]:
            tk.Radiobutton(fmt_row, text=fmt_opt, variable=self._batch_fmt, value=fmt_opt,
                           bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                           activebackground=BG_CARD, font=F_SM).pack(side="left", padx=(4,0))

        # ── ANIMATION ──────────────────────────────────────
        can = card_frame(f, "ANIMATION", ACCENT_P)

        # Row 1: enable + format + delay + loop — all on one line
        anim_r1 = tk.Frame(can, bg=BG_CARD); anim_r1.pack(fill="x", pady=(0,3))
        self._batch_anim_on = tk.BooleanVar(value=False)
        tk.Checkbutton(anim_r1, text="Create animation",
                       variable=self._batch_anim_on,
                       bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                       activebackground=BG_CARD, font=F_SM).pack(side="left")
        self._batch_anim_fmt = tk.StringVar(value="WebP")
        for fmt_opt in ["WebP", "GIF"]:
            tk.Radiobutton(anim_r1, text=fmt_opt, variable=self._batch_anim_fmt, value=fmt_opt,
                           bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                           activebackground=BG_CARD, font=F_SM).pack(side="left", padx=(6,0))
        tk.Label(anim_r1, text="  Delay:", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(side="left")
        self._batch_anim_delay = tk.DoubleVar(value=0.5)
        tk.Spinbox(anim_r1, from_=0.05, to=10.0, increment=0.05,
                   textvariable=self._batch_anim_delay,
                   font=F_SM, width=6, relief="flat", bg=BG_RAISED,
                   format="%.2f").pack(side="left", padx=(4,0))
        tk.Label(anim_r1, text="s", bg=BG_CARD, fg=FG_MID, font=F_SM).pack(side="left", padx=(2,8))
        self._batch_anim_loop = tk.BooleanVar(value=True)
        tk.Checkbutton(anim_r1, text="Loop",
                       variable=self._batch_anim_loop,
                       bg=BG_CARD, fg=FG_MID, selectcolor=BG_RAISED,
                       activebackground=BG_CARD, font=F_SM).pack(side="left")

        # Row 2: filename + export button
        anim_r2 = tk.Frame(can, bg=BG_CARD); anim_r2.pack(fill="x", pady=(0,0))
        tk.Label(anim_r2, text="Filename:", bg=BG_CARD, fg=FG_MID, font=F_SM, width=9, anchor="w").pack(side="left")
        self._batch_anim_name = tk.StringVar(value="kepler_animation")
        tk.Entry(anim_r2, textvariable=self._batch_anim_name,
                 font=F_SM, bg=BG_RAISED, relief="flat", bd=2, width=22).pack(side="left", padx=(4,8))
        tk.Button(anim_r2, text="▶ Export Now",
                  command=self._batch_export_animation_standalone,
                  bg=BG_RAISED, fg=ACCENT_P, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=2,
                  activebackground=SEL_BG).pack(side="left")

        # ── SETTINGS SUMMARY ───────────────────────────────
        cs = card_frame(f, "SETTINGS SUMMARY", ACCENT_C)
        refresh_row = tk.Frame(cs, bg=BG_CARD); refresh_row.pack(fill="x", pady=(0,3))
        tk.Button(refresh_row, text="↻  Refresh Summary",
                  command=self._batch_refresh_summary,
                  bg=BG_RAISED, fg=ACCENT_C, font=F_SM, relief="flat",
                  cursor="hand2", padx=8, pady=2,
                  activebackground=SEL_BG).pack(side="left")
        tk.Label(refresh_row,
                 text="Shows settings that will be applied at Run time.",
                 bg=BG_CARD, fg=FG_DIM, font=F_SM).pack(side="left", padx=8)
        self._batch_summary_txt = tk.Text(
            cs, height=6, font=("Consolas", 11),
            bg=BG_RAISED, fg=FG_MID, relief="flat",
            state="disabled", wrap="none")
        self._batch_summary_txt.pack(fill="x")

        # ── RUN ────────────────────────────────────────────
        cr = card_frame(f, "RUN", ACCENT_G)

        run_row = tk.Frame(cr, bg=BG_CARD); run_row.pack(fill="x", pady=(0,4))
        self._batch_run_btn = tk.Button(run_row, text="▶  Run Batch",
                  command=self._batch_run,
                  bg=ACCENT_G, fg="white", font=F_BOLD, relief="flat",
                  cursor="hand2", padx=14, pady=6,
                  activebackground="#0d5a2a")
        self._batch_run_btn.pack(side="left")
        self._batch_cancel_btn = tk.Button(run_row, text="■  Cancel",
                  command=self._batch_cancel,
                  bg=BG_RAISED, fg=ACCENT_O, font=F_MD, relief="flat",
                  cursor="hand2", padx=10, pady=6,
                  activebackground=SEL_BG, state="disabled")
        self._batch_cancel_btn.pack(side="left", padx=(8,0))

        self._batch_progress_var = tk.DoubleVar(value=0.0)
        self._batch_progress_bar = ttk.Progressbar(
            cr, variable=self._batch_progress_var,
            maximum=100, length=400, mode="determinate")
        self._batch_progress_bar.pack(fill="x", pady=(4,2))

        self._batch_status_lbl = tk.Label(cr, text="Ready.", bg=BG_CARD,
                                           fg=FG_DIM, font=F_SM, anchor="w")
        self._batch_status_lbl.pack(fill="x")

        log_frame = tk.Frame(cr, bg=BG_CARD); log_frame.pack(fill="x", pady=(4,0))
        log_scroll = tk.Scrollbar(log_frame, orient="vertical")
        self._batch_log = tk.Text(log_frame, height=5, font=("Consolas", 11),
                                   bg=BG_RAISED, fg=FG_MID, relief="flat",
                                   state="disabled", wrap="none",
                                   yscrollcommand=log_scroll.set)
        log_scroll.config(command=self._batch_log.yview)
        log_scroll.pack(side="right", fill="y")
        self._batch_log.pack(side="left", fill="x", expand=True)

        # Internal state
        self._batch_files   = []
        self._batch_running = False
        self._batch_stop    = False

    # ── Batch helpers ─────────────────────────────────────────

    def _batch_log_msg(self, msg):
        """Append a line to the batch log widget (thread-safe via root.after)."""
        def _append():
            self._batch_log.config(state="normal")
            self._batch_log.insert("end", msg + "\n")
            self._batch_log.see("end")
            self._batch_log.config(state="disabled")
        self.root.after(0, _append)

    def _batch_add_files(self):
        paths = filedialog.askopenfilenames(
            title="Add Files to Batch",
            filetypes=[("Image files", "*.tif *.tiff *.png *.jpg *.jpeg *.bmp"),
                       ("All files", "*.*")])
        for p in paths:
            if p not in self._batch_files:
                self._batch_files.append(p)
                self._batch_listbox.insert("end", os.path.basename(p))
        self._batch_count_lbl.configure(text=f"{len(self._batch_files)} file{'s' if len(self._batch_files)!=1 else ''}")

    def _batch_remove_selected(self):
        selected = sorted(self._batch_listbox.curselection(), reverse=True)
        for idx in selected:
            self._batch_listbox.delete(idx)
            del self._batch_files[idx]
        self._batch_count_lbl.configure(text=f"{len(self._batch_files)} file{'s' if len(self._batch_files)!=1 else ''}")

    def _batch_clear(self):
        self._batch_listbox.delete(0, "end")
        self._batch_files.clear()
        self._batch_count_lbl.configure(text="0 files")

    def _batch_browse_output(self):
        d = filedialog.askdirectory(title="Choose Parent Folder for Output")
        if d:
            self._batch_out_dir.set(d)
            self._batch_update_path_lbl()

    def _batch_update_path_lbl(self):
        base = self._batch_out_dir.get().strip()
        sub  = self._batch_subfolder.get().strip()
        if base and sub:
            full = os.path.join(base, sub)
            self._batch_path_lbl.configure(text=f"→  {full}")
        elif base:
            self._batch_path_lbl.configure(text=f"→  {base}  (enter a folder name above)")
        else:
            self._batch_path_lbl.configure(text="")

    def _batch_cancel(self):
        self._batch_stop = True
        self._batch_status_lbl.configure(text="Cancelling…")

    def _on_preview_rotate(self):
        """Called when preview rotation spinbox changes — refresh preview and sync to batch."""
        try:
            deg = float(self._preview_rot_deg.get())
            deg = max(-360.0, min(360.0, deg))
            self._preview_rot_deg.set(round(deg, 1))
        except (ValueError, tk.TclError):
            self._preview_rot_deg.set(0.0)
            deg = 0.0
        # Redraw current processed result with new rotation (no re-pipeline needed)
        pil = self._get_processed_pil()
        if pil is not None:
            self._draw_on_canvas(self.cnv_proc, pil)
        # Sync to batch tab
        self._sync_preview_rot_to_batch(deg)

    def _preview_set_rotation(self, deg):
        """Set preview rotation to a specific value (preset or reset)."""
        self._preview_rot_deg.set(float(deg))
        self._on_preview_rotate()

    def _sync_batch_rot_to_preview(self):
        """Mirror batch rotation back to the preview rotation spinbox."""
        try:
            if not self._batch_rotate_on.get():
                return
            deg = float(self._batch_rot_deg.get())
            current = float(self._preview_rot_deg.get())
            if abs(deg - current) > 0.05:   # avoid feedback loop
                self._preview_rot_deg.set(round(deg, 1))
                # Redraw without triggering another sync
                pil = self._get_processed_pil()
                if pil is not None:
                    self._draw_on_canvas(self.cnv_proc, pil)
        except (AttributeError, ValueError, tk.TclError):
            pass

    def _sync_preview_rot_to_batch(self, deg):
        """Mirror the preview rotation into the Batch ALIGNMENT & ROTATION section."""
        try:
            self._batch_rot_deg.set(float(deg))
            if deg != 0.0:
                self._batch_rotate_on.set(True)
            self._batch_rotate_toggle()
            self._batch_update_rot_preview()
        except AttributeError:
            pass   # Batch tab not yet built

    def _batch_rotate_toggle(self):
        """Enable or disable rotation sub-controls based on checkbox."""
        state = "normal" if self._batch_rotate_on.get() else "disabled"
        for w in self._batch_rot_preset_frame.winfo_children():
            try: w.configure(state=state)
            except Exception: pass
        self._batch_rot_entry.configure(state=state)
        self._batch_rot_expand_cb.configure(state=state)
        self._batch_update_rot_preview()

    def _batch_update_rot_preview(self, *_):
        """Render rotated thumbnail live into the inset canvas."""
        import numpy as np
        from PIL import Image as PILImage, ImageTk as PILImageTk

        cnv = self._batch_rot_canvas
        lbl = self._batch_rot_canvas_lbl
        SIZE = 180

        if not self._batch_rotate_on.get():
            cnv.delete("all")
            cnv.create_rectangle(0, 0, SIZE, SIZE, fill="#303030", outline="")
            lbl.configure(text="Enable rotation to see preview")
            return

        src = self.working_arr if self.working_arr is not None else self.original_arr
        if src is None:
            cnv.delete("all")
            cnv.create_text(SIZE//2, SIZE//2, text="Load an image\nto preview",
                            fill="#888888", font=("Consolas", 11), justify="center")
            lbl.configure(text="")
            return

        try:
            deg    = float(self._batch_rot_deg.get())
        except (ValueError, tk.TclError):
            return

        expand = bool(self._batch_rot_expand.get())
        arr8   = np.clip(src * 255, 0, 255).astype(np.uint8)
        pil    = PILImage.fromarray(arr8)

        # Fit source into SIZE×SIZE first, then rotate
        scale_fit = min(SIZE / pil.width, SIZE / pil.height)
        thumb = pil.resize((max(1, int(pil.width*scale_fit)),
                             max(1, int(pil.height*scale_fit))),
                            PILImage.LANCZOS)
        rotated = thumb.rotate(-deg, expand=expand,
                               resample=PILImage.BICUBIC,
                               fillcolor=(0, 0, 0))

        # Fit rotated result into SIZE×SIZE canvas
        rw, rh = rotated.size
        scale2 = min(SIZE / rw, SIZE / rh)
        final  = rotated.resize((max(1, int(rw*scale2)),
                                  max(1, int(rh*scale2))),
                                 PILImage.LANCZOS)

        # Composite onto dark background
        bg_img = PILImage.new("RGB", (SIZE, SIZE), (0x30, 0x30, 0x30))
        ox = (SIZE - final.width)  // 2
        oy = (SIZE - final.height) // 2
        bg_img.paste(final, (ox, oy))

        tk_img = PILImageTk.PhotoImage(bg_img)
        cnv.delete("all")
        cnv.create_image(0, 0, anchor="nw", image=tk_img)
        cnv._rot_img = tk_img   # prevent GC

        dir_str = "CW" if deg > 0 else "CCW" if deg < 0 else "no rotation"
        lbl.configure(text=f"{deg:+.1f}°  {dir_str}"
                      + (f"  expanded to {rotated.width}×{rotated.height}px" if expand else ""))

    def _batch_set_rotation(self, deg):
        """Set rotation spinbox to a preset value and enable rotation."""
        self._batch_rotate_on.set(True)
        self._batch_rot_deg.set(float(deg))
        self._batch_rotate_toggle()
        self._batch_update_rot_preview()

    def _batch_export_animation_standalone(self):
        """Export animation from already-processed files in the output folder."""
        out_dir  = self._batch_out_dir.get().strip()
        subfolder = self._batch_subfolder.get().strip()
        if not out_dir or not subfolder:
            messagebox.showwarning("Animation", "Please set an output folder and folder name first.")
            return
        out_path = os.path.join(out_dir, subfolder)
        if not os.path.isdir(out_path):
            messagebox.showwarning("Animation", f"Output folder not found:\n{out_path}")
            return
        fmt = self._batch_anim_fmt.get()
        ext = ".webp" if fmt == "WebP" else ".gif"
        exts = (".tif", ".tiff", ".png", ".jpg", ".jpeg", ".webp")
        anim_name = self._batch_anim_name.get().strip() or "kepler_animation"
        # Exclude any existing animation files
        files = sorted([
            os.path.join(out_path, fn)
            for fn in os.listdir(out_path)
            if os.path.splitext(fn)[1].lower() in exts
               and not fn.startswith(anim_name)
        ])
        if not files:
            messagebox.showwarning("Animation", "No processed image files found in the output folder.")
            return
        self._build_animation(files, out_path, anim_name, fmt, ext)

    def _build_animation(self, image_paths, out_path, anim_name, fmt, ext):
        """Build and save animated WebP or GIF from a list of image file paths."""
        import numpy as np
        from PIL import Image as PILImage

        delay_ms  = max(50, int(round(self._batch_anim_delay.get() * 1000)))
        loop      = 0 if self._batch_anim_loop.get() else 1
        out_file  = os.path.join(out_path, anim_name + ext)

        try:
            frames = []
            for fp in image_paths:
                img = PILImage.open(fp).convert("RGB")
                frames.append(img)

            if not frames:
                messagebox.showwarning("Animation", "No frames to animate.")
                return

            first = frames[0]
            if fmt == "WebP":
                first.save(out_file, format="WEBP", save_all=True,
                           append_images=frames[1:],
                           duration=delay_ms, loop=loop, quality=90)
            else:  # GIF — convert to palette mode
                pal_frames = [fr.quantize(colors=256, method=PILImage.Quantize.MEDIANCUT)
                              for fr in frames]
                pal_frames[0].save(out_file, format="GIF", save_all=True,
                                   append_images=pal_frames[1:],
                                   duration=delay_ms, loop=loop, optimize=True)

            self._batch_log_msg(f"Animation saved: {os.path.basename(out_file)}  "
                                f"({len(frames)} frames, {delay_ms}ms/frame)")
            messagebox.showinfo("Animation", f"Saved: {out_file}")
        except Exception as e:
            messagebox.showerror("Animation error", str(e))

    def _batch_refresh_summary(self):
        """Read current tab settings and display a human-readable summary."""
        lines = []

        # Wavelet
        lvls = self._get_wavelet_params()
        fm   = self.wv_filter.get().split()[0]
        cm   = self.wv_color_model.get().split()[0]
        conv = self.wv_convolve.get().split()[0]
        ps   = float(self.wv_pre_smooth.get())
        pf   = float(self.wv_powerfn_exp.get()) if self.wv_powerfn_enabled.get() else None
        sf   = [float(self.wsf1.get()), float(self.wsf2.get()), float(self.wsf3.get())]
        lines.append("─── Wavelet ───────────────────────────────")
        for i,(sh,th,sz) in enumerate(lvls,1):
            active = sh > 0 or th > 0
            tag = "" if active else "  (off)"
            lines.append(f"  L{i}  Sharpen={sh}  Threshold={th}  σ={sz:.2f}px  SharpenFilter={sf[i-1]:.3f}{tag}")
        lines.append(f"  Filter={fm}  Colour={cm}  Convolve={conv}"
                     + (f"  Pre-Smooth={ps:.2f}" if ps>0 else "")
                     + (f"  PowerFn={pf:.2f}" if pf else ""))

        # FFT
        fft_on = self.fft_enabled.get()
        lines.append("─── FFT Denoise ───────────────────────────")
        if fft_on:
            fs = float(self.fft_marker_start)
            fe = float(self.fft_marker_end)
            fc = float(self.fft_curve_slider.get())
            fl = self.fft_layer.get()
            lines.append(f"  Enabled  Start={fs:.0f}%  End={fe:.0f}%  Curve={fc:.0f}  Layer={fl}")
        else:
            lines.append("  Disabled")

        # RGB
        rg  = float(self.rgb_r.get())/2;  gg  = float(self.rgb_g.get())/2;  bg_ = float(self.rgb_b.get())/2
        rgm = float(self.gamma_r.get())/100; ggm = float(self.gamma_g.get())/100; bgm = float(self.gamma_b.get())/100
        sat = float(self.saturation.get())/2; vib = float(self.vibrance.get())/2
        hue = float(self.hue_rot.get()); bri = float(self.brightness.get()); con = float(self.contrast.get())/100
        lines.append("─── RGB / Colour ──────────────────────────")
        lines.append(f"  Gain  R={rg:.0f}  G={gg:.0f}  B={bg_:.0f}"
                     + f"    Gamma  R={rgm:.2f}  G={ggm:.2f}  B={bgm:.2f}")
        lines.append(f"  Sat={sat:.0f}  Vib={vib:.0f}  Hue={hue:.0f}°"
                     + f"  Brightness={bri:.0f}  Contrast={con:.2f}")

        # De-rind
        dr_on = self.dr_enabled.get()
        lines.append("─── De-rind ───────────────────────────────")
        if dr_on:
            lines.append(f"  Enabled  Edge={self.dr_edge.get():.0f}px  Feather={self.dr_feather.get():.0f}px"
                         + f"  Smooth={self.dr_smooth.get():.0f}  Inset={self.dr_inset.get():.0f}px")
        else:
            lines.append("  Disabled")

        # Write to text widget
        self._batch_summary_txt.config(state="normal")
        self._batch_summary_txt.delete("1.0", "end")
        self._batch_summary_txt.insert("end", "\n".join(lines))
        self._batch_summary_txt.config(state="disabled")

    def _batch_align_image(self, arr, ref_cy, ref_cx):
        """Shift arr so its disk centre aligns to (ref_cy, ref_cx). Returns shifted array."""
        import numpy as np
        lum = 0.299*arr[...,0]+0.587*arr[...,1]+0.114*arr[...,2]
        lum_max = float(np.percentile(lum, 99.5))
        thresh  = max(lum_max * 0.15, 0.01)
        disk    = lum > thresh
        ys, xs  = np.where(disk)
        if len(ys) == 0:
            return arr
        cy, cx = float(ys.mean()), float(xs.mean())
        dy = int(round(ref_cy - cy))
        dx = int(round(ref_cx - cx))
        if dy == 0 and dx == 0:
            return arr
        from scipy.ndimage import shift
        shifted = np.stack([
            shift(arr[...,c], (dy, dx), mode="constant", cval=0.0)
            for c in range(3)
        ], axis=-1)
        return np.clip(shifted, 0.0, 1.0).astype(arr.dtype)

    def _batch_run(self):
        """Collect current pipeline params and launch batch in a background thread."""
        import threading, numpy as np

        if self._batch_running:
            return
        if not self._batch_files:
            messagebox.showwarning("Batch", "No files added to batch."); return
        out_dir   = self._batch_out_dir.get().strip()
        subfolder = self._batch_subfolder.get().strip()
        if not out_dir:
            messagebox.showwarning("Batch", "Please choose a save-to folder."); return
        if not subfolder:
            messagebox.showwarning("Batch", "Please enter a name for the output folder."); return
        out_path = os.path.join(out_dir, subfolder)

        # Capture ALL current pipeline settings on main thread
        wv_params = self._get_wavelet_params()
        wv_fm   = self.wv_filter.get().split()[0]
        wv_cm   = self.wv_color_model.get().split()[0]
        wv_conv = self.wv_convolve.get().split()[0]
        wv_sf   = [float(self.wsf1.get()), float(self.wsf2.get()), float(self.wsf3.get())]
        wv_ps   = float(self.wv_pre_smooth.get())
        wv_pf   = float(self.wv_powerfn_exp.get()) if self.wv_powerfn_enabled.get() else 1.0
        wv_zgf  = float(self.wv_zgauss_factor.get()) if hasattr(self, "wv_zgauss_factor") else 1.0
        wv_br   = float(self.wv_bilateral_radius.get()) if hasattr(self, "wv_bilateral_radius") else 2.0
        wv_bls  = [self.wbl1.get(), self.wbl2.get(), self.wbl3.get()]                   if wv_fm == "bilateral" and hasattr(self, "wbl1") else None
        fft_s   = float(self.fft_marker_start)
        fft_e   = float(self.fft_marker_end)
        fft_c   = float(self.fft_curve_slider.get())
        fft_layer = self.fft_layer.get()
        fft_on  = self.fft_enabled.get()
        _fft_p  = (fft_s, max(0.1, fft_e-fft_s), fft_c) if fft_on and fft_s < 100.0 else None
        fft_pre = [
            _fft_p if (fft_on and fft_layer=="PRE1") else None,
            _fft_p if (fft_on and fft_layer=="PRE2") else None,
            _fft_p if (fft_on and fft_layer=="PRE3") else None,
        ]
        r_g  = float(self.rgb_r.get())/100;  g_g  = float(self.rgb_g.get())/100
        b_g  = float(self.rgb_b.get())/100;  r_gm = float(self.gamma_r.get())/100
        g_gm = float(self.gamma_g.get())/100; b_gm = float(self.gamma_b.get())/100
        r_bp = float(self.black_r.get())/100; g_bp = float(self.black_g.get())/100
        b_bp = float(self.black_b.get())/100
        sat  = float(self.saturation.get())/100
        vib  = float(self.vibrance.get())/100
        hue  = float(self.hue_rot.get())
        bri  = float(self.brightness.get())/255
        con  = float(self.contrast.get())/100
        # ── Tools ──
        _lc_b = self._get_lc_params()
        b_tl_br,b_tl_wr,b_tl_gr, b_tl_bg,b_tl_wg,b_tl_gg, b_tl_bb,b_tl_wb,b_tl_gb,         b_tl_lr,b_tl_lg,b_tl_lb, b_tl_def = _lc_b
        b_clahe_on   = bool(self._clahe_enabled.get())
        b_clahe_clip = float(self._clahe_clip.get())
        b_clahe_tile = max(4, int(float(self._clahe_tile.get())))
        b_clahe_str  = float(self._clahe_strength.get())
        b_clahe_ch   = self._clahe_channel.get()
        dr_on = bool(self.dr_enabled.get())
        dr_p  = dict(
            edge=float(self.dr_edge.get()), feather=float(self.dr_feather.get()),
            smooth=float(self.dr_smooth.get()), inset=float(self.dr_inset.get()),
            gap_width=float(self.dr_gap_width.get()), gap_angle=float(self.dr_gap_angle.get()),
            saturn_mode=bool(self.dr_saturn.get()), dark_edge=bool(self.dr_dark_edge.get()),
            pre_blur=float(self.dr_pre_blur.get()), show_ring_map=False,
        )
        do_align    = bool(self._batch_align.get())
        do_rotate   = bool(self._batch_rotate_on.get())
        rot_deg     = float(self._batch_rot_deg.get()) if do_rotate else 0.0
        rot_expand  = bool(self._batch_rot_expand.get())
        do_anim     = bool(self._batch_anim_on.get())
        anim_fmt    = self._batch_anim_fmt.get()
        anim_ext    = ".webp" if anim_fmt == "WebP" else ".gif"
        anim_name   = self._batch_anim_name.get().strip() or "kepler_animation"
        fmt         = self._batch_fmt.get()
        suffix      = "_KEP"
        files    = list(self._batch_files)
        n        = len(files)

        # Update UI
        self._batch_running = True
        self._batch_stop    = False
        self._batch_run_btn.configure(state="disabled")
        self._batch_cancel_btn.configure(state="normal")
        self._batch_progress_var.set(0)
        self._batch_log.config(state="normal"); self._batch_log.delete("1.0","end"); self._batch_log.config(state="disabled")
        self._batch_status_lbl.configure(text=f"Starting batch of {n} files…")

        def _worker():
            import tifffile
            from PIL import Image as PILImage

            try:
                os.makedirs(out_path, exist_ok=True)
                self._batch_log_msg(f"Output: {out_path}")

                # Determine reference disk centre (first file) for alignment
                ref_cy, ref_cx  = None, None
                processed_files = []   # (img_array, original_filename) for animation

                for i, fpath in enumerate(files):
                    if self._batch_stop:
                        self._batch_log_msg("— Cancelled —")
                        break

                    fname = os.path.basename(fpath)
                    self.root.after(0, lambda i=i,n=n,fname=fname:
                        self._batch_status_lbl.configure(text=f"[{i+1}/{n}]  {fname}"))
                    self._batch_log_msg(f"[{i+1}/{n}]  {fname}")

                    # Load
                    ext = os.path.splitext(fpath)[1].lower()
                    try:
                        if ext in (".tif",".tiff"):
                            raw = tifffile.imread(fpath)
                            if raw.ndim == 2: raw = np.stack([raw]*3, axis=-1)
                            elif raw.shape[-1] > 3: raw = raw[...,:3]
                            if raw.dtype == np.uint16:
                                arr = raw.astype(np.float32)/65535.0
                            else:
                                arr = raw.astype(np.float32)
                                mn,mx=arr.min(),arr.max()
                                if mx>mn: arr=(arr-mn)/(mx-mn)
                        else:
                            pil = PILImage.open(fpath).convert("RGB")
                            arr = np.array(pil).astype(np.float32)/255.0
                    except Exception as e:
                        self._batch_log_msg(f"  ✕ Load error: {e}"); continue

                    # Alignment
                    if do_align:
                        lum = 0.299*arr[...,0]+0.587*arr[...,1]+0.114*arr[...,2]
                        lmax = float(np.percentile(lum,99.5))
                        disk = lum > max(lmax*0.15,0.01)
                        ys,xs = np.where(disk)
                        if len(ys)>0:
                            cy,cx = float(ys.mean()),float(xs.mean())
                            if ref_cy is None:
                                ref_cy,ref_cx = cy,cx
                                self._batch_log_msg(f"  Reference centre: ({cx:.1f},{cy:.1f})")
                            else:
                                arr = self._batch_align_image(arr, ref_cy, ref_cx)
                                self._batch_log_msg(f"  Aligned: shift ({cx-ref_cx:+.1f},{cy-ref_cy:+.1f})px")

                    # Pipeline
                    img = proc.wavelet_sharpen(arr, wv_params, wv_fm,
                                               color_model=wv_cm, convolve=wv_conv,
                                               pre_fft=fft_pre, sharp_filter=wv_sf,
                                               pre_smooth=wv_ps, power_fn=wv_pf,
                                               zgauss_factor=wv_zgf,
                                               bilateral_radius=wv_br,
                                               bilateral_layers=wv_bls)
                    if fft_on and fft_layer=="POST" and fft_s<100.0:
                        img = proc.fft_denoise(img, fft_start=fft_s,
                                               fft_width=max(0.1,fft_e-fft_s), fft_curve=fft_c)
                    img = proc.apply_color_adjustments(
                        img, r_gain=r_g, g_gain=g_g, b_gain=b_g,
                        r_black=r_bp, g_black=g_bp, b_black=b_bp,
                        r_gamma=r_gm, g_gamma=g_gm, b_gamma=b_gm,
                        saturation=sat, vibrance=vib, hue_rotation=hue,
                        brightness=bri, contrast=con)
                    if not b_tl_def:
                        img = proc.apply_levels_curves(
                            img,
                            black_r=b_tl_br, white_r=b_tl_wr, gamma_r=b_tl_gr,
                            black_g=b_tl_bg, white_g=b_tl_wg, gamma_g=b_tl_gg,
                            black_b=b_tl_bb, white_b=b_tl_wb, gamma_b=b_tl_gb,
                            curve_lut_r=b_tl_lr, curve_lut_g=b_tl_lg, curve_lut_b=b_tl_lb)
                    if b_clahe_on:
                        img = proc.apply_clahe(img,
                            clip_limit=b_clahe_clip, tile_grid=b_clahe_tile,
                            channel_mode=b_clahe_ch, strength=b_clahe_str)
                    if dr_on:
                        img = proc.apply_derind(img, **dr_p)

                    # Rotation (applied after pipeline)
                    if do_rotate and rot_deg != 0.0:
                        pil_img = PILImage.fromarray(
                            np.clip(img*255,0,255).astype(np.uint8))
                        # PIL rotate: positive = CCW internally; negate to match convention
                        # (positive input = CW, negative = CCW as stated by WaveSharp)
                        pil_img = pil_img.rotate(
                            -rot_deg, expand=rot_expand,
                            resample=PILImage.BICUBIC,
                            fillcolor=(0,0,0))
                        img = np.array(pil_img).astype(np.float32) / 255.0

                    processed_files.append((img, fname))

                    # Save
                    stem = os.path.splitext(fname)[0]
                    if fmt == "TIFF 16-bit":
                        out_fname = stem + suffix + ".tif"
                        arr16 = np.clip(img*65535.0,0,65535).astype(np.uint16)
                        tifffile.imwrite(os.path.join(out_path, out_fname), arr16)
                    elif fmt == "PNG 8-bit":
                        out_fname = stem + suffix + ".png"
                        arr8 = np.clip(img*255.0,0,255).astype(np.uint8)
                        PILImage.fromarray(arr8).save(os.path.join(out_path, out_fname))
                    else:  # JPEG
                        out_fname = stem + suffix + ".jpg"
                        arr8 = np.clip(img*255.0,0,255).astype(np.uint8)
                        PILImage.fromarray(arr8).save(os.path.join(out_path, out_fname), quality=95)

                    self._batch_log_msg(f"  ✔ Saved: {out_fname}")
                    pct = (i+1)/n*100
                    self.root.after(0, lambda p=pct: self._batch_progress_var.set(p))

                # Build animation from processed files
                if do_anim and processed_files and not self._batch_stop:
                    self.root.after(0, lambda: self._batch_status_lbl.configure(
                        text="Building animation…"))
                    self._batch_log_msg(f"Building {anim_fmt} animation ({len(processed_files)} frames)…")
                    saved_paths = []
                    for _, orig_fname in processed_files:
                        stem = os.path.splitext(orig_fname)[0]
                        ext_map = {"TIFF 16-bit": ".tif", "PNG 8-bit": ".png", "JPEG": ".jpg"}
                        saved_paths.append(os.path.join(out_path, stem + suffix + ext_map.get(fmt, ".tif")))
                    self._build_animation(saved_paths, out_path, anim_name, anim_fmt, anim_ext)

                if not self._batch_stop:
                    done_msg = f"Done — {n} file{'s' if n!=1 else ''} processed."
                    self._batch_log_msg(done_msg)
                    self.root.after(0, lambda: self._batch_status_lbl.configure(text=done_msg))

            except Exception as e:
                self._batch_log_msg(f"Batch error: {e}")
                self.root.after(0, lambda: self._batch_status_lbl.configure(text=f"Error: {e}"))
            finally:
                self._batch_running = False
                self._batch_stop    = False
                self.root.after(0, lambda: self._batch_run_btn.configure(state="normal"))
                self.root.after(0, lambda: self._batch_cancel_btn.configure(state="disabled"))

        import threading
        threading.Thread(target=_worker, daemon=True).start()

    def _build_stats_tab(self):
        outer = tk.Frame(self.notebook, bg=BG_PANEL)
        self.notebook.add(outer, text="📊 Stats")
        gf = tk.Frame(outer, bg=BG_PANEL, padx=8, pady=8); gf.pack(fill="x")
        self.stat_vars = {}
        for i,(k,lbl) in enumerate([("width","WIDTH"),("height","HEIGHT"),
                                     ("channels","CHANNELS"),("mean","MEAN L"),
                                     ("std","STD DEV"),("file","FILE")]):
            r,c = divmod(i,3)
            cell = tk.Frame(gf, bg=BG_CARD, padx=8, pady=6)
            cell.grid(row=r, column=c, padx=2, pady=2, sticky="nsew")
            self.stat_vars[k] = tk.StringVar(value="—")
            tk.Label(cell, textvariable=self.stat_vars[k],
                     bg=BG_CARD, fg=ACCENT_C, font=F_BOLD).pack()
            tk.Label(cell, text=lbl, bg=BG_CARD, fg=FG_DIM, font=F_TINY).pack()
        for c in range(3): gf.columnconfigure(c, weight=1)

        tk.Frame(outer, bg=BORDER, height=1).pack(fill="x", padx=8, pady=4)
        tk.Label(outer, text="Per-Channel Statistics",
                 bg=BG_PANEL, fg=FG_MID, font=F_MD).pack(padx=8, anchor="w")
        tbl = tk.Frame(outer, bg=BG_PANEL, padx=8, pady=4); tbl.pack(fill="x")
        for c,h in enumerate(["Channel","Min","Max","Mean","Std Dev"]):
            tk.Label(tbl, text=h, bg=BG_RAISED, fg=FG_MID, font=F_SM,
                     padx=6, pady=3, anchor="center"
                     ).grid(row=0, column=c, sticky="nsew", padx=1, pady=1)
        self.ch_stat_vars = {}
        for r,(ch,col) in enumerate([("Red","#dc2626"),("Green","#15803d"),
                                      ("Blue","#2563eb")], 1):
            tk.Label(tbl, text=ch, bg=BG_CARD, fg=col,
                     font=F_SM, padx=6, pady=3, anchor="w"
                     ).grid(row=r, column=0, sticky="nsew", padx=1, pady=1)
            rv = {}
            for c,key in enumerate(["min","max","mean","std"],1):
                v = tk.StringVar(value="—"); rv[key]=v
                tk.Label(tbl, textvariable=v, bg=BG_CARD, fg=FG_BRIGHT,
                         font=F_SM, padx=6, pady=3, anchor="center"
                         ).grid(row=r, column=c, sticky="nsew", padx=1, pady=1)
            self.ch_stat_vars[ch.lower()] = rv
        for c in range(5): tbl.columnconfigure(c, weight=1)

        tk.Frame(outer, bg=BORDER, height=1).pack(fill="x", padx=8, pady=4)
        tk.Label(outer, text="Histogram  (log scale, 0–65535)",
                 bg=BG_PANEL, fg=FG_MID, font=F_MD).pack(padx=8, anchor="w")
        self.hist_canvas2 = tk.Canvas(outer, height=160, bg=BG_CARD,
                                      highlightthickness=1, highlightbackground=BORDER)
        self.hist_canvas2.pack(fill="x", padx=8, pady=(3,10))

    # ── Image I/O ────────────────────────────────────────────
    def open_image(self):
        path = filedialog.askopenfilename(
            title="Open Planetary Image",
            filetypes=[("Image files","*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.fit *.fits"),
                       ("All files","*.*")])
        if not path: return
        try:
            # Use tifffile for TIFs to preserve 16-bit depth; fall back to PIL for others
            ext = os.path.splitext(path)[1].lower()
            if ext in (".tif", ".tiff"):
                try:
                    import tifffile
                    raw = tifffile.imread(path)
                    if raw.ndim == 2:                     # grayscale → RGB
                        raw = np.stack([raw]*3, axis=-1)
                    elif raw.shape[-1] > 3:               # RGBA → RGB
                        raw = raw[..., :3]
                    if raw.dtype == np.uint16:
                        arr = raw.astype(np.float32) / 65535.0
                    elif raw.dtype == np.uint8:
                        arr = raw.astype(np.float32) / 255.0
                    else:
                        arr = raw.astype(np.float32)
                        mn, mx = arr.min(), arr.max()
                        if mx > mn: arr = (arr - mn) / (mx - mn)
                    self.original_arr = arr
                    # Build display PIL from float32 (8-bit for canvas rendering)
                    pil = proc.array_to_pil(arr)
                except ImportError:
                    pil = Image.open(path).convert("RGB")
                    self.original_arr = proc.pil_to_array(pil)
            else:
                pil = Image.open(path).convert("RGB")
                self.original_arr = proc.pil_to_array(pil)

            self.original_pil = pil; self.working_pil = pil.copy()
            self.working_arr  = self.original_arr.copy()
            self._source_path = path
            # Reset preview rotation when a new image is loaded
            try:
                self._preview_rot_deg.set(0.0)
            except AttributeError:
                pass
            # Refresh curve canvas histogram with new image data
            try:
                self._draw_curve_canvas()
            except AttributeError:
                pass
            self._update_stats(path)
            self._update_fft_spectrum(self.original_arr)
            self.status_var.set("IMAGE LOADED")
            self.img_size_var.set(f"{pil.width}×{pil.height}  ·  {os.path.basename(path)}")
            # Defer canvas draws until layout is complete so winfo_width/height
            # return real pixel sizes for correct Fit scaling.
            def _draw_after_layout():
                self.root.update_idletasks()
                self._draw_on_canvas(self.cnv_orig, pil)
                self._draw_on_canvas(self.cnv_proc, pil)
                self._update_histogram(self.original_arr)
            self.root.after(30, _draw_after_layout)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open image:\n{e}")

    def export_image(self):
        if self.working_pil is None:
            messagebox.showwarning("No Image","No processed image to export."); return

        # Determine defaults from source file
        if self._source_path:
            base, src_ext = os.path.splitext(os.path.basename(self._source_path))
            src_ext  = src_ext.lower()
            init_dir = os.path.dirname(self._source_path)
            default_ext = src_ext if src_ext in (".tif",".tiff",".png",".jpg",".jpeg",".bmp") else ".tif"
        else:
            base        = "export_KEP"
            default_ext = ".tif"
            init_dir    = os.path.expanduser("~")

        # ── Format picker ─────────────────────────────────────────────────────
        # The Linux GTK file dialog ignores the filetypes filter — the selected
        # filter has no effect on the returned filename. We show a small format
        # selector first so the user explicitly picks the output format, then
        # open the save dialog with that extension already in the filename.
        _fmt_opts = [
            ("TIFF 16-bit  (.tif)",  ".tif"),
            ("PNG  (.png)",           ".png"),
            ("JPEG  (.jpg)",          ".jpg"),
            ("BMP  (.bmp)",           ".bmp"),
        ]
        picker = tk.Toplevel(self.root)
        picker.title("Export Format")
        picker.resizable(False, False)
        picker.grab_set()
        picker.configure(bg=BG_PANEL)
        tk.Label(picker, text="Save as format:",
                 bg=BG_PANEL, fg=FG_BRIGHT, font=F_SM).pack(padx=20, pady=(16,6))
        fmt_var = tk.StringVar(value=default_ext)
        for lbl, ext in _fmt_opts:
            tk.Radiobutton(picker, text=lbl, variable=fmt_var, value=ext,
                           bg=BG_PANEL, fg=FG_BRIGHT, selectcolor=BG_RAISED,
                           activebackground=BG_PANEL, font=F_SM,
                           anchor="w").pack(fill="x", padx=24, pady=2)
        btn_row = tk.Frame(picker, bg=BG_PANEL)
        btn_row.pack(pady=(10,16), padx=20, fill="x")
        chosen = [None]
        def _ok():
            chosen[0] = fmt_var.get()
            picker.destroy()
        def _cancel():
            picker.destroy()
        tk.Button(btn_row, text="Cancel", command=_cancel,
                  bg=BG_RAISED, fg=FG_MID, font=F_SM, relief="flat",
                  padx=10, pady=4, cursor="hand2",
                  activebackground=SEL_BG).pack(side="right", padx=(4,0))
        tk.Button(btn_row, text="  OK  ", command=_ok,
                  bg=ACCENT_G, fg="white", font=F_SM, relief="flat",
                  padx=10, pady=4, cursor="hand2",
                  activebackground=SEL_BG).pack(side="right")
        # Let tkinter size the window to its contents, then centre it.
        # A fixed geometry clips the OK button on Windows due to larger DPI/font rendering.
        picker.update_idletasks()
        pw = picker.winfo_reqwidth()
        ph = picker.winfo_reqheight()
        px = self.root.winfo_x() + (self.root.winfo_width()  - pw) // 2
        py = self.root.winfo_y() + (self.root.winfo_height() - ph) // 2
        picker.geometry(f"+{px}+{py}")
        picker.wait_window()
        if chosen[0] is None:
            return
        default_ext  = chosen[0]

        # ── File save dialog ──────────────────────────────────────────────────
        # No filetypes filter — format is already decided by the picker above.
        default_name = base + "_KEP" + default_ext
        path = filedialog.asksaveasfilename(
            title="Export Processed Image",
            initialdir=init_dir,
            initialfile=default_name,
            defaultextension=default_ext)
        if not path: return
        # Resolve extension and PIL format explicitly — don't let PIL guess.
        # On Linux GTK, the dialog may return a path with no extension.
        _ext_to_fmt = {
            ".tif": "TIFF", ".tiff": "TIFF",
            ".png": "PNG",
            ".jpg": "JPEG", ".jpeg": "JPEG",
            ".bmp": "BMP",
        }
        _root, _ext = os.path.splitext(path)
        _ext = _ext.lower()
        if _ext not in _ext_to_fmt:
            # No extension or unrecognised — append the default
            _ext = default_ext.lower()
            path = (_root if _root else path) + _ext
        pil_fmt = _ext_to_fmt[_ext]
        try:
            try:
                rot_deg = float(self._preview_rot_deg.get())
            except (ValueError, AttributeError, tk.TclError):
                rot_deg = 0.0
            if _ext in (".tif", ".tiff") and self.working_arr is not None:
                # Export as 16-bit TIFF preserving full dynamic range.
                import tifffile as _tifffile
                if rot_deg != 0.0:
                    pil_tmp = proc.array_to_pil(self.working_arr)
                    pil_tmp = pil_tmp.rotate(-rot_deg, expand=False,
                                             resample=Image.BICUBIC,
                                             fillcolor=(0, 0, 0))
                    arr16 = np.clip(
                        np.array(pil_tmp).astype(np.float32) / 255.0 * 65535.0,
                        0, 65535).astype(np.uint16)
                else:
                    arr16 = np.clip(self.working_arr * 65535.0, 0, 65535).astype(np.uint16)
                _tifffile.imwrite(path, arr16)
            else:
                img = self.working_pil if self.working_arr is None                       else proc.array_to_pil(self.working_arr)
                if rot_deg != 0.0:
                    img = img.rotate(-rot_deg, expand=False,
                                     resample=Image.BICUBIC,
                                     fillcolor=(0, 0, 0))
                # Pass format= explicitly so PIL never has to guess from extension
                img.save(path, format=pil_fmt)
            rot_note = f"  (rotated {rot_deg:+.1f}°)" if rot_deg != 0.0 else ""
            self.status_var.set("EXPORTED")
            messagebox.showinfo("Exported", f"Image saved to:\n{path}{rot_note}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))
        """Force a full pipeline re-run with current slider values.
        Cancels any pending debounce, resets processing state if stuck,
        then fires immediately."""
        if self.original_arr is None: return
        # Cancel any queued debounce timer
        if self._live_after is not None:
            self.root.after_cancel(self._live_after)
            self._live_after = None
        # If the processing flag is stuck (e.g. thread died silently), clear it
        if self.processing:
            self.processing = False
            self.progress_var.set(0)
        self._fire_live()

    def _fft_auto_denoise(self):
        """
        Estimate best-guess FFT denoise band from the image's power spectrum.

        Strategy:
          - Compute the smoothed radial power spectrum of the processed image
          - Find where the drop rate (first derivative) slows to <10% of the
            initial drop rate — this marks where signal energy gives way to
            noise/sharpening artefacts
          - Set start = that point (clamped to 15-45% Nyquist)
          - Set end = 70% (fixed — always roll off well past the noise floor)
          - Curve chosen based on the flatness of the noise plateau
        """
        src = self.working_arr if self.working_arr is not None else self.original_arr
        if src is None:
            self.fft_auto_lbl.configure(text="Load an image first")
            return

        import numpy as np
        from scipy.ndimage import gaussian_filter1d

        sp = proc.compute_fft_power(src)   # 64-bin normalised power spectrum
        n  = len(sp)

        sp_s = gaussian_filter1d(sp.astype(np.float64), sigma=2.0)
        d1 = np.diff(sp_s)

        # Initial drop rate: mean slope of the first 8 bins (signal-dominated)
        initial_rate = float(np.mean(d1[:8]))   # negative value

        # Find first bin (past bin 4) where slope slows to <10% of initial rate
        # i.e., the drop essentially stops — signal has given way to noise floor
        threshold = initial_rate * 0.10         # 10% of initial rate (less negative)
        slow_bins = np.where(d1[4:] > threshold)[0]
        if len(slow_bins) > 0:
            cross_bin = slow_bins[0] + 4
        else:
            cross_bin = int(n * 0.30)

        start_pct = float(np.clip(cross_bin / n * 100.0, 15.0, 45.0))
        end_pct   = 70.0   # always roll off to 70% Nyquist

        # Noise severity: how flat is the plateau from 30-70%?
        # A flat spectrum (ratio hi/lo near 1) = mild noise
        # A rising spectrum = heavy sharpening artefacts
        plateau = sp_s[int(n*0.30) : int(n*0.70)]
        if len(plateau) > 1:
            plateau_ratio = float(plateau.max() / (plateau.min() + 1e-8))
        else:
            plateau_ratio = 1.5

        if plateau_ratio > 1.3:
            curve = 85.0
            desc  = "heavy noise"
        elif plateau_ratio > 1.1:
            curve = 65.0
            desc  = "moderate noise"
        else:
            curve = 50.0
            desc  = "mild noise"

        # Apply
        self.fft_marker_start = round(start_pct, 1)
        self.fft_marker_end   = round(end_pct,   1)
        self.fft_curve_slider.set(curve, fire_callback=False)
        self.fft_enabled.set(True)
        self.fft_disabled_lbl.pack_forget()
        self.fft_start_lbl.configure(text=f"{self.fft_marker_start:.0f}%")
        self.fft_end_lbl.configure(text=f"{self.fft_marker_end:.0f}%")
        self.fft_auto_lbl.configure(
            text=f"start={self.fft_marker_start:.0f}%  end={self.fft_marker_end:.0f}%  {desc}")
        self._redraw_fft_graph()
        self._schedule_live(1)

    def _fft_reset(self):
        """Reset all FFT controls to defaults."""
        self.fft_marker_start = 60.0
        self.fft_marker_end   = 90.0
        self.fft_enabled.set(False)
        self.fft_disabled_lbl.pack(side="left", padx=8)
        self.fft_curve_slider.set(25.0, fire_callback=False)
        self.fft_layer.set("POST")
        self.fft_start_lbl.configure(text="60%")
        self.fft_end_lbl.configure(text="90%")
        try: self.fft_auto_lbl.configure(text="")
        except Exception: pass
        self._redraw_fft_graph()
        self._schedule_live(1)

    def reset_tab_sliders(self):
        """Reset sliders in active tab to defaults, then re-run live processing."""
        idx = self._current_tab_index
        if idx == 1:
            self._fft_reset()
            self.status_var.set("FFT RESET")
            return
        if idx == 3:
            self._derind_reset()
            self.status_var.set("DE-RIND RESET")
            return
        for s in self._tab_sliders.get(idx, []):
            s.set(s._default, fire_callback=False)
        self.status_var.set("TAB SLIDERS RESET")
        self._pending_tab = idx
        self._fire_live()

    def _derind_reset(self):
        """Reset all De-rind controls to defaults."""
        for s in self._tab_sliders.get(4, []):
            s.set(s._default, fire_callback=False)
        self.dr_gap_width.set(0.0)
        self.dr_gap_angle.set(0.0)
        self.dr_saturn.set(False)
        self.dr_dark_edge.set(True)
        self.dr_show_map.set(False)
        self.dr_enabled.set(False)
        self.dr_auto_lbl.configure(text="")
        self.dr_edge_lbl.configure(text="")
        self._pending_tab = 3
        self._fire_live()

    def reset_all(self):
        """Reset ALL sliders and image back to original."""
        for tab_idx, sliders in self._tab_sliders.items():
            for s in sliders:
                
                s.set(s._default, fire_callback=False)
        self.reset_image()
        self.status_var.set("FULL RESET")

    def _update_stats(self, path=""):
        if self.original_arr is None: return
        arr = self.original_arr; h, w = arr.shape[:2]
        lum = proc.luminance(arr)
        self.stat_vars["width"].set(str(w)); self.stat_vars["height"].set(str(h))
        self.stat_vars["channels"].set("RGB")
        self.stat_vars["mean"].set(f"{lum.mean()*255:.1f}")
        self.stat_vars["std"].set(f"{lum.std()*255:.1f}")
        self.stat_vars["file"].set(os.path.basename(path)[:16] if path else "—")
        for i, ch in enumerate(["red","green","blue"]):
            d = arr[...,i]
            self.ch_stat_vars[ch]["min"].set(f"{d.min()*255:.1f}")
            self.ch_stat_vars[ch]["max"].set(f"{d.max()*255:.1f}")
            self.ch_stat_vars[ch]["mean"].set(f"{d.mean()*255:.1f}")
            self.ch_stat_vars[ch]["std"].set(f"{d.std()*255:.1f}")

    def _update_histogram(self, arr):
        for canvas, h in [(self.hist_canvas,135),(self.hist_canvas2,160)]:
            draw_line_histogram(canvas, arr, h)

    def _update_fft_spectrum(self, arr):
        def _go():
            spec = proc.compute_fft_power(arr)
            self._fft_spectrum = spec
            self.root.after(0, self._draw_fft_graph)
        threading.Thread(target=_go, daemon=True).start()

    # ── Processing ───────────────────────────────────────────
    def _get_wavelet_params(self):
        return [
            (int(self.ws1.get()), int(self.wt1.get()), float(self.wsz1.get())),
            (int(self.ws2.get()), int(self.wt2.get()), float(self.wsz2.get())),
            (int(self.ws3.get()), int(self.wt3.get()), float(self.wsz3.get())),
        ]

    def _do_wavelet(self, arr):
        fm = self.wv_filter.get().split()[0]
        br = getattr(self, "wv_bilateral_radius", None)
        bilateral_radius = float(br.get()) if br is not None else 2.0
        zf = getattr(self, "wv_zgauss_factor", None)
        zgauss_factor = float(zf.get()) if zf is not None else 1.0
        bilateral_layers = [
            self.wbl1.get(),
            self.wbl2.get(),
            self.wbl3.get(),
        ] if fm == "bilateral" else None
        return proc.wavelet_sharpen(
            arr, self._get_wavelet_params(), fm,
            bilateral_radius=bilateral_radius,
            zgauss_factor=zgauss_factor,
            bilateral_layers=bilateral_layers)

    def _do_fft(self, arr):
        """Apply FFT denoise using current marker positions (POST mode)."""
        if not self.fft_enabled.get():
            return arr
        fs = float(self.fft_marker_start)
        fe = float(self.fft_marker_end)
        return proc.fft_denoise(arr, fft_start=fs,
                                fft_width=max(0.1, fe - fs),
                                fft_curve=float(self.fft_curve_slider.get()))

    def _do_color(self, arr):
        return proc.apply_color_adjustments(
            arr,
            r_gain=self.rgb_r.get()/100,    g_gain=self.rgb_g.get()/100,
            b_gain=self.rgb_b.get()/100,    r_gamma=self.gamma_r.get()/100,
            g_gamma=self.gamma_g.get()/100, b_gamma=self.gamma_b.get()/100,
            saturation=self.saturation.get()/100,
            vibrance=self.vibrance.get()/100,
            hue_rotation=self.hue_rot.get(),
            brightness=self.brightness.get()/255,
            contrast=self.contrast.get()/100)

    def _do_dering(self, arr):
        return proc.apply_derind(
            arr,
            edge=self.dr_edge.get(),
            feather=self.dr_feather.get(),
            smooth=self.dr_smooth.get(),
            gap_width=self.dr_gap_width.get(),
            gap_angle=self.dr_gap_angle.get(),
            saturn_mode=self.dr_saturn.get(),
            dark_edge=self.dr_dark_edge.get(),
            pre_blur=self.dr_pre_blur.get(),
            show_ring_map=self.dr_show_map.get())

    def _run_in_thread(self, fn, label="PROCESSING"):
        if self.original_arr is None: return
        if self.processing: return
        self.processing = True
        self.status_var.set(label + "…")
        self.progress_var.set(10)
        def worker():
            try:
                result = fn()
                self.working_arr = result
                self.root.after(0, self._finish_processing)
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Processing Error",str(e)))
                self.root.after(0, self._reset_processing_state)
        threading.Thread(target=worker, daemon=True).start()

    def _finish_processing(self):
        if self.working_arr is not None:
            proc_pil = self._get_processed_pil()
            self._draw_on_canvas(self.cnv_proc, proc_pil)
            # Refresh magnifier if it has an active PROC view
            if self.magnifier._last_pil is not None and self.magnifier._last_name == "PROC":
                self.magnifier.click_magnify(
                    proc_pil,
                    self.magnifier._last_px,
                    self.magnifier._last_py,
                    "PROC")
        self._update_histogram(self.working_arr if self.working_arr is not None
                               else self.original_arr)
        self._update_fft_spectrum(self.working_arr if self.working_arr is not None
                                  else self.original_arr)
        self.progress_var.set(100); self.status_var.set("DONE")
        self.processing = False
        self.root.after(1500, lambda: self.progress_var.set(0))
        # If a slider moved while we were processing, fire immediately now
        if self._live_pending:
            self._live_pending = False
            self.root.after(0, self._fire_live)

    def _reset_processing_state(self):
        self.processing = False; self.status_var.set("ERROR"); self.progress_var.set(0)

    def run_estimate_sharpen(self):
        """Estimate optimal filter sigma per level from current sharpen values.
        Activates Autosize and updates sigma labels."""
        if self.original_arr is None:
            messagebox.showwarning("No Image", "Load an image first."); return
        self._run_autosize()
        self.wv_autosize.set(True)
        self._wv_sigmas = [float(self.wsz1.get()), float(self.wsz2.get()), float(self.wsz3.get())]
        self.estimate_lbl.configure(
            text=f"Decomp: σ1={self._wv_sigmas[0]:.1f}px  "
                 f"σ2={self._wv_sigmas[1]:.1f}px  "
                 f"σ3={self._wv_sigmas[2]:.1f}px")
        if self._live_after is not None:
            self.root.after_cancel(self._live_after)
            self._live_after = None
        self._pending_tab = 0
        self._fire_live()

    def auto_balance(self):
        """Full levels balance: sets R/G/B gain AND black point sliders so
        both shadow and highlight edges of the histogram align. Always computed
        from the original image so repeated clicks give the same stable result."""
        if self.original_arr is None:
            messagebox.showwarning("No Image","Load an image first."); return
        rg, gg, bg_, rbp, gbp, bbp = proc.auto_balance(self.original_arr)
        for slider, val in [
            (self.rgb_r,   rg  * 100),
            (self.rgb_g,   gg  * 100),
            (self.rgb_b,   bg_ * 100),
            (self.black_r, rbp * 100),
            (self.black_g, gbp * 100),
            (self.black_b, bbp * 100),
        ]:
            slider.set(val, fire_callback=False)
        self.status_var.set("AUTO RGB BALANCED")
        self._pending_tab = 2
        self._fire_live()

    def auto_white_balance(self):
        """Percentile stretch: sets R/G/B gain AND gamma sliders. Always
        computed from the original image so repeated clicks are idempotent."""
        if self.original_arr is None:
            messagebox.showwarning("No Image","Load an image first."); return
        gains, gammas = proc.auto_white_balance(self.original_arr)
        rg, gg, bg_  = gains
        rgm, ggm, bgm = gammas
        for slider, val in [(self.rgb_r,   rg*100),
                            (self.rgb_g,   gg*100),
                            (self.rgb_b,   bg_*100),
                            (self.gamma_r, rgm*100),
                            (self.gamma_g, ggm*100),
                            (self.gamma_b, bgm*100)]:
            slider.set(val, fire_callback=False)
        self.status_var.set("AUTO WHITE BALANCED")
        self._pending_tab = 2
        self._fire_live()

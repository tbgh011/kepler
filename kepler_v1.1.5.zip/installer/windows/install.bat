@echo off
:: ============================================================
::  Kepler - Planetary Image Processing Suite
::  Windows Installer Bootstrap
:: ============================================================
setlocal EnableDelayedExpansion
title Kepler Installer

:: Resolve the project root (two levels up from installer\windows\)
set "INSTALLER_DIR=%~dp0"
pushd "%~dp0..\.."
set "KEPLER_ROOT=%CD%"
popd

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║           KEPLER  -  Planetary Image Processor           ║
echo  ║                    Windows Installer                     ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

:: ── Locate Python ──────────────────────────────────────────
set "PYTHON_CMD="
for %%P in (python python3 py) do (
    %%P --version >nul 2>&1
    if !errorLevel! == 0 (
        if not defined PYTHON_CMD set "PYTHON_CMD=%%P"
    )
)

if not defined PYTHON_CMD (
    echo  Python not found. Trying winget...
    winget install Python.Python.3.11 --accept-package-agreements --accept-source-agreements --silent >nul 2>&1
    for %%P in (python python3 py) do (
        %%P --version >nul 2>&1
        if !errorLevel! == 0 (
            if not defined PYTHON_CMD set "PYTHON_CMD=%%P"
        )
    )
)

if not defined PYTHON_CMD (
    echo  ERROR: Python not found. Please install from https://www.python.org/downloads/
    echo  IMPORTANT: tick "Add python.exe to PATH" during install.
    start https://www.python.org/downloads/
    pause
    exit /b 1
)
echo  Python: %PYTHON_CMD%

:: ── GUI installer ───────────────────────────────────────────
if exist "%INSTALLER_DIR%install_gui.py" (
    echo  Launching GUI installer...
    %PYTHON_CMD% "%INSTALLER_DIR%install_gui.py"
    if not errorlevel 1 goto :end
    echo  GUI installer failed. Falling back to text mode...
)

:: ── Text-mode fallback ─────────────────────────────────────
echo.
echo  Installing packages (numpy, Pillow, scipy, tifffile)...
%PYTHON_CMD% -m pip install --upgrade pip numpy Pillow scipy tifffile

set "INSTALL_DIR=%LOCALAPPDATA%\Kepler"
echo  Installing Kepler to: %INSTALL_DIR%
mkdir "%INSTALL_DIR%" 2>nul

for %%F in (main.py app.py processing.py requirements.txt) do (
    if exist "%KEPLER_ROOT%\%%F" (
        copy /Y "%KEPLER_ROOT%\%%F" "%INSTALL_DIR%\%%F" >nul
        echo  Copied %%F
    ) else (
        echo  WARNING: %%F not found
    )
)
if exist "%KEPLER_ROOT%\icon.ico" copy /Y "%KEPLER_ROOT%\icon.ico" "%INSTALL_DIR%\icon.ico" >nul

:: Resolve pythonw.exe from the found Python
for /f "delims=" %%I in ('%PYTHON_CMD% -c "import sys,os;print(os.path.dirname(sys.executable))"') do set "PY_DIR=%%I"
set "PYTHONW=%PY_DIR%\pythonw.exe"
if not exist "%PYTHONW%" set "PYTHONW=%PYTHON_CMD%"

(echo @echo off
echo cd /d "%INSTALL_DIR%"
echo start "" "%PYTHONW%" "%INSTALL_DIR%\main.py" %%*) > "%INSTALL_DIR%\Kepler.bat"

setx PATH "%PATH%;%INSTALL_DIR%" /M >nul 2>&1

echo.
echo  ============================================================
echo   Installed to: %INSTALL_DIR%
echo   Launch:  double-click Kepler.bat  or  type 'Kepler' in terminal
echo  ============================================================
pause

:end
endlocal
